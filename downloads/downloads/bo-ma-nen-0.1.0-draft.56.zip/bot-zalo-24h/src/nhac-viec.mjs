import { cleanText, sha256 } from './mo-rong-du-lieu.mjs';
import {naturalReminderIntent,naturalReminderFollowup,parseNaturalReminder} from './nhac-tu-nhien.mjs';
export const reminderCommand = text => /^\/(?:nhac|lichnhac|huynhac)(?:\s|$)/i.test(String(text??'').trim());
export function parseReminder(text,now){
  let m=String(text).trim().match(/^\/nhac\s+sau\s+(\d{1,4})\s+(phút|giờ|ngày)\s+([\s\S]+)$/iu),due,content;
  if(m){due=now+Number(m[1])*({phút:60000,giờ:3600000,ngày:86400000}[m[2].toLowerCase()]);content=m[3];}
  else{
    m=String(text).trim().match(/^\/nhac\s+(\d{2})\/(\d{2})\/(\d{4})\s+(\d{2}):(\d{2})\s+([\s\S]+)$/u);
    if(!m)return null;
    const [,d,mo,y,h,min,body]=m;
    due=Date.parse(`${y}-${mo}-${d}T${h}:${min}:00+07:00`);content=body;
    if(!Number.isFinite(due)||new Date(due+7*3600000).toISOString().slice(0,16)!==`${y}-${mo}-${d}T${h}:${min}`)return null;
  }
  return cleanText(content,700)&&due-now>=60000&&due-now<=365*86400000?{due,text:content.trim()}:null;
}
export function vnTime(n){const t=new Date(n+7*3600000).toISOString();return `${t.slice(8,10)}/${t.slice(5,7)}/${t.slice(0,4)} ${t.slice(11,16)} (giờ Việt Nam)`;}
export class Reminders{
  constructor(storage,{now=Date.now}={}){this.storage=storage;this.now=now;}
  async pendingKey(event){return 'reminder-pending:'+await sha256(JSON.stringify([event.chatType??'PRIVATE',event.chatId,event.senderId]));}
  async hasFollowup(event){
    const key=await this.pendingKey(event),p=await this.storage.get(key);
    if(!p)return false;
    if(p.expires<=this.now()||!naturalReminderFollowup(event.text,p.draft,this.now())){await this.storage.delete(key);return false;}
    return true;
  }
  async next(){const rows=await this.storage.list({prefix:'reminder:'});const pending=[...rows.values()].filter(v=>['pending','sending'].includes(v.status));return pending.length?Math.min(...pending.map(v=>v.status==='sending'?v.watchdog:v.due)):null;}
  async handle(event){
    if(!cleanText(event.senderId,256)||!cleanText(event.chatId,256)||!cleanText(event.key,1200))return 'Chưa xác định được người tạo lịch.';
    const natural=naturalReminderIntent(event.text),command=reminderCommand(event.text);
    const pendingKey=await this.pendingKey(event);
    const receipt='reminder-event:'+await sha256(event.key);
    const cached=await this.storage.get(receipt);if(cached)return cached.reply;
    if(!command&&!natural&&!await this.hasFollowup(event))return null;
    const id=(await sha256(event.key)).slice(0,16);
    let created=false;
    const result=await this.storage.transaction(async()=>{
      const old=await this.storage.get(receipt);if(old)return old.reply;
      let parsedNatural=null;
      if(!command){
        const pending=await this.storage.get(pendingKey);
        const previous=!natural&&pending?.expires>this.now()?pending.draft:null;
        const current=this.now(),anchor=Number.isFinite(event.eventAt)&&Math.abs(current-event.eventAt)<=86400000?event.eventAt:Number.isFinite(event.created)?event.created:current;
        parsedNatural=parseNaturalReminder(event.text,current,previous,anchor);
        if(!parsedNatural)return null;
        if(parsedNatural.state!=='ready'){
          if(parsedNatural.state==='incomplete')await this.storage.put(pendingKey,{draft:parsedNatural.draft,expires:this.now()+5*60000});
          else await this.storage.delete(pendingKey);
          const reply=parsedNatural.state==='cancelled'?'Đã bỏ yêu cầu đang hỏi thêm; các lịch đã đặt vẫn giữ nguyên.':parsedNatural.reply;
          await this.storage.put(receipt,{reply,created:this.now()});return reply;
        }
      }
      await this.storage.delete(pendingKey);
      const rows=await this.storage.list({prefix:'reminder:'});
      const own=[...rows.values()].filter(v=>v.actor===event.senderId&&v.chatId===event.chatId);
      // User-facing numbers survive restarts and are never reused after expiry.
      // Backups retain row.number; a missing counter is rebuilt from those rows.
      const sequenceKey='reminder-number:'+await sha256(JSON.stringify([event.chatId,event.senderId]));
      const previous=await this.storage.get(sequenceKey);
      let sequence=Math.max(Number.isSafeInteger(previous?.value)?previous.value:0,...own.map(v=>Number.isSafeInteger(v.number)&&v.number>0?v.number:0));
      const allocate=()=>{if(sequence>=999999999)throw Error('reminder-number-limit');return ++sequence;};
      for(const v of own.sort((a,b)=>a.created-b.created||a.id.localeCompare(b.id)))if(!Number.isSafeInteger(v.number)||v.number<1){v.number=allocate();await this.storage.put('reminder:'+v.id,v);}
      const describe=v=>`${v.number}. ${v.text.slice(0,120)}\n${vnTime(v.due)} · ${v.status==='pending'?'chờ nhắc':v.status==='sending'?'đang gửi':v.status==='restored-paused'?'đang dừng sau khôi phục':'chưa rõ đã gửi; không tự gửi lại'}${v.status==='pending'?'\nHủy: /huynhac '+v.number:''}`;
      const text=event.text.trim();let reply;
      if(/^\/lichnhac$/i.test(text)){
        const waiting=own.filter(v=>['pending','sending','uncertain','restored-paused'].includes(v.status)).sort((a,b)=>a.due-b.due);
        reply=waiting.length?waiting.slice(0,8).map(describe).join('\n\n'):'Chưa có lịch nhắc đang chờ trong chat này.';
      }else if(/^\/huynhac(?:\s|$)/i.test(text)){
        const code=text.split(/\s+/)[1],pending=own.filter(v=>v.status==='pending');
        const target=code?own.find(v=>v.id===code)||own.find(v=>String(v.number)===code):pending.length===1?pending[0]:null;
        if(!code&&pending.length>1)reply='Chọn lịch cần hủy:\n'+pending.slice(0,8).sort((a,b)=>a.due-b.due).map(describe).join('\n\n');
        else if(!code&&!pending.length)reply='Chưa có lịch đang chờ để hủy.';
        else if(!target)reply='Không có lịch này trong danh sách của bạn. Gửi /lichnhac để xem lại.';
        else if(target.status!=='pending')reply='Lịch đã bắt đầu gửi hoặc đã kết thúc; không thể xác nhận hủy.';
        else{target.status='cancelled';target.finished=this.now();await this.storage.put('reminder:'+target.id,target);reply=`Đã hủy: ${target.text}`;}
      }else{
        const parsed=parsedNatural?.state==='ready'?{due:parsedNatural.due,text:parsedNatural.text}:parseReminder(text,this.now());
        if(!parsed)reply='Dùng /nhac 25/12/2026 09:00 Nội dung hoặc /nhac sau 10 phút Nội dung. Giờ Việt Nam; từ 1 phút đến 365 ngày, tối đa 700 ký tự.';
        else if(own.filter(v=>v.status==='pending').length>=20||rows.size>=500)reply='Đã đạt số lịch có thể lưu. Hãy kiểm /lichnhac và hủy lịch không cần.';
        else{const number=allocate();await this.storage.put('reminder:'+id,{id,number,...parsed,actor:event.senderId,chatId:event.chatId,chatType:event.chatType??'PRIVATE',status:'pending',created:this.now()});created=true;reply=`Đã hẹn nhắc: ${parsed.text}\n${vnTime(parsed.due)}\nHủy: /huynhac ${number}`;}
      }
      await this.storage.put(sequenceKey,{value:sequence});
      await this.storage.put(receipt,{reply,created:this.now()});return reply;
    });
    if(created)console.info('REMINDER_CREATED',JSON.stringify({kind:command?'command':'natural',chatType:event.chatType==='GROUP'?'GROUP':'PRIVATE',stored:true}));
    return result;
  }
  async drain(sender,{enabled=true,allowGroup=async()=>false}={}){
    if(!enabled)return;
    const row=await this.storage.transaction(async()=>{
      const all=await this.storage.list({prefix:'reminder:'});let chosen;
      for(const [key,v] of all){
        if(v.status==='sending'&&v.watchdog<=this.now()){v.status='uncertain';v.finished=this.now();await this.storage.put(key,v);}
        if(!chosen&&v.status==='pending'&&v.due<=this.now()){
          // Do not flood old reminders after prolonged downtime or a restored backup.
          if(this.now()-v.due>86400000||v.chatType==='GROUP'&&!await allowGroup(v.chatId)){v.status='missed';v.finished=this.now();await this.storage.put(key,v);continue;}
          v.status='sending';v.watchdog=this.now()+30000;await this.storage.put(key,v);chosen=v;
          // Persist a wake-up before I/O so a crash cannot strand a sending reminder.
          const alarm=await this.storage.getAlarm();
          await this.storage.setAlarm(alarm&&alarm>this.now()?Math.min(alarm,v.watchdog):v.watchdog);
        }
      }
      return chosen;
    });
    if(!row)return;
    let result;try{result=await sender.send({chat_id:row.chatId,text:`Nhắc việc: ${row.text}\n${vnTime(row.due)}`});}catch{result={status:'uncertain'};}
    row.status=['sent','rejected'].includes(result?.status)?result.status:'uncertain';row.finished=this.now();await this.storage.put('reminder:'+row.id,row);
  }
  async maintain(){
    const now=this.now();
    for(const [key,p]of await this.storage.list({prefix:'reminder-pending:'}))if(p.expires<=now)await this.storage.delete(key);
    for(const prefix of ['reminder:','reminder-event:'])for(const [k,v]of await this.storage.list({prefix})){
      const at=prefix==='reminder:'?v.finished:v.created;
      if(Number.isFinite(at)&&now-at>30*86400000)await this.storage.delete(k);
    }
  }
}
