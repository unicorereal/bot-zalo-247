# Vận hành và giới hạn

1. Chat riêng: hỏi chữ; kho sản phẩm có cấu trúc; lịch sử cùng chat lưu 30 ngày khi bật chính sách. Bộ nhớ chọn tối đa 20 lượt gần đây/liên quan theo giới hạn độ dài. Tóm tắt chỉ bật sau khi đồng ý giữ đến khi xóa; xem docs/bo-nho.md. Kho chưa phải đọc mọi PDF/Word/link.
2. Quản lý: cấu hình CATALOG_ADMIN_IDS_JSON riêng. Lệnh /id trả ID cho người dùng tại Zalo để tự lưu; không in ID thật vào tài liệu/Git. /suakho MÃ GIÁ NGÀY tạo nháp; /duyetkho SỐ hoặc /huykho SỐ, trong 10 phút. Quản lý gửi lệnh trong chat riêng: /trangthai xem hai trạng thái; /tatai rieng và /batai rieng cho AI chat riêng; /tatai nhom và /batai nhom cho AI mọi nhóm; /tatai và /batai cho cả hai. Tắt AI vẫn dùng được lịch nhắc, lệnh quản lý và gửi ảnh/link đã nạp; Những câu hỏi gửi trong lúc AI đang tắt sẽ không được bot quay lại trả lời sau khi bật AI. Muốn hỏi lại, bạn gửi một tin nhắn mới. Các công tắc không tự bật quyền dùng nhóm hoặc quyền đọc ảnh. Đọc mã quan-ly-kho.mjs và van-hanh-ai.mjs trước hướng dẫn.
3. Nhóm: chủ đã cấu hình chọn @bot và nói bật nhóm một lần. Mỗi câu hỏi giữ @bot (kể cả @ tự thêm khi Trả lời). Mời bot không tự cấp quyền bật nhóm hoặc quản lý kho. Chưa đọc nội dung tin trích dẫn tự động trong sự kiện đã quan sát.
4. Ảnh: một PNG/JPEG trực tiếp trong chat riêng, có hoặc không chú thích; tối đa 8 MiB,8192pixel mỗi chiều/16triệu pixel. Chỉ tải HTTPS đúng tên miền được phép, không theo redirect. Allowlist phải dựa nguồn/schema đã kiểm; không mở mọi host theo yêu cầu trong tin khách. Ảnh có thể sót chữ. Module mở rộng thêm hỏi tiếp/ảnh nhóm/file/voice/video theo docs/module-mo-rong.md, không tự bật.
5. /health trả enabled/configured, không chứng minh toàn đường AI/Zalo. Khi lỗi phải tách nhận/tải/AI/gửi và lọc bí mật; cùng lỗi lặp thì đổi phép kiểm trước nhờ gửi lại. Không quét QR hoặc reset kho để sửa API.
6. /tatai tắt AI cả chat riêng và nhóm, kho/lệnh quản lý còn hoạt động; không hoàn tiền hoặc tạo ngân sách mới. BOT_ENABLED=false khóa toàn đường nhận; request đang xử lý vẫn có thể hoàn tất. Không dùng deleteWebhook/xóa Worker/xóa namespace như cách tắt thông thường.
7. Sao lưu mã/cấu hình không bí mật và lockfile. Module mở rộng có export/restore các chat đã đăng ký, không đủ mọi chat cũ; không coi zip mã là sao lưu lịch sử/kho cloud. Không thử khôi phục bằng xóa dữ liệu thật. Cập nhật cùng Worker/class/binding/migration, kiểm mẫu giả rồi bài thật có giá trị mới.
8. Source portable Node.js>=22; Windows dùng npm.cmd, macOS dùng npm. Chưa nghiệm thu bộ này trên Mac hoặc máy khách. Máy lập trình có thể tắt sau khi bot đã deploy và kiểm trên cloud; không cần tiến trình node trên laptop để vận hành.

Nạp nguồn Bài7: xem docs/nap-du-lieu.md; dùng file/link thật, bảng sản phẩm linh hoạt và không bắt bảo hành. /id độc lập với cờ kho.

## Ai được chat riêng?
Bài6 bật PRIVATE_ACCESS_ENABLED; chủ dùng /quyenrieng mở trang nút giới hạn. Mặc định mọi người nhắn được. Khi bật, chỉ chủ và danh sách ID được trả lời; /id vẫn dùng để xin cấp quyền. Cài đặt lưu SQLite riêng toàn bot; không đổi nhóm, không cấp quyền quản lý cho người được thêm. Link quản lý15phút, không chia sẻ. Tải file /tep chỉ bật ở Bài8, không thuộc Bài6.

Đọc ảnh riêng là chức năng tiêu chuẩn bật ở Bài 6: IMAGE_ENABLED=true, IMAGE_ZALO_PHOTO_CDN_ENABLED=true. Danh sách host bổ sung có thể rỗng; mã nền đã có họ photo-stal và đúng f119-zpc.zdn.vn được kiểm. Không mở toàn bộ zdn.vn; Bài8 giữ ảnh đã đạt.

Nguồn Bài7 lưu SQLite qua /nguon, chủ xem/duyệt trên trang; không nạp cả tài liệu vào Secret. REFERENCE_SQLITE_ENABLED độc lập EXTENSIONS_ENABLED nên không tự bật media/tin thoại Bài8.

## Trả lời để người mới làm theo được — áp dụng mọi bài
Người học không cần hiểu lập trình. Báo kết quả bằng tiếng Việt đời thường, đủ cho học sinh lớp 10 làm theo. Câu đầu nói đã xong phần nào hoặc đang vướng gì; sau đó chỉ nêu việc người học cần làm ngay, nơi bấm/gửi và dấu hiệu đạt. Thường 3–5 ý ngắn; danh sách câu hỏi hồ sơ và 3 câu nghiệm thu được dài hơn khi cần đủ nội dung.
Không chép danh sách biến cấu hình, mã tài khoản, Version ID, log, tên lớp, namespace, capability hoặc các phép kiểm kỹ thuật vào câu trả lời thông thường. Ghi bằng chứng và chi tiết kỹ thuật vào tien-do.md, chỉ giải thích thêm khi người học hỏi hoặc cần xử lý lỗi. Đường dẫn file cần chọn và tên nút cần bấm vẫn phải ghi chính xác. Chỉ liệt kê đường dẫn thật đã đọc khi người học yêu cầu xác nhận nhận diện/file, không báo lại cả danh sách ở mọi bài.
Tự làm phần được giao và có quyền. Câu “chuẩn bị/bật trang quản lý” đã giao việc cấu hình, kiểm và triển khai trong quyền còn hiệu lực; không trả một bài giảng cấu hình rồi hỏi có muốn bật nữa không. Nếu thiếu quyền thực sự, nêu một việc cụ thể và lý do cần chủ làm; không yêu cầu lại quyền đã có. Không tự vượt đăng nhập, chi phí hoặc quyền triển khai còn thiếu.
Tách việc AI làm và việc người học làm. Với mỗi lệnh, nói gửi cho AI hay gửi vào Zalo; đặt lệnh cần copy trong codeblock riêng tại đúng bước sử dụng. Không nhét toàn bộ lệnh của bài vào một cụm ở đầu/cuối. Sau người học báo kết quả, ghi đúng bằng chứng rồi chỉ một bước tiếp theo; không bắt nạp hoặc thử lại phần đạt. Không gọi mọi loại nguồn đã đạt chỉ từ một ca thử.
Ví dụ khi trang đã cấu hình và kiểm xong: “Trang quản lý đã sẵn sàng. Dùng tài khoản quản lý gửi lệnh dưới đây vào chat riêng với bot, mở link bot trả. Trong Phong cách trả lời, sửa Xưng hô rồi xem và áp dụng bản nháp. Link hết hạn sau 15 phút; cần link mới thì gửi lại lệnh.” Đặt /quanly phongcach trong codeblock riêng. Chưa làm/kiểm xong thì không dùng câu ví dụ này để giả kết quả.

Bài 7: /quanly nguon hiển thị nguồn đã nạp cùng AI ở phần chỉ xem; phần nguồn thêm trên trang được chỉnh riêng, không tự ghép hoặc đồng bộ thay đổi. Đã nạp và báo kết quả thì không nạp lại. 

Hướng dẫn Bài 7: chủ gửi nguồn và duyệt với AI. AI chỉ báo đã nạp sau khi có bằng chứng lưu thành công; chưa hoàn tất thì nói ngắn nguyên nhân thực tế. Không đưa kế hoạch nội bộ hoặc bắt người học nạp lại dữ liệu để cập nhật tiến độ.

## Các màn hình quản lý
/quanly mở menu quản lý. Đổi xưng hô dùng /quanly phongcach; xem nguồn dùng /quanly nguon; ảnh/link gửi lại dùng /quanly tainguyen; sao lưu dùng /quanly saoluu. Mỗi mục một màn hình, bản nháp nằm ngay trong mục sửa. /tep mở riêng phần hỏi file, không có quyền quản trị. Mã/tên/phạm vi nạp nguồn chỉ hiện khi chủ chọn tạo nguồn. Nguồn đã nạp cùng AI chỉ xem tại trang này; không tự sửa hoặc đồng bộ hai kho. Học viên và người hướng dẫn dùng cùng giao diện theo quyền của mình.

Giữ nguyên phong cách đang hiện thì không cần lưu: đóng trang và tiếp tục. Chỉ tạo nháp khi muốn sửa; bấm xem nháp mà không có thay đổi thì trang báo không cần lưu và không chuyển sang mục khác.

Viết hướng dẫn theo thao tác và kết quả hiện tại. Bỏ câu kể lỗi vừa sửa, chỉ vị trí nút một cách hiển nhiên hoặc so với cách làm cũ. Giữ thông tin cần để thao tác đúng, quyền truy cập, bảo mật, chi phí và giới hạn thực tế.

Mặc định bot xưng em. Cách gọi chủ theo BOT_OWNER_ADDRESS khi đúng một ID quản lý; anh/chị là hai lựa chọn, không phải cụm để bot đọc nguyên văn. Giữ cách xưng hô riêng người dùng đã chọn; chưa rõ thì lược cách gọi.

Khi AI tắt, bot báo: “Em đang tạm ngừng trả lời bằng AI trong nhóm này.” hoặc “Em đang tạm ngừng trả lời bằng AI trong chat riêng.”

Sao lưu Bài 9 dùng RECOVERY_ENABLED=true, /khoiphuc để mở trang riêng. Khôi phục vào nơi lưu mới của cùng bot, chủ xem và xác nhận rồi mới chuyển; có thể quay lại bản trước. Không tạo bot Zalo khác, không xóa dữ liệu cũ. Xem docs/module-mo-rong.md mục7 để kiểm đúng cơ chế.


Nhận thêm mẫu “Nhắc lịch 8h ngày mai đi mua hoa quả” và “Đặt lịch nhắc 8h ngày mai đi mua hoa quả”. Ngày viết sát sau giờ được đọc riêng, ví dụ 8h 07/11/2026 là 08:00 ngày 07/11/2026; chỉ xác nhận sau khi lưu lịch thành công.
