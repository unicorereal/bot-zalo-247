import test from 'node:test';
import assert from 'node:assert/strict';
import {naturalReminderIntent,parseNaturalReminder} from '../src/nhac-tu-nhien.mjs';
import {Reminders} from '../src/nhac-viec.mjs';
import {DurableInbox} from '../src/hang-doi-ben.mjs';
import {CloudExtensions} from '../src/mo-rong-cloud.mjs';
import {exportRows} from '../src/sao-luu-cloud.mjs';
const NOW=Date.parse('2026-10-16T22:15:00+07:00');
const event=(text,key='e1',senderId='u',chatId='c')=>({kind:'text',text,key,senderId,chatId,chatType:'PRIVATE'});
test('reported reminder wording routes to the scheduler and never consumes the day as minutes',()=>{
 const now=Date.parse('2026-10-28T09:01:00+07:00');
 for(const text of ['nhắc lịch 8h 7/11 đi ăn hỏi sơn','Nhắc tôi 8h 7/11 đi ăn hỏi sơn','Đặt lịch nhắc 8h 7/11 đi ăn hỏi sơn','Nhắc 8h 07/11/2026 đi ăn hỏi sơn']){
  assert.equal(naturalReminderIntent(text),true,text);
  const p=parseNaturalReminder(text,now);assert.equal(p.state,'ready',text);
  assert.equal(p.due,Date.parse('2026-11-07T08:00:00+07:00'),text);assert.equal(p.text,'đi ăn hỏi sơn',text);
 }
 for(const [text,time]of [['Nhắc lịch 8h30 7/11 đi ăn hỏi sơn','08:30'],['Nhắc lịch 7/11 lúc 8h đi ăn hỏi sơn','08:00'],['Nhắc lịch 08:05 07/11/2026 đi ăn hỏi sơn','08:05']])assert.equal(parseNaturalReminder(text,now).due,Date.parse('2026-11-07T'+time+':00+07:00'),text);
 assert.equal(naturalReminderIntent('Nhắc lịch sử của Nhà An'),false);
 assert.equal(naturalReminderIntent('Nhắc lại lịch đã đặt'),false);
 assert.equal(parseNaturalReminder('Nhắc lịch 8h đi ăn hỏi sơn',now).state,'incomplete');
 assert.equal(parseNaturalReminder('Nhắc lịch 8h 31/11 đi ăn hỏi sơn',now).state,'invalid');
});
class Store{
 rows=new Map();alarm=null;tail=Promise.resolve();
 async get(k){return structuredClone(this.rows.get(k));}
 async put(k,v){this.rows.set(k,structuredClone(v));}
 async delete(k){this.rows.delete(k);}
 async list({prefix=''}){return new Map([...this.rows].filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k,structuredClone(v)]));}
 async setAlarm(n){this.alarm=n;}async getAlarm(){return this.alarm;}
 async transaction(fn){const before=this.tail;let done;this.tail=new Promise(r=>done=r);await before;try{return await fn();}finally{done();}}
}
test('natural request preserves original task, Vietnam date and morning time',()=>{
 const p=parseNaturalReminder('Nhắc t vào 9h sáng mai đi mua hoa quả',NOW);
 assert.equal(p.state,'ready');assert.equal(p.due,Date.parse('2026-10-17T09:00:00+07:00'));assert.equal(p.text,'đi mua hoa quả');
 for(const text of ['Nhắc tôi ngày mai lúc 9 giờ sáng đi mua hoa quả','Nhắc em vào 09:00 ngày 17/10/2026 đi mua hoa quả'])assert.equal(parseNaturalReminder(text,NOW).due,p.due);
 assert.equal(parseNaturalReminder('Nhắc tối mai 9h đi mua hoa quả',NOW).due,Date.parse('2026-10-17T21:00:00+07:00'));
 assert.equal(parseNaturalReminder('Nhắc tôi lúc 9h tối ngày mai đi mua hoa quả',NOW).due,Date.parse('2026-10-17T21:00:00+07:00'));
});
test('relative durations, leap day and midnight do not depend on machine timezone',()=>{
 assert.equal(parseNaturalReminder('Nhắc tôi sau 10 phút uống nước',NOW).due,NOW+600000);
 assert.equal(parseNaturalReminder('Nhắc tôi lúc 0h ngày mai uống thuốc',NOW).due,Date.parse('2026-10-17T00:00:00+07:00'));
 const n=Date.parse('2028-02-28T23:00:00+07:00');assert.equal(parseNaturalReminder('Nhắc tôi lúc 9h ngày mai họp',n).due,Date.parse('2028-02-29T09:00:00+07:00'));
 assert.equal(parseNaturalReminder('Nhắc tôi sau 1 giờ đọc sách',NOW).text,'đọc sách');
 assert.equal(parseNaturalReminder('Nhắc tôi sau 1 phút uống nước',NOW+500,null,NOW).due,NOW+60000);
 assert.equal(parseNaturalReminder('Nhắc tôi lúc 1h đêm ngày mai uống nước',NOW).due,Date.parse('2026-10-17T01:00:00+07:00'));
 const before=Date.parse('2026-10-16T23:59:59+07:00'),after=before+3000;
 assert.equal(parseNaturalReminder('Nhắc tôi lúc 9h ngày mai họp',after,null,before).due,Date.parse('2026-10-17T09:00:00+07:00'));
});
test('missing, invalid, past and multiple dates never silently schedule',()=>{
 for(const text of ['Nhắc t đi mua hoa quả','Nhắc t lúc 9h đi mua hoa quả','Nhắc t ngày mai đi mua hoa quả'])assert.equal(parseNaturalReminder(text,NOW).state,'incomplete');
 for(const text of ['Nhắc t ngày 31/02/2027 lúc 9h họp','Nhắc t ngày mai lúc 25h họp','Nhắc t ngày mai lúc 9h75 họp','Nhắc t lúc 9h hôm nay họp','Nhắc t sau 0 phút họp','Nhắc t sau 366 ngày họp','Nhắc t ngày mai lúc 9h hoặc 10h họp','Nhắc t ngày mai ngày kia lúc 9h họp'])assert.equal(parseNaturalReminder(text,NOW).state,'invalid',text);
 assert.equal(naturalReminderIntent('Nhắc lại lời bài hát'),false);assert.equal(naturalReminderIntent('Hôm qua bạn đã nhắc tôi điều gì?'),false);
 for(const text of ['Nhắc tôi lúc 9 giờ rưỡi ngày mai đi học','Nhắc tôi 9h kém 15 ngày mai đi học','Nhắc tôi ngày mai sau 1.5 giờ đi học','Nhắc tôi lúc 9h sáng tối mai họp','Nhắc tôi 9h ngày mai và lặp lại mỗi ngày'])assert.equal(parseNaturalReminder(text,NOW).state,'invalid',text);
});
test('clarifications are scoped, expire, cancel, and discard on a new topic',async()=>{
 const s=new Store();let now=NOW;const r=new Reminders(s,{now:()=>now});
 assert.match(await r.handle(event('Nhắc t lúc 9h đi mua hoa quả')),/ngày nhắc/);assert.equal((await s.list({prefix:'reminder:'})).size,0);
 assert.equal(await r.hasFollowup(event('ngày mai','e2','other')),false);
 assert.equal(await r.hasFollowup(event('ngày mai','e2','u','other-chat')),false);
 const reply=await r.handle(event('ngày mai','e2'));assert.match(reply,/Đã hẹn nhắc/);assert.match(reply,/17\/10\/2026 09:00/);
 assert.equal(await r.handle(event('ngày mai','e2')),reply);assert.equal((await s.list({prefix:'reminder:'})).size,1);
 await r.handle(event('Nhắc t đi học','e3'));assert.match(await r.handle(event('hủy','e4')),/Đã bỏ yêu cầu/);assert.equal((await s.list({prefix:'reminder:'})).size,1);
 await r.handle(event('Nhắc t lúc 9h đọc sách','e5'));now+=300001;assert.equal(await r.hasFollowup(event('ngày mai','e6')),false);
 await r.handle(event('Nhắc t lúc 9h đọc sách','e7'));assert.equal(await r.hasFollowup(event('Kể chuyện vui','e8')),false);assert.equal(await r.handle(event('ngày mai','e9')),null);
});
test('missing content asks for an explicit content reply and pending draft is not backed up',async()=>{
 const s=new Store(),r=new Reminders(s,{now:()=>NOW});assert.match(await r.handle(event('Nhắc t lúc 9h sáng mai')),/Nội dung:/);
 assert.equal(exportRows(await s.list({prefix:''})).length,0);
 assert.match(await r.handle(event('Nội dung: đi mua 🍎 hoa quả','e2')),/Đã hẹn nhắc: đi mua 🍎 hoa quả/);
});
test('old commands, quota and delivery remain idempotent',async()=>{
 const s=new Store();let now=NOW;const r=new Reminders(s,{now:()=>now});
 const e=event('Nhắc tôi sau 1 phút uống nước');const results=await Promise.all([r.handle(e),r.handle(e)]);assert.equal(results[0],results[1]);assert.equal((await s.list({prefix:'reminder:'})).size,1);
 assert.match(await r.handle(event('/lichnhac','list')),/uống nước/);assert.match(await r.handle(event('/huynhac 1','cancel')),/Đã hủy/);
 await r.handle(event('/nhac sau 1 phút kiểm lịch','old'));now+=60001;const sent=[];await r.drain({send:async msg=>{sent.push(msg);return {status:'sent'};}});await r.drain({send:async msg=>{sent.push(msg);return {status:'sent'};}});assert.equal(sent.length,1);assert.match(sent[0].text,/kiểm lịch/);
 for(let i=0;i<20;i++)await r.handle(event('Nhắc tôi sau 10 phút uống nước','cap'+i));assert.match(await r.handle(event('Nhắc tôi sau 10 phút uống nước','over')),/Đã đạt số lịch/);
});
test('durable inbox routes a clarification without using conversational AI and preserves group guard',async()=>{
 const s=new Store(),r=new Reminders(s,{now:()=>NOW}),sent=[];let calls=0;
 const inbox=new DurableInbox(s,{now:()=>NOW,extensionsEnabled:true,aiEnabled:true,handleExtension:async e=>({status:'ready',reply:await r.handle(e)}),isReminderFollowup:e=>r.hasFollowup(e),nextReminder:()=>r.next()});
 const sender={send:async v=>{sent.push(v);return {status:'sent'};}},ai=async()=>{calls++;throw Error('should not call AI');};
 await inbox.enqueue(event('Nhắc t lúc 9h đi mua hoa quả'));await inbox.drain(sender,ai);
 await inbox.enqueue(event('ngày mai','e2'));await inbox.drain(sender,ai);assert.equal(calls,0);assert.match(sent[1].text,/Đã hẹn nhắc/);
 assert.equal(s.alarm,Date.parse('2026-10-17T09:00:00+07:00'));
 assert.equal((await inbox.enqueue({...event('Nhắc tôi sau 1 phút abc','g'),chatType:'GROUP'})).reason,'group-not-allowed');
});
test('cloud extension uses saved reminder result, not a model success message',async()=>{
 const x=new CloudExtensions({storage:new Store()},{});x.now=()=>NOW;
 const a=await x.command(event('Nhắc t vào 9h sáng mai đi mua hoa quả'));assert.match(a.reply,/Đã hẹn nhắc/);assert.match(a.reply,/17\/10\/2026 09:00/);
});
test('reported request saves exactly 08:00 and no conversational AI is called',async()=>{
 const now=Date.parse('2026-10-28T09:01:00+07:00'),s=new Store(),r=new Reminders(s,{now:()=>now});let aiCalls=0;const sent=[];
 const inbox=new DurableInbox(s,{now:()=>now,extensionsEnabled:true,aiEnabled:true,handleExtension:async e=>({status:'ready',reply:await r.handle(e)}),isReminderFollowup:e=>r.hasFollowup(e),nextReminder:()=>r.next()});
 const ai={configured:true,reserve:async()=>({allowed:true}),generate:async()=>{aiCalls++;throw Error('must-not-use-ai');}},sender={send:async v=>{sent.push(v);return {status:'sent'};}};
 const e=event('nhắc lịch 8h 7/11 đi ăn hỏi sơn');await inbox.enqueue(e);await inbox.drain(sender,ai);
 assert.equal(aiCalls,0);assert.equal(sent.length,1);assert.match(sent[0].text,/07\/11\/2026 08:00/);assert.match(sent[0].text,/Đã hẹn nhắc: đi ăn hỏi sơn/);
 const rows=await s.list({prefix:'reminder:'});assert.equal(rows.size,1);assert.equal([...rows.values()][0].due,Date.parse('2026-11-07T08:00:00+07:00'));
 assert.equal((await inbox.enqueue(e)).status,'duplicate');assert.equal(rows.size,1);
});
test('storage failure cannot produce a scheduled confirmation',async()=>{
 const s=new Store(),put=s.put.bind(s);s.put=async(k,v)=>{if(k.startsWith('reminder:'))throw Error('fake-storage-unavailable');return put(k,v);};
 const r=new Reminders(s,{now:()=>NOW});await assert.rejects(r.handle(event('Nhắc tôi sau 1 phút uống nước')),/fake-storage-unavailable/);
 assert.equal((await s.list({prefix:'reminder:'})).size,0);assert.equal((await s.list({prefix:'reminder-event:'})).size,0);
});
