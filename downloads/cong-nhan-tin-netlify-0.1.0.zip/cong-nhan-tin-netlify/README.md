# Cổng nhận webhook Netlify 0.1.0

Chỉ dùng khi đã tái hiện Cloudflare 1010 trước Worker với yêu cầu Java. Đã kiểm tin Zalo thật ngày 14/10/2026; từng bộ khách vẫn cần một tin thật để nghiệm thu.

Zalo → Netlify /webhook → Worker của chính khách → xử lý/lưu lịch sử/gửi Zalo.
Netlify nhận nội dung HTTP trong lúc chuyển tiếp. Cổng không lưu lịch sử hoặc ghi khóa/nội dung vào log. Free có hạn mức: https://www.netlify.com/pricing/.

## AI thực hiện
1. Đọc tiến độ và xác định origin HTTPS đúng Worker của bộ khách, không có /webhook. Chạy node check-local.mjs. Không lấy URL mẫu làm cấu hình thật.
2. Dùng CLI Netlify chính thức từ npm; chủ đăng nhập Netlify Free và tự Authorize khi có yêu cầu. Kiểm tài khoản rồi tạo một project riêng, không dùng lại project của bộ khác.
3. Đặt BOT_WORKER_ORIGIN là origin Worker đúng bộ khách, scope functions/context production. Đây là địa chỉ công khai, không phải key. Không sao chép ZALO_BOT_TOKEN, WEBHOOK_SECRET hoặc OpenAI key lên Netlify.
4. Triển khai thư mục public VÀ netlify/functions theo netlify.toml bằng CLI. Không chỉ kéo thả public lên web vì sẽ thiếu function. Khi deploy, dùng --env BOT_WORKER_ORIGIN=<origin-thật> để cấu hình ngay lần đó; lưu env bằng env:set cho những lần sau.
5. CLI có thể tạo Production private. Kiểm trên Netlify, xuất bản Production bằng Make public để Zalo gọi được, giữ preview private. Trang public chỉ là cổng nhận, không chứa khóa hoặc lịch sử. Worker vẫn xác thực X-Bot-Api-Secret-Token. Không đổi bảo vệ tài nguyên khác.
6. Kiểm với Java/1.8.0_192: GET /health phải tới Worker; POST /webhook thiếu khóa và khóa giả phải bị403. Lỗi phải sửa trước khi nhờ chủ gửi tin. Không in khóa, body hoặc ID thật. Cổng không chuyển hướng, không làm proxy tới URL do người nhắn chọn, giới hạn body1MiB.
7. Báo URL Netlify /webhook để chủ tự thay Webhook URL trên Zalo, giữ nguyên Secret Token. Mở nhật ký đúng Worker trước một tin mới, kiểm webhook/hàng đợi/phản hồi. Ghi tiến độ bằng kết quả thực tế, không coi health là nghiệm thu Zalo.

Không sửa runtime/secrets/dữ liệu/cờ của Worker trong bước thêm cổng. Portal/media vẫn dùng đường Worker hiện có. Cổng này chỉ chuyển /health và /webhook.
Nguồn: https://docs.netlify.com/build/functions/api/ và https://cli.netlify.com/commands/deploy/.
