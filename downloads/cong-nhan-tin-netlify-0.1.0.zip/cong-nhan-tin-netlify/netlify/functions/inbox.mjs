// Webhook relay only. Bot processing, authentication and data stay on Cloudflare.
export function makeHandler({ origin, fetcher = fetch }) {
  const base = new URL(origin);
  if (base.protocol !== 'https:' || !/^[a-z0-9-]+\.[a-z0-9-]+\.workers\.dev$/.test(base.hostname)
      || base.port || base.username || base.password || base.pathname !== '/' || base.search || base.hash) {
    throw new Error('Expected a Worker origin, without path or credentials');
  }
  return async function handle(request) {
    const path = new URL(request.url).pathname;
    if (!['/health', '/webhook'].includes(path)) return new Response(null, { status: 404 });
    const expectedMethod = path === '/webhook' ? 'POST' : 'GET';
    if (request.method !== expectedMethod) return new Response(null, { status: 405 });
    const headers = new Headers({ 'user-agent': 'Mozilla/5.0 ZaloInboxRelay/1.0' });
    let body;
    if (path === '/webhook') {
      const secret = request.headers.get('x-bot-api-secret-token');
      if (!secret) return new Response(null, { status: 403 });
      headers.set('x-bot-api-secret-token', secret);
      headers.set('content-type', request.headers.get('content-type') || 'application/json');
      if (Number(request.headers.get('content-length')) > 1024 * 1024) return new Response(null, { status: 413 });
      try {
        const reader = request.body?.getReader();
        const chunks = [];
        let size = 0;
        if (reader) {
          for (;;) {
            const { done, value } = await reader.read();
            if (done) break;
            size += value.byteLength;
            if (size > 1024 * 1024) {
              await reader.cancel();
              return new Response(null, { status: 413 });
            }
            chunks.push(value);
          }
        }
        body = new Uint8Array(size);
        let position = 0;
        for (const chunk of chunks) { body.set(chunk, position); position += chunk.byteLength; }
      } catch { return new Response(null, { status: 400 }); }
    }
    try {
      const response = await fetcher(new URL(path, base), {
        method: expectedMethod, headers, body, redirect: 'manual', signal: AbortSignal.timeout(8000)
      });
      // Never forward the credential to a redirected destination or conceal delivery errors.
      if (response.status >= 300 && response.status < 400) return new Response(null, { status: 502 });
      return new Response(response.body, {
        status: response.status,
        headers: { 'content-type': response.headers.get('content-type') || 'application/json', 'cache-control': 'no-store' }
      });
    } catch { return new Response(null, { status: 502 }); }
  };
}

export default async function handler(request) {
  const origin = process.env.BOT_WORKER_ORIGIN;
  if (!origin) return new Response(null, { status: 503 });
  try { return await makeHandler({ origin })(request); }
  catch { return new Response(null, { status: 503 }); }
}

export const config = { path: ['/webhook', '/health'] };
