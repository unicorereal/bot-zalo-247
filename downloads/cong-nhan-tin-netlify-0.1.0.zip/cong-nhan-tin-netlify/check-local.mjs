import assert from 'node:assert/strict';
import { makeHandler } from './netlify/functions/inbox.mjs';
const origin = 'https://sample-bot.sample-account.workers.dev';
let calls = 0;
let observed;
const mock = async (url, options) => {
  calls++;
  observed = { url: String(url), options };
  return Response.json({ accepted: true });
};
const handler = makeHandler({ origin, fetcher: mock });
const request = (path, opts = {}) => new Request('https://sample.netlify.app' + path, opts);
const payload = '{"event_name":"message","message":{"text":"Tiếng Việt giả kiểm"}}';
const post = (secret = 'FAKE-test-only') => ({ method: 'POST', headers: {
  'x-bot-api-secret-token': secret, 'content-type': 'application/json', 'user-agent': 'Java/1.8.0_192',
  authorization: 'FAKE-not-forwarded'
}, body: payload });
assert.equal((await handler(request('/webhook', post()))).status, 200);
assert.equal(observed.url, origin + '/webhook');
assert.equal(new TextDecoder().decode(observed.options.body), payload);
assert.equal(observed.options.headers.get('x-bot-api-secret-token'), 'FAKE-test-only');
assert.equal(observed.options.headers.has('authorization'), false);
assert.match(observed.options.headers.get('user-agent'), /^Mozilla/);
assert.equal(observed.options.redirect, 'manual');
const before = calls;
assert.equal((await handler(request('/webhook', post('')))).status, 403);
assert.equal((await handler(request('/webhook'))).status, 405);
assert.equal((await handler(request('/unknown', post()))).status, 404);
assert.equal((await handler(request('/webhook', { ...post(), body: 'x'.repeat(1024 * 1024 + 1) }))).status, 413);
assert.equal(calls, before);
assert.equal((await handler(request('/health?url=https://example.com'))).status, 200);
assert.equal(observed.url, origin + '/health');
for (const status of [403, 500, 503]) {
  const failedWorker = makeHandler({ origin, fetcher: async () => new Response(null, { status }) });
  assert.equal((await failedWorker(request('/webhook', post()))).status, status);
}
const redirect = makeHandler({ origin, fetcher: async () => new Response(null, { status: 302, headers: { location: 'https://example.com' } }) });
assert.equal((await redirect(request('/webhook', post()))).status, 502);
const unavailable = makeHandler({ origin, fetcher: async () => { throw new Error('unavailable'); } });
assert.equal((await unavailable(request('/webhook', post()))).status, 502);
for (const invalid of ['http://sample.workers.dev', 'https://example.com', origin + '/webhook', 'https://user:pass@sample.example.workers.dev']) {
  assert.throws(() => makeHandler({ origin: invalid }));
}
console.log('Local relay checks passed: exact payload/auth, fixed target, no redirect, bounded input and truthful errors. No real messages or credentials used.');
