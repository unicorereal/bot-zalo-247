import { memoryCommand } from './tom-tat-chat.mjs';
import { FIXED_REPLY } from './gui-tin.mjs';
import { AI_FAILURE } from './ai-luna.mjs';
import { recentHistory, relevantHistory } from './bo-nho-chat.mjs';
import { productReply } from './kho-san-pham.mjs';
import { isCatalogCommand, identityReply } from './quan-ly-kho.mjs';
import { aiFailureReply } from './van-hanh-ai.mjs';
import { eventAgeReason, pruneChatRows, retentionDue, receiptCount } from './luu-du-lieu.mjs';
import { conversationRows, GROUP_ADMIN_REPLY, GROUP_ACTIVATED_REPLY, isGroupActivation } from './nhom-chat.mjs';
import { missingQuoteRequest, MISSING_QUOTE_REPLY } from './thieu-trich-dan.mjs';
import { IMAGE_DEFAULT_QUESTION, IMAGE_FAILURE_REPLY, imageFailureReply } from './doc-anh.mjs';
import { extensionCommand, relevantMedia } from './mo-rong-du-lieu.mjs';
import { isPrivateAccessCommand } from './quyen-chat-rieng.mjs';

// Storage adapter must supply atomic transaction, durable get/put/list and alarms.
// One object per chat. Text is retained only in explicit AI mode; no secrets/error bodies.
export class DurableInbox {
  constructor(storage, { now = Date.now, maxRecords = 1000, aiEnabled = false, memoryEnabled = false,
    knowledgeEnabled = false, catalog = null, catalogAdminEnabled = false,
    manageCatalog = null, loadCatalog = null, retentionEnabled = false, historyRetrievalEnabled = false,
    allowGroup = () => false, canActivateGroup = () => false, activateGroup = null, imageEnabled = false,
    memory = null, extensionsEnabled = false, groupImageEnabled = false, handleExtension = null, handleResource = null, isResourceFollowup = null, isReminderFollowup = null, nextReminder = null, refreshResource = null, stageUpload = null,
    privateAccessEnabled=false,allowPrivate=()=>true,handlePrivateAccess=null } = {}) {
    this.storage = storage; this.memory = memory;
    Object.assign(this,{privateAccessEnabled,allowPrivate,handlePrivateAccess});
    this.now = now;
    this.maxRecords = maxRecords;
    this.aiEnabled = aiEnabled;
    this.memoryEnabled = memoryEnabled;
    this.historyRetrievalEnabled = historyRetrievalEnabled === true;
    this.knowledgeEnabled = knowledgeEnabled;
    this.catalog = catalog;
    this.catalogAdminEnabled = catalogAdminEnabled;
    this.manageCatalog = manageCatalog;
    this.loadCatalog = loadCatalog;
    this.retentionEnabled = retentionEnabled === true;
    this.allowGroup = allowGroup;
    this.canActivateGroup = canActivateGroup;
    this.activateGroup = activateGroup;
    this.imageEnabled = imageEnabled === true;
    Object.assign(this,{extensionsEnabled,groupImageEnabled,handleExtension,handleResource,isResourceFollowup,isReminderFollowup,nextReminder,refreshResource,stageUpload});
  }
  async schedule(rows, sendEnabled = true) {
    const pending = sendEnabled ? [...rows.values()].filter(r => ['queued', 'processing'].includes(r.status)).map(r => r.due) : [];
    const cleanup = this.retentionEnabled ? [...rows.values()].map(retentionDue).filter(Number.isFinite) : [];
    const due = [...pending, ...cleanup];
    if(sendEnabled && this.extensionsEnabled && this.nextReminder){const next=await this.nextReminder();if(Number.isFinite(next))due.push(next);}
    if (due.length) await this.storage.setAlarm(Math.max(this.now() + 1, Math.min(...due)));
  }
  async maintain({ sendEnabled = true } = {}) {
    if (!this.retentionEnabled) return { compacted: 0, removed: 0 };
    return this.storage.transaction(async () => {
      const rows = await this.storage.list({ prefix: 'tin:' });
      const report = await pruneChatRows(this.storage, rows, this.now());
      await this.schedule(rows, sendEnabled);
      return report;
    });
  }
  async enqueue(event) {
    if(!await this.allowPrivate(event))return {status:'ignored',reason:'private-user-not-allowed'};
    const image = event.kind === 'image';
    const attachment=['voice','upload'].includes(event.kind);
    if(attachment&&(!this.extensionsEnabled||!this.aiEnabled))return {status:'ignored',reason:'attachment-not-enabled'};
    if (image && (!this.imageEnabled || !this.aiEnabled || event.chatType === 'GROUP'&&!this.groupImageEnabled))
      return { status:'ignored', reason:'image-not-enabled' };
    const activation = event.chatType === 'GROUP' && this.canActivateGroup(event) === true;
    if (event.chatType === 'GROUP' && ((!activation && !await this.allowGroup(event.chatId)) ||
      typeof event.senderId !== 'string' || !event.senderId || event.senderId.length > 256))
      return { status: 'ignored', reason: 'group-not-allowed' };
    return this.storage.transaction(async () => {
      if (this.retentionEnabled) {
        const reason = eventAgeReason(event.eventAt, this.now());
        if (reason) return { status: 'ignored', reason };
      }
      const key = `tin:${event.key}`;
      const previous = await this.storage.get(key);
      if (previous) {
        await this.schedule(await this.storage.list({ prefix: 'tin:' }));
        return { status: 'duplicate', delivery: previous.status };
      }
      const rows = await this.storage.list({ prefix: 'tin:' });
      if (this.retentionEnabled) await pruneChatRows(this.storage, rows, this.now());
      if ((this.retentionEnabled ? receiptCount(rows) : rows.size) >= this.maxRecords) {
        await this.schedule(rows); return { status: 'capacity' };
      }
      const record = { chatId: event.chatId, status: 'queued', attempts: 0, due: this.now(), created: this.now() };
      if(this.extensionsEnabled||this.memory||this.privateAccessEnabled)record.senderId=event.senderId;
      if (event.chatType === 'GROUP') { record.chatType = 'GROUP'; record.senderId = event.senderId; }
      if (this.retentionEnabled) record.eventAt = event.eventAt;
      const memCommand = !image&&!attachment&&memoryCommand(event.text);
      const accessCommand=this.privateAccessEnabled&&!image&&!attachment&&isPrivateAccessCommand(event.text);
      if(accessCommand){record.accessCommand=true;record.accessOrigin=event.accessOrigin;record.senderId=event.senderId;}
      if(memCommand)record.memoryCommand=true;
      const extraCommand = this.extensionsEnabled&&!image&&!attachment&&(extensionCommand(event.text)||await this.isReminderFollowup?.(event)||await this.isResourceFollowup?.(event));
      const adminCommand = !image && !attachment && isCatalogCommand(event.text);
      if (adminCommand && (this.catalogAdminEnabled||/^\/id(?:\s|$)/i.test(event.text.trim())) && typeof event.senderId === 'string') record.senderId = event.senderId;
      if ((this.aiEnabled || adminCommand || extraCommand || memCommand || accessCommand) && typeof event.text === 'string') {
        record.ai = { status: 'pending' };
        if (event.text.trim() && event.text.length <= 1000) record.text = event.text;
        else record.ai = { status: 'failed', reply: AI_FAILURE };
      }
      if(extraCommand)record.extensionCommand=true;
      if(attachment){record.mediaKind=event.kind;record.mediaUrl=event.mediaUrl;record.uploadId=event.uploadId;}
      if (image) {
        record.mediaKind = 'image';
        record.senderId = event.senderId;
        if (!event.text?.trim()) {
          record.text = IMAGE_DEFAULT_QUESTION;
          record.ai = { status:'pending' };
        }
        if (record.ai?.status === 'pending') record.photo = event.photo;
        else delete record.text;
      } else if (activation) {
        await this.activateGroup(event);
        delete record.text; // Enrollment is not conversational memory or an AI request.
        record.ai = { status: 'ready', reply: GROUP_ACTIVATED_REPLY };
      } else if (event.chatType === 'GROUP' && isGroupActivation(event.text)) {
        delete record.text;
        record.ai = { status: 'ready', reply: 'Chỉ người sở hữu bot đã được cấu hình mới có quyền bật nhóm. Chưa thay đổi quyền nhóm.' };
      } else if (record.ai?.status === 'pending' && !adminCommand && !extraCommand && !attachment && missingQuoteRequest(event.text)) {
        delete record.text; // Missing-reference prompts must not pollute later memory.
        record.ai = { status: 'ready', reply: MISSING_QUOTE_REPLY };
      }
      if(event.kind==='upload'&&this.stageUpload)await this.stageUpload(event.uploadId,event.uploadPayload);
      await this.storage.put(key, record);
      rows.set(key, record);
      await this.schedule(rows);
      return { status: 'queued' };
    });
  }
  async drain(sender, ai) {
    if (this.running) return this.running;
    this.running = this.runOnce(sender, ai);
    try { return await this.running; }
    finally { this.running = null; }
  }
  async runOnce(sender, ai) {
    if (this.retentionEnabled) await this.maintain();
    // Alarms are at-least-once. A processing record from a previous invocation
    // is ambiguous: never automatically resend it after a restart.
    const claimed = await this.storage.transaction(async () => {
      const rows = await this.storage.list({ prefix: 'tin:' });
      let selected;
      // Arrival time first, deterministic key only for equal timestamps.
      for (const [key, row] of [...rows].sort(([ka,a],[kb,b]) => a.created - b.created || ka.localeCompare(kb))) {
        if (row.status === 'processing' && row.due <= this.now()) {
          row.status = 'uncertain';
          delete row.photo;
          delete row.mediaUrl;delete row.uploadId;
          await this.storage.put(key, row);
        } else if (!selected && row.status === 'queued' && row.due <= this.now()) {
          if(!await this.allowPrivate(row)){row.status='uncertain';delete row.photo;delete row.mediaUrl;delete row.uploadId;delete row.text;await this.storage.put(key,row);continue;}
          // Disabling/removing a group does not replay its queued messages when re-enabled.
          if (row.chatType === 'GROUP' && !await this.allowGroup(row.chatId)) {
            row.status = 'uncertain'; delete row.photo;delete row.mediaUrl;delete row.uploadId;await this.storage.put(key, row); continue;
          }
          if (this.retentionEnabled && eventAgeReason(row.eventAt, this.now())) {
            row.status = 'uncertain'; delete row.photo;delete row.mediaUrl;delete row.uploadId;await this.storage.put(key, row); continue;
          }
          const imageUrl = row.photo, mediaUrl=row.mediaUrl,uploadId=row.uploadId;
          delete row.photo; // Remove URL before I/O; a restart never downloads or generates again.
          delete row.mediaUrl;delete row.uploadId;
          row.status = 'processing'; row.attempts++; row.due = this.now() + (row.mediaKind==='upload'?720000:row.mediaKind==='voice'?120000:30000);
          await this.storage.put(key, row);
          const context = conversationRows(rows, row);
          const mediaMemory=this.extensionsEnabled&&this.memoryEnabled?relevantMedia(context,row,this.now()):[];
          selected = { key, row, imageUrl, mediaUrl,uploadId,mediaMemory, catalogHistory: this.memoryEnabled ? recentHistory(context, row.chatId, this.now()) : [],
            history: this.memoryEnabled && row.mediaKind !== 'image' ? (this.historyRetrievalEnabled
              ? relevantHistory(context, row.chatId, this.now(), row.text)
              : recentHistory(context, row.chatId, this.now())) : [] };
        }
      }
      await this.schedule(rows); // Watchdog committed before external I/O.
      return selected;
    });
    if (!claimed) return;
    if (claimed.row.ai?.status === 'pending') {
      // Commit AI processing before reserving budget or making a paid request.
      claimed.row.ai = { status: 'processing' };
      await this.storage.put(claimed.key, claimed.row);
      let generated = { status: 'failed', reason: 'missing-ai-config' };
      let knowledgeReply = null;
      let resource=null;if(this.extensionsEnabled&&this.handleResource&&!claimed.row.mediaKind&&!claimed.row.accessCommand&&!claimed.row.memoryCommand){try{resource=await this.handleResource({...claimed.row,key:claimed.key});}catch{resource={status:'ready',reply:'Chưa tìm được ảnh/link lúc này. Hãy báo người quản lý kiểm tra, chưa cần gửi lại ảnh.'};}}
      if(resource){generated=resource;knowledgeReply=resource.reply;}else if(claimed.row.accessCommand){
        try{knowledgeReply=await this.handlePrivateAccess(claimed.row);}catch{knowledgeReply='Chưa mở được trang quản lý. Người cài cần kiểm cấu hình.';}
      }else if(identityReply(claimed.row)!==null){
        knowledgeReply=identityReply(claimed.row);
      }else if(claimed.row.memoryCommand){
        knowledgeReply=this.memory?await this.memory.command(claimed.row):'Bộ nhớ tóm tắt chưa được bật. Chưa thay đổi dữ liệu.';
      }else if(claimed.row.extensionCommand){
        try{generated=await this.handleExtension({...claimed.row,key:claimed.key});knowledgeReply=generated?.reply??'Chưa thực hiện được lệnh.';}catch{knowledgeReply='Chưa thực hiện được lệnh mở rộng. Chưa xác nhận thay đổi; người quản lý cần kiểm tra mã lỗi.';}
      }else if (!claimed.row.mediaKind && isCatalogCommand(claimed.row.text)) {
        if (claimed.row.chatType === 'GROUP') knowledgeReply = GROUP_ADMIN_REPLY;
        else if (!this.catalogAdminEnabled) knowledgeReply = 'Chức năng quản lý kho chưa được bật. Chưa thay đổi dữ liệu.';
        else try {
          knowledgeReply = await this.manageCatalog({ key: claimed.key, senderId: claimed.row.senderId,
            chatId: claimed.row.chatId, text: claimed.row.text, ...(this.retentionEnabled ? { eventAt: claimed.row.eventAt } : {}) });
          if (typeof knowledgeReply !== 'string') throw Error('invalid-manager-reply');
        } catch { knowledgeReply = 'Chưa thực hiện được thao tác quản lý kho. Anh/chị vui lòng kiểm tra kết nối; không gửi lại thao tác khi chưa biết kết quả.'; }
      } else if (!claimed.row.mediaKind && this.knowledgeEnabled && typeof claimed.row.text === 'string') {
        let catalog = this.catalog;
        if (this.loadCatalog) {
          try { catalog = await this.loadCatalog(); } catch { catalog = null; }
        }
        knowledgeReply = productReply(claimed.row.text, claimed.catalogHistory, catalog);
      }
      if (knowledgeReply !== null) generated = { ...generated, status: 'ready', reply: knowledgeReply };
      else if (this.aiEnabled && ai?.configError === 'invalid-ai-key-format')
        generated = { status: 'failed', reason: 'invalid-ai-key-format' };
      else if (this.aiEnabled && ai?.configured && typeof claimed.row.text === 'string') {
        try {
          const allocation = await ai.reserve(claimed.key, { eventAt: claimed.row.eventAt,chatType:claimed.row.chatType==='GROUP'?'GROUP':'PRIVATE' });
          if (!allocation.allowed) generated = { status:'failed', reason:allocation.reason ?? 'trial-limit' };
          else if (['voice','upload'].includes(claimed.row.mediaKind)) {
            generated=typeof ai.processAttachment==='function'?await ai.processAttachment(claimed):{status:'failed',reason:'attachment-not-enabled'};
          }else if (claimed.row.mediaKind === 'image') {
            const loaded = this.imageEnabled && typeof ai.loadImage === 'function'
              ? await ai.loadImage(claimed.imageUrl,{senderId:claimed.row.senderId}) : { status:'failed' };
            generated = loaded?.status === 'ready'
              ? await ai.generate(claimed.row.text, { ...(ai.context?await ai.context(claimed.row):{}), image:loaded.dataUrl, history:[] })
              : { status:'ready', reply:imageFailureReply(loaded) };
            if(loaded?.status==='ready'&&generated?.status==='ready'&&this.extensionsEnabled)claimed.row.mediaSummary=generated.reply;
          } else generated = await ai.generate(claimed.row.text, { ...(ai.context?await ai.context(claimed.row):{}),history:claimed.history,memorySummary:this.memory?await this.memory.read(claimed.row):'',...(this.extensionsEnabled?{mediaMemory:claimed.mediaMemory}:{}) });
        } catch { generated = { status: 'uncertain', reason: 'ai-state-or-transport' }; }
      }
      claimed.row.ai = generated?.status === 'ready' && typeof generated.reply === 'string' &&
        generated.reply.trim() && generated.reply.length <= 1900
        ? { status: 'ready', reply: generated.reply }
        : { status: generated?.status === 'uncertain' ? 'uncertain' : 'failed',
          reply: aiFailureReply(generated?.reason, AI_FAILURE, claimed.row.chatType) };
      if(generated?.status==='ready'&&typeof generated.photo==='string')claimed.row.ai.photo=generated.photo;
      if(generated?.resourceCode)claimed.row.ai.resourceCode=generated.resourceCode;
      if(generated?.mediaSummary&&typeof generated.mediaSummary==='string'&&generated.mediaSummary.length<=1900)claimed.row.mediaSummary=generated.mediaSummary;
      if(claimed.row.extensionCommand||claimed.row.memoryCommand||claimed.row.accessCommand)delete claimed.row.text;
      // If this write fails, no Zalo send follows; watchdog recovery never calls AI again.
      await this.storage.put(claimed.key, claimed.row);
    }
    let result;
    try {
      let output=claimed.row.ai;
      if(output?.resourceCode&&this.refreshResource)output=await this.refreshResource(output.resourceCode,claimed.row);
      result = await this.allowPrivate(claimed.row)?await sender.send({ chat_id: claimed.row.chatId, text: output?.reply ?? FIXED_REPLY,...(output?.photo?{photo:output.photo}:{}) }):{status:'uncertain'};
    }
    catch { result = { status: 'uncertain' }; }
    await this.storage.transaction(async () => {
      const row = await this.storage.get(claimed.key);
      if (row.status !== 'processing') return;
      row.status = ['sent', 'rejected', 'uncertain'].includes(result?.status) ? result.status : 'uncertain';
      if (row.status === 'rejected' && row.attempts < 2) { row.status = 'queued'; row.due = this.now() + 5000; }
      await this.storage.put(claimed.key, row);
      await this.schedule(await this.storage.list({ prefix: 'tin:' }));
    });
    if(this.memory)await this.memory.schedule();
  }
}
