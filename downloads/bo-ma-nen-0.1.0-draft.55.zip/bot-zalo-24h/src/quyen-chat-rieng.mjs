import { adminIds } from './quan-ly-kho.mjs';
import { ReferenceStore } from './kho-tham-khao.mjs';
export const PRIVATE_ACCESS_NAME=JSON.stringify(['PRIVATE-ACCESS','v1']);
export const isPrivateAccessCommand=text=>typeof text==='string'&&/^\/(?:quyenrieng|nguon)(?:\s|$)/i.test(text.trim());
const validId=id=>typeof id==='string'&&id.length>0&&id.length<=256&&!/[\x00-\x20]/.test(id);
const digest=async value=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value))),n=>n.toString(16).padStart(2,'0')).join('');
export const privateAccessService=env=>env.INBOX.get(env.INBOX.idFromName(PRIVATE_ACCESS_NAME));
export async function privateAllowed(env,event){
 if(event.chatType==='GROUP'||env.PRIVATE_ACCESS_ENABLED!=='true')return true;
 const r=await privateAccessService(env).fetch(new Request('https://internal/private-access/check',{method:'POST',body:JSON.stringify({senderId:event.senderId,text:event.text,kind:event.kind??event.mediaKind??'text'})}));
 if(!r.ok)throw Error('private-access-unavailable');return (await r.json()).allowed===true;
}
export class PrivateAccess{
 constructor(storage,env,{now=Date.now}={}){this.storage=storage;this.env=env;this.now=now;this.references=new ReferenceStore(storage,{now});}
 owner(id){return adminIds(this.env.CATALOG_ADMIN_IDS_JSON).includes(id);}
 async policy(){const p=await this.storage.get('private-access:policy')??{restricted:false,ids:[],revision:0};
  if(typeof p.restricted!=='boolean'||!Array.isArray(p.ids)||p.ids.length>100||p.ids.some(id=>!validId(id))||new Set(p.ids).size!==p.ids.length||!Number.isSafeInteger(p.revision)||p.revision<0)throw Error('private-access-corrupt');return p;}
 async command(event){
  if(event.chatType==='GROUP'||!this.owner(event.senderId))return 'Chỉ chủ bot được mở trang giới hạn chat riêng. Dùng lệnh trong chat riêng bằng tài khoản quản lý.';
  if(!['/quyenrieng','/nguon'].includes(event.text.trim().toLowerCase()))return 'Gửi /quyenrieng hoặc /nguon trong chat riêng để mở trang quản lý.';
  if(event.text.trim().toLowerCase()==='/nguon'&&this.env.REFERENCE_SQLITE_ENABLED!=='true')return 'Nguồn SQLite Bài 7 chưa được bật. Người cài cần cập nhật cấu hình trước.';
  let origin;try{origin=new URL(event.accessOrigin);if(origin.protocol!=='https:'||origin.username||origin.password||origin.pathname!=='/'||origin.search||origin.hash)throw Error();}catch{return 'Chưa có địa chỉ trang quản lý hợp lệ. Người cài cần kiểm cấu hình.';}
  const token=Array.from(crypto.getRandomValues(new Uint8Array(32)),n=>n.toString(16).padStart(2,'0')).join('');
  await this.storage.put('private-access:session',{hash:await digest(token),owner:event.senderId,expires:this.now()+15*60*1000});
  return 'Mở trang quản lý chat riêng và nạp nguồn dữ liệu. Link dùng trong 15 phút, giữ riêng; gửi /quyenrieng hoặc /nguon để lấy link mới:\n'+origin.origin+'/quyen-rieng#'+token;
 }
 async handle(request){
  const path=new URL(request.url).pathname;
  const body=await request.json();
  if(path==='/private-access/reference-read'&&this.env.REFERENCE_SQLITE_ENABLED==='true')return Response.json(await this.references.current());
  if(path==='/private-access/check'){
   const p=await this.policy();return Response.json({allowed:validId(body.senderId)&&(this.owner(body.senderId)||!p.restricted||p.ids.includes(body.senderId)||body.kind==='text'&&body.text?.trim().toLowerCase()==='/id')});
  }
  if(path==='/private-access/command')return Response.json({reply:await this.command(body)});
  if(path!=='/private-access/api')return new Response(null,{status:404});
  const token=request.headers.get('Authorization')?.replace(/^Bearer /,'');
  const session=await this.storage.get('private-access:session');
  if(!/^[a-f0-9]{64}$/.test(token??'')||!session||session.expires<=this.now()||!this.owner(session.owner)||session.hash!==await digest(token))return Response.json({error:'Link đã hết hạn hoặc không hợp lệ. Gửi /quyenrieng trong chat riêng để mở lại.'},{status:403});
  if(body.action==='read')return Response.json({...await this.policy(),referenceEnabled:this.env.REFERENCE_SQLITE_ENABLED==='true'});
  if(['source-read','source-draft','source-apply'].includes(body.action)){
    if(this.env.REFERENCE_SQLITE_ENABLED!=='true')return Response.json({error:'Nguồn SQLite chưa được bật ở Bài 7.'},{status:409});
    try{
      if(body.action==='source-read')return Response.json(await this.references.current());
      if(body.action==='source-draft')return Response.json(await this.references.draft(body.document,session.owner));
      return Response.json(await this.references.apply(body.id,session.owner));
    }catch{return Response.json({error:'Bản nạp chưa hợp lệ, đã hết hạn hoặc nguồn vừa được cập nhật. Tạo lại bản xem trước; chưa thay nguồn đang dùng.'},{status:409});}
  }
  if(body.action!=='save'||typeof body.restricted!=='boolean'||!Array.isArray(body.ids)||body.ids.length>100||body.ids.some(id=>!validId(id))||new Set(body.ids).size!==body.ids.length||!Number.isSafeInteger(body.revision))return Response.json({error:'Danh sách chưa hợp lệ. Mỗi dòng một ID, tối đa 100 người.'},{status:400});
  return this.storage.transaction(async()=>{
   const p=await this.policy();if(body.revision!==p.revision)return Response.json({error:'Cài đặt đã đổi. Tải lại trang trước khi lưu.'},{status:409});
   const next={restricted:body.restricted,ids:body.ids,revision:p.revision+1};await this.storage.put('private-access:policy',next);return Response.json(next);
  });
 }
}
export const privateAccessPage=()=>`<!doctype html><html lang="vi"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Ai được chat riêng với bot?</title><style>body{font:18px system-ui;max-width:650px;margin:40px auto;padding:20px;color:#16344b}button,textarea{font:inherit}button{padding:12px 18px;margin:8px 0;background:#176d69;color:white;border:0;border-radius:8px}textarea{box-sizing:border-box;width:100%;height:190px;padding:12px}label{display:block;margin:24px 0}#status{white-space:pre-wrap}button:disabled{opacity:.5}</style><h1>Ai được chat riêng với bot?</h1><p>Tắt giới hạn: mọi người nhắn được bot. Bật giới hạn: chỉ chủ bot và người trong danh sách được trả lời. Áp dụng cả khi người đó mở bot từ nhóm hoặc đường dẫn.</p><button id="toggle" disabled aria-pressed="false">Đang tải…</button><label>Người được phép (mỗi dòng một ID)<textarea id="ids" placeholder="Ví dụ: 123456789012345678 (thay bằng ID thật). Mỗi dòng một ID. Người đó gửi /id cho bot để lấy ID."></textarea></label><p>Chủ bot luôn được phép. Người chưa được phép vẫn dùng /id để biết ID của mình; các câu hỏi và ảnh của họ không được xử lý bằng AI. Cài đặt này không đổi quyền trong nhóm.</p><button id="save" disabled>Lưu cài đặt</button><p id="status" role="status"></p><section id="sources"><h2>Nạp đầy đủ nguồn tham khảo</h2><p>Chọn file JSON AI đã chuẩn bị. Nội dung được lưu trong SQLite của bot, không nhập vào Secret. Xem đầy đủ bản nạp và ai được tra cứu trước khi xác nhận. Áp dụng sẽ thay toàn bộ nguồn tham khảo cũ bằng bản mới; không đổi khóa, kho sản phẩm hoặc lịch sử chat.</p><p>Ví dụ: nguon-da-duyet.json do AI chuẩn bị.</p><input id="source-file" type="file" accept=".json,application/json"><button id="source-preview" disabled>Xem bản nạp</button><pre id="source-content" style="white-space:pre-wrap;overflow-wrap:anywhere"></pre><label><input id="source-confirm" type="checkbox" disabled> Tôi đã kiểm nội dung và đồng ý thay nguồn tham khảo bằng bản này.</label><button id="source-apply" disabled>Áp dụng nguồn cho bot</button><p id="source-status" role="status"></p></section><script src="/quyen-rieng.js"></script></html>`;
export const privateAccessScript=()=>`const token=location.hash.slice(1);history.replaceState(null,'',location.pathname);const toggle=document.getElementById('toggle'),ids=document.getElementById('ids'),save=document.getElementById('save'),status=document.getElementById('status');let state;function paint(){toggle.textContent=state.restricted?'Giới hạn đang BẬT — bấm để tắt':'Giới hạn đang TẮT — bấm để bật';toggle.setAttribute('aria-pressed',String(state.restricted));}async function api(data){const r=await fetch('/quyen-rieng-api',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+token},body:JSON.stringify(data)});const result=await r.json();if(!r.ok)throw Error(result.error||'Chưa lưu được.');return result;}toggle.onclick=()=>{state.restricted=!state.restricted;paint();status.textContent='Chưa lưu: bấm Lưu cài đặt để áp dụng.';};save.onclick=async()=>{save.disabled=true;toggle.disabled=true;try{state=await api({action:'save',restricted:state.restricted,ids:[...new Set(ids.value.split(/\\r?\\n/).map(s=>s.trim()).filter(Boolean))],revision:state.revision});paint();status.textContent=state.restricted?'Đã lưu: chỉ chủ và người trong danh sách được trả lời.':'Đã lưu: mọi người được chat riêng.';}catch(e){status.textContent=e.message;}finally{save.disabled=false;toggle.disabled=false;}};api({action:'read'}).then(s=>{state=s;document.getElementById('source-preview').disabled=!s.referenceEnabled;document.getElementById('source-status').textContent=s.referenceEnabled?'Chọn file rồi bấm Xem bản nạp.':'Phần nguồn sẽ được bật ở Bài 7.';ids.value=s.ids.join('\\n');paint();toggle.disabled=false;save.disabled=false;}).catch(e=>{status.textContent=e.message;});
const sourceFile=document.getElementById('source-file'),sourcePreview=document.getElementById('source-preview'),sourceContent=document.getElementById('source-content'),sourceConfirm=document.getElementById('source-confirm'),sourceApply=document.getElementById('source-apply'),sourceStatus=document.getElementById('source-status');let sourceDraft=null;
sourceFile.onchange=()=>{sourceDraft=null;sourceConfirm.checked=false;sourceConfirm.disabled=true;sourceApply.disabled=true;sourceContent.textContent='';};
sourceConfirm.onchange=()=>{sourceApply.disabled=!sourceDraft||!sourceConfirm.checked;};
sourcePreview.onclick=async()=>{sourcePreview.disabled=true;sourceDraft=null;sourceApply.disabled=true;sourceConfirm.checked=false;try{const file=sourceFile.files[0];if(!file)throw Error('Chọn file JSON trước.');if(file.size>160000)throw Error('File quá lớn. Nhờ AI chia nguồn đầy đủ; không cắt ý.');const value=JSON.parse(await file.text());const d=await api({action:'source-draft',document:value});sourceDraft=d;sourceContent.textContent=d.sources.map(x=>x.code+' — '+x.title+'\\nAi được tra cứu: '+(x.audience==='owner'?'Chỉ chủ bot':'Mọi người được phép dùng bot')+'\\n'+x.text).join('\\n\\n────────────────\\n\\n');sourceConfirm.disabled=false;sourceStatus.textContent='Bản nạp gồm '+d.sources.length+' mục. Chưa áp dụng: đọc nội dung, đánh dấu xác nhận rồi bấm Áp dụng.';}catch(e){sourceStatus.textContent=e.message;sourceConfirm.disabled=true;}finally{sourcePreview.disabled=false;}};
sourceApply.onclick=async()=>{if(!sourceDraft||!sourceConfirm.checked)return;sourceApply.disabled=true;try{const r=await api({action:'source-apply',id:sourceDraft.id});sourceDraft=null;sourceConfirm.disabled=true;sourceStatus.textContent='Đã lưu '+r.count+' mục đầy đủ vào SQLite. Quay lại Zalo gửi các câu kiểm AI đã chuẩn bị.';}catch(e){sourceStatus.textContent=e.message;sourceApply.disabled=false;}};
`;
