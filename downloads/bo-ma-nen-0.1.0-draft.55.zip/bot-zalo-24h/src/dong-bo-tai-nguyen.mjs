import {sha256} from './mo-rong-du-lieu.mjs';
const encoder=new TextEncoder();
export function validSyncRequest(value,now=Date.now()){
 return !!value&&value.schema===1&&/^[a-f0-9]{64}$/.test(value.id??'')&&/^[a-z0-9][a-z0-9-]{0,62}$/.test(value.target??'')&&typeof value.origin==='string'&&/^https:\/\/[a-z0-9.-]+$/.test(value.origin)&&Number.isSafeInteger(value.issued)&&Number.isSafeInteger(value.expires)&&value.issued<=now+30000&&value.expires>now&&value.expires-value.issued>0&&value.expires-value.issued<=900000&&value.publicKey?.kty==='RSA'&&value.publicKey.e==='AQAB'&&typeof value.publicKey.n==='string'&&value.publicKey.n.length===342&&!value.publicKey.d;
}
function b64(bytes){let out='';for(let i=0;i<bytes.length;i+=8192)out+=String.fromCharCode(...bytes.subarray(i,i+8192));return btoa(out);}
const aad=spec=>encoder.encode(JSON.stringify([spec.id,spec.target,spec.origin,spec.issued,spec.expires]));
export async function encryptResourceSnapshot(spec,state){
 const payload={schema:1,id:spec.id,target:spec.target,origin:spec.origin,revision:state.revision,at:Date.now(),items:[]};
 for(const item of state.resources)payload.items.push({item,expected:await sha256(JSON.stringify(item))});
 const raw=encoder.encode(JSON.stringify(payload));if(raw.length>140000)throw Error('snapshot-size');
 const key=await crypto.subtle.generateKey({name:'AES-GCM',length:256},true,['encrypt']),iv=crypto.getRandomValues(new Uint8Array(12)),publicKey=await crypto.subtle.importKey('jwk',spec.publicKey,{name:'RSA-OAEP',hash:'SHA-256'},false,['encrypt']);
 const wrapped=await crypto.subtle.encrypt({name:'RSA-OAEP'},publicKey,await crypto.subtle.exportKey('raw',key));const data=await crypto.subtle.encrypt({name:'AES-GCM',iv,additionalData:aad(spec)},key,raw);
 return {schema:1,id:spec.id,key:b64(new Uint8Array(wrapped)),iv:b64(iv),data:b64(new Uint8Array(data))};
}
export async function serveResourceSnapshot(request,spec,readState,now=Date.now()){
 const headers={'Cache-Control':'no-store','X-Content-Type-Options':'nosniff','Referrer-Policy':'no-referrer'};const url=new URL(request.url);
 if(!validSyncRequest(spec,now)||url.origin!==spec.origin||url.pathname!=='/tai-nguyen-sync/'+spec.id)return new Response(null,{status:404,headers});
 if(request.method!=='GET')return new Response(null,{status:405,headers});
 try{return Response.json(await encryptResourceSnapshot(spec,await readState()),{headers});}catch{return new Response(null,{status:503,headers});}
}
