import { memoryCommand } from './tom-tat-chat.mjs';
import { isCatalogCommand } from './quan-ly-kho.mjs';
// Select a bounded prompt window from existing durable records, without deleting data.
export function recentHistory(rows, chatId, now) {
  return [...rows.entries()].filter(([, r]) => r.chatId === chatId && !r.mediaKind && !r.extensionCommand && !r.memoryErased && !r.memoryCommand && !memoryCommand(r.text) && r.status === 'sent' &&
    r.ai?.status === 'ready' && typeof r.text === 'string' && !isCatalogCommand(r.text) && r.text.trim() && r.text.length <= 1000 &&
    typeof r.ai.reply === 'string' && r.ai.reply.trim() && r.ai.reply.length <= 1900 &&
    Number.isFinite(r.created) && r.created <= now && now - r.created <= 86400000)
    .sort(([ka, a], [kb, b]) => a.created - b.created || ka.localeCompare(kb))
    .slice(-3).flatMap(([, r]) => [
      { role: 'user', content: r.text }, { role: 'assistant', content: r.ai.reply }
    ]);
}

const DAY = 86400000;
const STOP = new Set('toi ban anh chi em minh muon can da vua la va thi cua cho giup nhe a nao gi bao nhieu nhu the hom nay truoc sau lai noi hoi nhac co khong sang'.split(' '));
function terms(text) {
  const normalized = text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd');
  const result = new Set((normalized.match(/[a-z0-9]+(?:-[a-z0-9]+)*/g) ?? []).filter(t => t.length > 1 && !STOP.has(t)));
  // Narrow topic bridge for the tested shopping use case, not a semantic search claim.
  if (/\b(ao|quan|vay|size)\b/.test(normalized) || /(?:^|\s)cỡ(?:\s|[?,.]|$)/i.test(text) ||
    /\bmau\s+(gi|nao)\b/.test(normalized)) result.add('topic-clothing');
  return result;
}

// Read-only local selection. No new storage, embedding API or extra paid request.
// Old assistant claims are deliberately omitted: they may contain stale prices or errors.
export function relevantHistory(rows, chatId, now, text) {
  if (typeof text !== 'string' || !Number.isFinite(now)) return [];
  const query = terms(text);
  const eligible = [...rows.entries()].filter(([, r]) => r.chatId === chatId && !r.mediaKind && !r.extensionCommand && !r.memoryErased && !r.memoryCommand && !memoryCommand(r.text) && r.status === 'sent' &&
    r.ai?.status === 'ready' && typeof r.text === 'string' && r.text.trim() && r.text.length <= 1000 &&
    !isCatalogCommand(r.text) && typeof r.ai.reply === 'string' && r.ai.reply.trim() && r.ai.reply.length <= 1900 &&
    Number.isFinite(r.created) && r.created <= now && now - r.created <= 30 * DAY);
  const order = ([ka, a], [kb, b]) => a.created - b.created || ka.localeCompare(kb);
  const ordered = eligible.sort(order);
  const scored = ordered.map((entry, index) => {
    let score = [...terms(entry[1].text)].filter(t => query.has(t)).length;
    // An explicit correction immediately after a matching turn belongs to that turn.
    // Do not infer corrections across intervening topics or more than one day.
    const previous = ordered[index - 1];
    const correction = /^(?:toi |minh |em |anh )?(?:doi|thay|chuyen|khong lay)\b/.test(
      entry[1].text.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '').replace(/đ/g, 'd'));
    if (!score && correction && previous && entry[1].created - previous[1].created <= DAY &&
      [...terms(previous[1].text)].some(t => query.has(t))) score = 1;
    return { entry, score };
  }).filter(v => v.score > 0).sort((a, b) => order(b.entry, a.entry));
  const selected = new Map(eligible.filter(([,r])=>now-r.created<=DAY).sort((a,b)=>order(b,a)).slice(0,12));
  for(const {entry} of scored){if(selected.size>=20)break;selected.set(...entry);const i=ordered.findIndex(e=>e[0]===entry[0]);for(const neighbour of [ordered[i-1],ordered[i+1]])if(neighbour&&selected.size<20&&Math.abs(neighbour[1].created-entry[1].created)<=DAY&&/^(?:tôi |mình |em |anh )?(?:đổi|thay|chuyển|không lấy|cái đó|cái này|nó |vậy )/i.test(neighbour[1].text))selected.set(...neighbour);}
  // Keep one recent turn for short continuations; remaining slots use recent delivered turns.
  for (const [key, r] of eligible.filter(([, r]) => now - r.created <= DAY).sort((a, b) => order(b, a))) {
    if (selected.size >= 20) break;
    selected.set(key, r);
  }
  return [...selected].sort(order).flatMap(([, r]) => [
    { role: 'user', content: r.text },
    { role: 'assistant', content: now - r.created > DAY
      ? 'Đây là lời khách trong lịch sử được chọn theo chủ đề; chưa xác nhận thành đơn hàng.' : r.ai.reply }
  ]);
}

export function boundedInput(text, history, instructions) {
  if (!Array.isArray(history) || history.length > 40 || history.length % 2 !== 0) return null;
  if (history.some((m, i) => !m || m.role !== (i % 2 ? 'assistant' : 'user') ||
    typeof m.content !== 'string' || !m.content.trim() || m.content.length > (i % 2 ? 1900 : 1000))) return null;
  const messages = history.map(m => ({ role: m.role, content: m.content }));
  if (!messages.length) return text; // Preserve E.1 request format when no context exists.
  messages.push({ role: 'user', content: text });
  const bytes = () => new TextEncoder().encode(instructions + JSON.stringify(messages)).length;
  while (messages.length > 1 && bytes() > 24000) messages.splice(0, 2);
  return bytes() <= 24000 ? (messages.length === 1 ? text : messages) : null;
}
