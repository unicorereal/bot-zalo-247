// Opt-in policy v1. Time windows are local product choices, not Zalo retry promises.
export const CONTENT_TTL = 30 * 86400000;
export const RECEIPT_TTL = CONTENT_TTL;
export const FUTURE_SKEW = 5 * 60000;
export const MAX_OPERATION_RECEIPTS = 10000;
export function eventAgeReason(eventAt, now) {
  if (!Number.isSafeInteger(now) || now <= 0) throw Error('invalid-retention-clock');
  if (!Number.isSafeInteger(eventAt) || eventAt <= 0) return 'invalid-event-time';
  if (eventAt > now + FUTURE_SKEW) return 'future-event';
  return now - eventAt > RECEIPT_TTL ? 'expired-event' : null;
}
export const terminal = row => ['sent', 'rejected', 'uncertain'].includes(row?.status);
const clock = value => Number.isSafeInteger(value) && value > 0;
export function retentionDue(row) {
  if (!terminal(row) || !clock(row.created)) return null;
  if (row.receipt === true) return clock(row.retentionUntil) ? row.retentionUntil : null;
  return row.created + CONTENT_TTL + 1;
}
// Called inside the owner's existing storage transaction. Never delete pending I/O.
export async function pruneChatRows(storage, rows, now) {
  let compacted = 0, removed = 0;
  for (const [key, row] of rows) {
    if (!terminal(row) || !clock(row.created) || row.created > now) continue;
    const timed = clock(row.eventAt) && row.eventAt <= row.created + FUTURE_SKEW;
    const until = timed ? Math.max(row.created, row.eventAt) + RECEIPT_TTL + 1 : null;
    if (timed && now >= until) {
      await storage.delete(key); rows.delete(key); removed++; continue;
    }
    if (row.receipt !== true && now > row.created + CONTENT_TTL) {
      const receipt = { status: row.status, created: row.created, receipt: true,
        ...(timed ? { eventAt: row.eventAt, retentionUntil: until } : { legacy: true }) };
      await storage.put(key, receipt); rows.set(key, receipt); compacted++;
    }
  }
  return { compacted, removed };
}
export function receiptCount(rows) {
  return [...rows.values()].filter(row => !(row?.receipt === true && row.legacy === true)).length;
}
export async function setEarlierAlarm(storage, next, now) {
  if (!Number.isFinite(next)) return;
  const current = await storage.getAlarm();
  const target = Math.max(now + 1, next);
  if (current === null || current <= now || target < current) await storage.setAlarm(target);
}
