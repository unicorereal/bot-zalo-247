// The deployed account owner pins a short-lived public key. No public write API.
export const resourceSyncRequest=null;
