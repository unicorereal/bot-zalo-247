export const RECOVERY_NAME=JSON.stringify(['RECOVERY','v1']);
export const SETTINGS=['MEMORY_ENABLED','HISTORY_RETRIEVAL_ENABLED','SUMMARY_ENABLED','IMAGE_ENABLED','VOICE_ENABLED','GROUP_ENABLED','GROUP_ACTIVATION_ENABLED','GROUP_IMAGE_ENABLED','PRIVATE_ACCESS_ENABLED','EXTENSIONS_ENABLED','KNOWLEDGE_ENABLED','CATALOG_MANAGED','CATALOG_ADMIN_ENABLED'];
export const recoveryStub=env=>(env.RAW_INBOX??env.INBOX).get((env.RAW_INBOX??env.INBOX).idFromName(RECOVERY_NAME));
export async function recoveryCall(env,action,body={}){const r=await recoveryStub(env).fetch(new Request('https://internal/recovery/internal',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,...body})}));const data=await r.json();if(!r.ok)throw Error(data.error??'recovery-unavailable');return data;}
export function generationEnv(env,generation='legacy',restoring=false){
 const raw=env.RAW_INBOX??env.INBOX;
 return {...env,...(env.DATA_SETTINGS??{}),...(generation!=='legacy'?{REFERENCE_SQLITE_ENABLED:'true'}:{}),RAW_INBOX:raw,DATA_GENERATION:generation,RESTORING:restoring,
  INBOX:{idFromName:name=>raw.idFromName(generation==='legacy'||name===RECOVERY_NAME?name:JSON.stringify(['DATA',generation,name])),get:id=>{
   const stub=raw.get(id);return {fetch:(request,init)=>{const req=new Request(request,init),headers=new Headers(req.headers);headers.set('X-Data-Generation',generation);headers.set('X-Data-Settings',JSON.stringify(env.DATA_SETTINGS??{}));if(restoring)headers.set('X-Recovery-Write','true');return stub.fetch(new Request(req,{headers}));}};
  }}
 };
}
