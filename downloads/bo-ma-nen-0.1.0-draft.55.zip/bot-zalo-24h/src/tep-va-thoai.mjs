import { publicUrl, cleanText } from './mo-rong-du-lieu.mjs';
import { readLimitedBody } from './webhook.mjs';
import { isAdts, remuxAdts } from './aac-m4a.mjs';
export const ZALO_VOICE_HOSTS=Object.freeze(['voice-aac-dl.zdn.vn','f2-voice-aac-dl.zdn.vn']);
export const FILE_MAX_BYTES=20*1024*1024;
export const VIDEO_AUDIO_MAX_BYTES=16*1024*1024;
export const VOICE_MAX_BYTES=8*1024*1024;
export const SOURCE_MAX_BYTES=4*1024*1024;
export const allowedFileNames=/\.(pdf|docx|txt|md|csv)$/i;
export async function readBytes(body,max){
  if(Number(body.headers.get('content-length'))>max)return null;
  const reader=body.body?.getReader();if(!reader)return null;
  const parts=[];let size=0;
  try{for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>max){await reader.cancel();return null;}parts.push(value);}}catch{return null;}
  const out=new Uint8Array(size);let at=0;for(const b of parts){out.set(b,at);at+=b.length;}return out;
}
export function bytes64(bytes){let s='';for(let p=0;p<bytes.length;p+=8192)s+=String.fromCharCode(...bytes.subarray(p,p+8192));return btoa(s);}
export function from64(value,max=FILE_MAX_BYTES){
  if(typeof value!=='string'||value.length>Math.ceil(max/3)*4||!value.length||value.length%4||/[^A-Za-z0-9+/=]/.test(value))return null;
  try{const raw=atob(value);if(raw.length>max)return null;const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return bytes;}catch{return null;}
}
export function documentType(filename,bytes){
  if(!cleanText(filename,120)||/[\\/\x00]/.test(filename)||!allowedFileNames.test(filename)||!bytes?.length||bytes.length>FILE_MAX_BYTES)return null;
  const head=new TextDecoder().decode(bytes.subarray(0,8));
  if(/\.pdf$/i.test(filename))return head.startsWith('%PDF-')?'application/pdf':null;
  if(/\.docx$/i.test(filename))return bytes[0]===80&&bytes[1]===75&&bytes[2]===3&&bytes[3]===4?'application/vnd.openxmlformats-officedocument.wordprocessingml.document':null;
  try{const text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);return !text.includes('\0')?'text/plain':null;}catch{return null;}
}
export function audioType(bytes,max=VOICE_MAX_BYTES){
  if(!bytes||bytes.length<12||bytes.length>max)return null;
  const h=new TextDecoder().decode(bytes.subarray(0,12));
  if(isAdts(bytes))return {mime:'audio/aac',ext:'aac'};
  if(h.startsWith('RIFF')&&h.slice(8,12)==='WAVE')return {mime:'audio/wav',ext:'wav'};
  if(h.startsWith('ID3')||bytes[0]===255&&(bytes[1]&224)===224)return {mime:'audio/mpeg',ext:'mp3'};
  if(h.slice(4,8)==='ftyp')return {mime:'audio/mp4',ext:'mp4'};
  if(bytes[0]===26&&bytes[1]===69&&bytes[2]===223&&bytes[3]===163)return {mime:'audio/webm',ext:'webm'};
  return null;
}
export function createVoiceReader({apiKey,model='gpt-4o-mini-transcribe',fetchImpl,hosts=[],canTranscribe}={}){
  if(typeof fetchImpl!=='function')throw Error('missing-transport');
  return async ({url,bytes,maxBytes=VOICE_MAX_BYTES,timeoutMs=20000})=>{
    if(![20000,90000].includes(timeoutMs)||(timeoutMs===90000&&![FILE_MAX_BYTES,VIDEO_AUDIO_MAX_BYTES].includes(maxBytes)))return {status:'failed',reason:'voice-config'};
    if(![VOICE_MAX_BYTES,FILE_MAX_BYTES,VIDEO_AUDIO_MAX_BYTES].includes(maxBytes))return {status:'failed',reason:'voice-format-or-size'};
    if(typeof apiKey!=='string'||!apiKey||!/^[\x21-\x7e]+$/.test(apiKey)||!['gpt-4o-mini-transcribe','gpt-4o-transcribe','whisper-1'].includes(model))return {status:'failed',reason:'voice-config'};
    const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),timeoutMs);
    try{
      if(!bytes){const target=publicUrl(url,hosts,4096);if(!target)return {status:'failed',reason:publicUrl(url,undefined,4096)?'voice-host':'voice-url-invalid'};
        const r=await fetchImpl(target,{redirect:'manual',signal:controller.signal,headers:{Accept:'audio/*'}});
        if(r.status!==200)return {status:'failed',reason:'voice-download',httpStatus:r.status};bytes=await readBytes(r,Math.min(maxBytes,VOICE_MAX_BYTES));
      }
      let type=audioType(bytes,maxBytes);if(!type)return {status:'failed',reason:'voice-format-or-size'};
      if(type.ext==='aac'){bytes=remuxAdts(bytes);if(!bytes)return {status:'failed',reason:'voice-aac-unsupported'};type={mime:'audio/mp4',ext:'m4a'};}
      if(canTranscribe&&!await canTranscribe())return {status:'failed',reason:'ai-paused'};
      const form=new FormData();form.set('model',model);form.set('response_format','json');form.set('file',new Blob([bytes],{type:type.mime}),'speech.'+type.ext);
      const r=await fetchImpl('https://api.openai.com/v1/audio/transcriptions',{method:'POST',redirect:'manual',signal:controller.signal,headers:{Authorization:`Bearer ${apiKey}`},body:form});
      if(!r.ok){
        const raw=await readLimitedBody(r,65536);let category='unclassified';
        try{const e=JSON.parse(raw)?.error;const msg=String(e?.message??'').toLowerCase();
          if(/format|decode|corrupt|audio file/.test(msg))category='audio-format';
          else if(/model/.test(msg))category='model';else if(/parameter|response_format/.test(msg))category='parameter';
        }catch{}
        return {status:'failed',reason:r.status===429?'quota':'voice-api',httpStatus:r.status,category};
      }
      const raw=await readLimitedBody(r,65536);if(!raw)return {status:'failed',reason:'voice-response'};
      const text=JSON.parse(raw)?.text;
      if(!cleanText(text,12000))return {status:'failed',reason:'voice-text-limit'};
      return {status:'ready',text};
    }catch{return {status:'uncertain',reason:'voice-transport'};}finally{clearTimeout(timer);}
  };
}
export async function fetchDocumentUrl(url,{hosts,fetchImpl}){
  const target=publicUrl(url,hosts);if(!target)return {status:'failed',reason:'source-host'};
  const controller=new AbortController(),timer=setTimeout(()=>controller.abort(),8000);
  try{
    const r=await fetchImpl(target,{redirect:'manual',signal:controller.signal,headers:{Accept:'text/html,text/plain,application/pdf'}});
    if(r.status!==200)return {status:'failed',reason:'source-http'};
    const bytes=await readBytes(r,SOURCE_MAX_BYTES);if(!bytes)return {status:'failed',reason:'source-size'};
    const mime=r.headers.get('content-type')?.split(';')[0]?.toLowerCase();
    if(mime==='application/pdf'&&documentType('source.pdf',bytes))return {status:'ready',filename:'source.pdf',mime,data:bytes64(bytes)};
    if(!['text/plain','text/html','text/markdown'].includes(mime))return {status:'failed',reason:'source-type'};
    let text=new TextDecoder('utf-8',{fatal:true}).decode(bytes);
    if(mime==='text/html')text=text.replace(/<(script|style|noscript|nav|footer)\b[^>]*>[\s\S]*?<\/\1\s*>/gi,' ').replace(/<[^>]*>/g,' ').replace(/&nbsp;/gi,' ').replace(/&amp;/gi,'&').replace(/&lt;/gi,'<').replace(/&gt;/gi,'>');
    text=text.replace(/\s+/g,' ').trim();
    if(!cleanText(text,100000))return {status:'failed',reason:'source-text-limit'};
    return {status:'ready',filename:'source.txt',mime:'text/plain',data:bytes64(new TextEncoder().encode(text))};
  }catch{return {status:'failed',reason:'source-transport'};}finally{clearTimeout(timer);}
}
// Keep each storage value under 128 KiB. Jobs are scoped to the owning chat DO.
export class UploadStore{
  constructor(storage,{now=Date.now}={}){this.storage=storage;this.now=now;}
  async save(id,payload){
    const raw=JSON.stringify(payload);if(raw.length>32*1024*1024)throw Error('upload-too-large');
    const rows=await this.storage.list({prefix:'upload-head:'});if(rows.size>=3)throw Error('uploads-full');
    const n=Math.ceil(raw.length/48000);for(let i=0;i<n;i++)await this.storage.put(`upload:${id}:${i}`,raw.slice(i*48000,(i+1)*48000));
    await this.storage.put('upload-head:'+id,{n,expires:this.now()+15*60000});
  }
  async take(id){
    const h=await this.storage.get('upload-head:'+id);if(!h)return null;
    let raw='';for(let i=0;i<h.n;i++){const v=await this.storage.get(`upload:${id}:${i}`);if(typeof v!=='string')return null;raw+=v;}
    await this.remove(id,h);return h.expires>this.now()?JSON.parse(raw):null;
  }
  async remove(id,h){for(let i=0;i<h.n;i++)await this.storage.delete(`upload:${id}:${i}`);await this.storage.delete('upload-head:'+id);}
  async maintain(){for(const [k,v]of await this.storage.list({prefix:'upload-progress:'}))if(v.expires<=this.now())await this.storage.delete(k);for(const [k,h]of await this.storage.list({prefix:'upload-head:'}))if(h.expires<=this.now())await this.remove(k.slice(12),h);}
  async next(){const rows=[...await this.storage.list({prefix:'upload-head:'})].map(([,v])=>v.expires);return rows.length?Math.min(...rows):null;}
}

// Shared bounds for browser preparation and server validation. No provider calls here.
export function videoPlan(duration,version=1){
 if(!Number.isFinite(duration)||duration<=0||duration>900)throw Error('invalid-video-duration');
 const step=version===2?90:Math.max(30,Math.ceil(duration/6));
 return Array.from({length:Math.ceil(duration/step)},(_,i)=>({start:i*step,end:Math.min(duration,(i+1)*step)}));
}
export function pickVideoFrames(candidates){
 if(!Array.isArray(candidates)||candidates.length!==16)throw Error('invalid-video-candidates');
 const chosen=new Set([0,4,8,12,15]);
 for(const item of candidates.map((v,i)=>({i,score:v.score})).sort((a,b)=>b.score-a.score||a.i-b.i))if(chosen.size<8&&item.score>=8)chosen.add(item.i);
 for(const i of [2,6,10,14,1,3,5,7,9,11,13])if(chosen.size<8)chosen.add(i);
 return [...chosen].sort((a,b)=>a-b).map(i=>({time:candidates[i].time,image:candidates[i].image}));
}
export function videoSamplingBudget(span){
 if(!Number.isFinite(span)||span<=0||span>90)throw Error('invalid-video-window');
 const base=span<=30?Math.min(30,Math.max(8,Math.ceil(span))):Math.ceil(span/3),extra=Math.ceil(span/15);
 return {base,extra,max:base+extra,scanStep:span<=30?.5:1,repeatGap:span<=30?3:12};
}
export function videoScanTimes(start,end){
 if(!Number.isFinite(start)||!Number.isFinite(end)||start<0||end<=start||end-start>90||end>900)throw Error('invalid-video-window');
 const span=end-start,step=videoSamplingBudget(span).scanStep;return Array.from({length:Math.ceil(span/step)},(_,i)=>start+Math.min((i+.5)*step,Math.max(span/2,span-.001)));
}
export function pickAdaptiveVideoFrames(candidates,span){
 if(!Array.isArray(candidates)||!candidates.length||!Number.isFinite(span)||span<=0||span>90)throw Error('invalid-video-candidates');
 const budget=videoSamplingBudget(span),base=budget.base,anchors=new Set(Array.from({length:base},(_,i)=>base===1?0:Math.round(i*(candidates.length-1)/(base-1))));
 const difference=(a,b)=>{if(!a||!b||a.length!==b.length)return Infinity;let sum=0;for(let i=0;i<a.length;i++)sum+=Math.abs(a[i]-b[i]);return sum/a.length;};
 if(candidates.length>1)anchors.add(candidates.length-1);
 const kept=[];for(const i of [...anchors].sort((a,b)=>a-b)){const last=kept.at(-1);if(last===undefined||i===candidates.length-1||candidates[i].time-candidates[last].time>=budget.repeatGap||difference(candidates[i].fingerprint,candidates[last].fingerprint)>=.75)kept.push(i);}
 const scores=candidates.slice(1).map(x=>x.score).sort((a,b)=>a-b),threshold=Math.max(2.5,(scores[Math.floor(scores.length/2)]??0)*1.5);let bonus=Math.min(budget.extra,budget.max-kept.length);
 for(const item of candidates.map((x,i)=>({i,score:x.score})).sort((a,b)=>b.score-a.score||a.i-b.i))if(bonus>0&&item.score>=threshold&&!kept.some(i=>Math.abs(candidates[i].time-candidates[item.i].time)<.75||(Math.abs(candidates[i].time-candidates[item.i].time)<12&&difference(candidates[i].fingerprint,candidates[item.i].fingerprint)<.75))){kept.push(item.i);bonus--;}
 return kept.sort((a,b)=>a-b).map(i=>candidates[i]);
}
export function validVideoSegments(payload){
 if(payload.samplingVersion!==undefined&&payload.samplingVersion!==2)return false;
 const modern=payload.samplingVersion===2;let plan;try{plan=videoPlan(payload.duration,modern?2:1);}catch{return false;}
 if(payload.frames!==undefined||!Array.isArray(payload.segments)||payload.segments.length!==plan.length)return false;
 return payload.segments.every((s,i)=>{const span=plan[i].end-plan[i].start,max=modern?videoSamplingBudget(span).max:8;
 return s.start===plan[i].start&&s.end===plan[i].end&&Array.isArray(s.frames)&&(modern?s.frames.length>=1&&s.frames.length<=max:s.frames.length===8)&&s.frames.every((f,j)=>Number.isFinite(f.time)&&f.time>=s.start&&f.time<s.end&&(!j||f.time>s.frames[j-1].time)&&(!modern||((j!==0||f.time-s.start<=1)&&(j!==s.frames.length-1||s.end-f.time<=1)&&(!j||f.time-s.frames[j-1].time<=16)))&&typeof f.image==='string'&&f.image.length<=120000&&/^data:image\/(?:jpeg|png);base64,[A-Za-z0-9+/]+={0,2}$/.test(f.image));});
}
