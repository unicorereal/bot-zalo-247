const object = value => value !== null && typeof value === 'object' && !Array.isArray(value);
const id = value => typeof value === 'string' && value.length > 0 && value.length <= 256;

// Only structural booleans; never emit values, field names from input or message text.
export function eventShape(body) {
  const r = body?.result, m = r?.message;
  const flat = body?.message;
  const actual = object(r) ? r : body, media = actual?.message;
  const attachmentFields = ['file','document','video','attachment','attachments','file_url','video_url','download_url','url'];
  const directShape = Object.fromEntries(attachmentFields.map(k=>['direct_'+k,media?.[k]!==undefined]));
  return { ...directShape, directUnsupportedEvent:actual?.event_name==='message.unsupported.received', directFileEvent:actual?.event_name==='message.file.received', directVideoEvent:actual?.event_name==='message.video.received', rootTextEvent: body?.event_name === 'message.text.received',
    rootImageEvent: body?.event_name === 'message.image.received',
    rootPhotoUrlString: typeof flat?.photo_url === 'string', rootPhotoString: typeof flat?.photo === 'string',
    imageEvent: r?.event_name === 'message.image.received',
    photoUrlString: typeof m?.photo_url === 'string', photoString: typeof m?.photo === 'string',
    rootMessageObject: object(flat), rootFromObject: object(flat?.from), rootChatObject: object(flat?.chat),
    rootSenderIdValid: id(flat?.from?.id), rootIsBotBoolean: typeof flat?.from?.is_bot === 'boolean',
    rootChatIdValid: id(flat?.chat?.id), rootPrivateChat: flat?.chat?.chat_type === 'PRIVATE',
    rootGroupChat: flat?.chat?.chat_type === 'GROUP', rootMessageIdValid: id(flat?.message_id),
    rootDateValid: Number.isSafeInteger(flat?.date) && flat.date > 0,
    rootDateString: typeof flat?.date === 'string', rootTextValid: typeof flat?.text === 'string' && flat.text.trim().length > 0,
    bodyObject: object(body), okTrue: body?.ok === true, resultObject: object(r),
    textEvent: r?.event_name === 'message.text.received', messageObject: object(m),
    messageString: typeof m === 'string', fromObject: object(m?.from), chatObject: object(m?.chat),
    senderIdValid: id(m?.from?.id), isBotBoolean: typeof m?.from?.is_bot === 'boolean',
    chatIdValid: id(m?.chat?.id), privateChat: m?.chat?.chat_type === 'PRIVATE',
    groupChat: m?.chat?.chat_type === 'GROUP', messageIdValid: id(m?.message_id),
    dateValid: Number.isSafeInteger(m?.date) && m.date > 0,
    dateString: typeof m?.date === 'string', textValid: typeof m?.text === 'string' && m.text.trim().length > 0 };
}

export function normalizeEvent(body, { includeText = false, includeTimestamp = false, includeGroups = false, includeImages = false, includeGroupImages = false, includeVoice = false } = {}) {
  if (!object(body)) return { kind: 'invalid' };
  // Authenticated empty probe is a local compatibility policy, not a verified Zalo schema.
  if (Object.keys(body).length === 0) return { kind: 'ignored', reason: 'possible-probe' };
  // Official sample wraps ok/result; authenticated live webhook (09/10/2026)
  // provides event_name/message directly. Never fall back from a broken wrapper.
  const wrapped = Object.hasOwn(body, 'ok') || Object.hasOwn(body, 'result');
  const result = wrapped ? (body.ok === true && object(body.result) ? body.result : null) : body;
  if (!object(result) || !id(result.event_name)) return { kind: 'invalid' };
  const image = result.event_name === 'message.image.received';
  const voice = result.event_name === 'message.voice.received';
  if(voice&&!includeVoice)return {kind:'ignored',reason:'voice-not-enabled'};
  if (image && !includeImages) return { kind: 'ignored', reason: 'image-not-enabled' };
  if (!image && !voice && result.event_name !== 'message.text.received') return { kind: 'ignored', reason: 'unsupported-event' };
  const m = result.message;
  // Authenticated PRIVATE image observed 10/10/2026 uses photo_url.
  // Keep documented photo; reject conflicting or malformed dual fields.
  const livePhoto=object(m)&&Object.hasOwn(m,'photo_url');
  const documentedPhoto=object(m)&&Object.hasOwn(m,'photo');
  const photo=livePhoto?m.photo_url:m?.photo;
  const ambiguousPhoto=image&&livePhoto&&documentedPhoto&&m.photo_url!==m.photo;
  if (!object(m) || !object(m.from) || !object(m.chat) || !id(m.from.id) ||
      typeof m.from.is_bot !== 'boolean' || !id(m.chat.id) ||
      !['PRIVATE', 'GROUP'].includes(m.chat.chat_type) || !id(m.message_id) ||
      !Number.isSafeInteger(m.date) || m.date <= 0 || (voice ? typeof m.voice_url!=='string'||!m.voice_url.trim()||m.voice_url.length>4096 : image
        ? ambiguousPhoto || typeof photo !== 'string' || !photo.trim() || photo.length > 4096 ||
          m.caption !== undefined && (typeof m.caption !== 'string' || m.caption.length > 1000)
        : typeof m.text !== 'string' || m.text.trim().length === 0)) return { kind: 'invalid' };
  if (m.from.is_bot) return { kind: 'ignored', reason: 'bot-message' };
  if (image && m.chat.chat_type !== 'PRIVATE' && !includeGroupImages) return { kind: 'ignored', reason: 'group-image-not-supported' };
  if (m.chat.chat_type === 'GROUP' && includeGroups !== true) return { kind: 'ignored', reason: 'group-not-enabled' };
  return {
    kind: voice ? 'voice' : image ? 'image' : 'text',
    ...(voice ? {mediaUrl:m.voice_url} : {}),
    ...(image ? { photo } : {}),
    ...(m.chat.chat_type === 'GROUP' ? { chatType: 'GROUP' } : {}),
    chatId: m.chat.id,
    senderId: m.from.id,
    messageId: m.message_id,
    key: JSON.stringify([m.chat.chat_type, m.chat.id, m.message_id]),
    ...(includeTimestamp ? { eventAt: m.date } : {}),
    ...(includeText ? { text: voice ? 'Trả lời nội dung tin thoại.' : image ? (m.caption ?? '').trim() : m.text } : {})
  };
}
