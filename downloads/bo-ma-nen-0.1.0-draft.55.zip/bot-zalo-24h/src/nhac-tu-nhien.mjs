// Bounded Vietnamese reminder grammar. No model calls or implicit calendar rollover.
const DAY=86400000,OFFSET=7*3600000;
const fold=s=>String(s??'').normalize('NFD').replace(/\p{M}/gu,'').replace(/đ/g,'d').replace(/Đ/g,'D').toLowerCase();
const raw=s=>String(s??'').normalize('NFC').trim().replace(/\s+/g,' ');
const prefix=/^nhac(?:\s+(?:toi|to|minh|t|em|anh|chi|ban))?(?:\s+nho)?(?:\s+|$)/;
export function naturalReminderIntent(text){
 const s=fold(raw(text));
 if(s.length>1000||!prefix.test(s)||/^nhac\s+(?:lai|den|ve)\b/.test(s))return false;
 return /^nhac\s+(?:toi|to|minh|t|em|anh|chi|ban)(?:\s|$)/.test(s)||/^nhac\s+(?:vao|luc|sau|trong|hom|ngay|mai|sang|chieu|toi)\b/.test(s);
}
function fragments(input,now){
 const text=raw(input),s=fold(text),spans=[];let date=null,time=null,error=null,hint=null;
 const today=new Date(now+OFFSET).toISOString().slice(0,10);
 const dateWord=/\b(ngay kia|hom nay|ngay mai|sang mai|chieu mai|toi mai|trua mai|dem mai|mai)\b/g;
 const dates=[...s.matchAll(dateWord)];
 const numeric=[...s.matchAll(/\b(?:ngay\s+)?(\d{1,2})\/(\d{1,2})(?:\/(\d{4}))?\b/g)];
 if(dates.length+numeric.length>1)error='Em chưa rõ ngày nào. Hãy ghi một ngày cụ thể cho mỗi lịch.';
 if(dates[0]){
  const m=dates[0],days=m[1]==='hom nay'?0:m[1]==='ngay kia'?2:1;
  date=new Date(Date.parse(today+'T00:00:00+07:00')+days*DAY+OFFSET).toISOString().slice(0,10);
  hint=m[1].match(/^(sang|chieu|toi|trua|dem) mai$/)?.[1]??null;spans.push([m.index,m.index+m[0].length]);
 }
 if(numeric[0]){
  const m=numeric[0],year=m[3]??today.slice(0,4),month=m[2].padStart(2,'0'),day=m[1].padStart(2,'0');date=`${year}-${month}-${day}`;
  const n=Date.parse(date+'T00:00:00+07:00');
  if(!Number.isFinite(n)||new Date(n+OFFSET).toISOString().slice(0,10)!==date)error='Ngày này không hợp lệ. Hãy ghi lại ngày/tháng/năm.';
  spans.push([m.index,m.index+m[0].length]);
 }
 const times=[...s.matchAll(/\b(?:vao\s+|luc\s+)?(\d{1,2})\s*(?:h|gio|:)(?:\s*(\d{1,2})(?:\s*phut)?)?(?:\s*(sang|chieu|toi|trua|dem))?\b/g)];
 if(times.length>1)error='Em chưa rõ giờ nào. Hãy ghi một giờ cụ thể cho mỗi lịch.';
 if(times[0]){
  const m=times[0];let hour=Number(m[1]),minute=Number(m[2]??0);const period=m[3]??hint;
  if(minute>59||hour>23)error='Giờ không hợp lệ. Hãy ghi giờ từ 00:00 đến 23:59.';
  if(period){
   if(['chieu','toi'].includes(period)&&hour>=1&&hour<=11||period==='dem'&&hour>=6&&hour<=11)hour+=12;
   if(period==='dem'&&hour===12)hour=0;
   if(hint&&m[3]&&hint!==m[3])error='Giờ và buổi trong ngày chưa khớp. Hãy ghi một giờ theo dạng 24 giờ.';
   if(period==='sang'&&hour>=12||period==='trua'&&![11,12,13].includes(hour))error='Em chưa rõ buổi trong ngày. Hãy ghi giờ theo dạng 24 giờ, ví dụ 09:00 hoặc 21:00.';
  }
  time={hour,minute};spans.push([m.index,m.index+m[0].length]);
 }
 let chars=text.split('');for(const [a,b]of spans)for(let i=a;i<b;i++)chars[i]=' ';
 const content=chars.join('').replace(/\s+/g,' ').replace(/^(?:vào|lúc|để|việc|nội dung|là)\s*:?\s*/iu,'').trim();
 return {date,time,content,error,found:spans.length>0};
}
export function naturalReminderFollowup(text,draft,now){
 const s=fold(raw(text));
 if(/^(?:huy|thoi|bo qua|khong dat)(?: lich)?[.!]?$/.test(s))return true;
 if(!draft.content&&/^(?:noi dung|viec)\s*:\s*\S/.test(s))return true;
 const f=fragments(text,now);return f.found&&!f.content;
}
export function parseNaturalReminder(input,now,previous=null,anchor=now){
 let text=raw(input),draft=previous?structuredClone(previous):{date:null,time:null,content:''};
 if(!previous){const m=fold(text).match(prefix);if(!m)return null;const length=/^nhắc\s+tối\b/iu.test(text)?fold(text).match(/^nhac\s+/)[0].length:m[0].length;text=text.slice(length);}
 else if(/^(?:huy|thoi|bo qua|khong dat)(?: lich)?[.!]?$/.test(fold(text)))return {state:'cancelled'};
 if(/\b(?:hang ngay|moi ngay|hang tuan|moi tuan|lap lai)\b/.test(fold(text)))return {state:'invalid',reply:'Hiện lịch nhắc chỉ chạy một lần, chưa có lịch lặp. Chưa đặt lịch; hãy gửi lại với một ngày giờ cụ thể.'};
 if(/\d[.,]\d\s*(?:h\b|gio\b|phut\b|ngay\b)|(?:\d\s*h|gio)\s*(?:ruoi|kem|hon)\b/.test(fold(text)))return {state:'invalid',reply:'Em chưa đọc chắc cách ghi giờ này. Hãy dùng giờ cụ thể như 09:30 hoặc “sau 30 phút”. Chưa đặt lịch.'};
 if(previous&&!draft.content&&/^(?:noi dung|viec)\s*:/i.test(fold(text))){
  draft.content=text.slice(text.indexOf(':')+1).trim();
 }else{
  const s=fold(text),relative=s.match(/^(?:sau|trong)\s+(\d{1,4})\s+(phut|gio|ngay)(?:\s+nua)?(?:\s+|$)/);
  if(relative){
   const amount=Number(relative[1]),duration=amount*({phut:60000,gio:3600000,ngay:DAY}[relative[2]]);
   if(duration<60000||duration>365*DAY)return {state:'invalid',reply:'Lịch nhắc cần cách hiện tại từ 1 phút đến 365 ngày. Chưa có lịch nào được đặt.'};
   draft.due=anchor+duration;draft.relative=true;draft.content=text.slice(relative[0].length).trim()||draft.content;
  }else{
   const f=fragments(text,anchor);
   if(f.error)return {state:'invalid',reply:f.error+' Chưa có lịch nào được đặt.'};
   if(f.date||f.time){delete draft.due;delete draft.relative;}
   if(f.date)draft.date=f.date;if(f.time)draft.time=f.time;
   if(f.content&&!previous)draft.content=f.content;
  }
 }
 if(!draft.due&&draft.date&&draft.time)draft.due=Date.parse(`${draft.date}T${String(draft.time.hour).padStart(2,'0')}:${String(draft.time.minute).padStart(2,'0')}:00+07:00`);
 if(draft.due!==undefined&&(!Number.isFinite(draft.due)||draft.due-now<(draft.relative?1:60000)||draft.due-now>365*DAY))return {state:'invalid',reply:'Thời điểm này đã qua, quá gần hoặc xa hơn 365 ngày. Chưa đặt lịch; hãy gửi lại với ngày giờ khác.'};
 if(draft.content.length>700)return {state:'invalid',reply:'Nội dung nhắc tối đa 700 ký tự. Chưa đặt lịch; hãy viết ngắn hơn.'};
 if(draft.due&&draft.content)return {state:'ready',due:draft.due,text:draft.content};
 const question=!draft.date&&!draft.due?'Em cần ngày nhắc, ví dụ “ngày mai”.':!draft.time&&!draft.due?'Em cần giờ nhắc, ví dụ “09:00”.':'Em cần nội dung nhắc. Trả lời “Nội dung: đi mua hoa quả”.';
 return {state:'incomplete',draft,reply:question+' Chưa đặt lịch; có thể trả lời “hủy” để bỏ yêu cầu này.'};
}
