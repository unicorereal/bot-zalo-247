import {randomToken,sha256,validateExtensions} from './mo-rong-du-lieu.mjs';
import {adminIds} from './quan-ly-kho.mjs';
import {generationEnv,SETTINGS} from './duong-du-lieu.mjs';
import {exportRows,restoreRows,checkBackup} from './sao-luu-cloud.mjs';
import {ResourceImages,resourceImageBytes} from './anh-tai-nguyen.mjs';
import {bytes64} from './tep-va-thoai.mjs';
import {approvedResourceBatch} from './tai-nguyen-da-duyet.mjs';
import {readReferences} from './du-lieu-tham-khao.mjs';
const EXT=JSON.stringify(['EXTENSIONS','v1']);
const basicNames=[EXT,...['CATALOG','AI-OPERATION','PRIVATE-ACCESS'].map(k=>JSON.stringify([k,'v1']))];
const initial=()=>({active:'legacy',revision:0,maintenance:false,previous:null,job:null});
function normalizedRows(o){const rows=restoreRows(o.rows);if(o.name==='["AI-OPERATION","v1"]'&&!rows.some(([k])=>k==='operation:control'))rows.push(['operation:control',{paused:true,privatePaused:true,groupPaused:true}]);return rows;}
export class RecoveryManager{
 constructor(storage,env,{now=Date.now}={}){this.storage=storage;this.env=env;this.now=now;}
 async state(){return await this.storage.get('recovery:state')??initial();}
 async mint(actor){if(!adminIds(this.env.CATALOG_ADMIN_IDS_JSON).includes(actor))throw Error('Chỉ người quản lý được dùng.');const token=randomToken();await this.storage.put('recovery:session:'+await sha256(token),{actor,expires:this.now()+15*60000});return {token};}
 async internal(body){
  if(body.action==='mint')return this.mint(body.actor);
  if(body.action==='command')return this.storage.transaction(async()=>{if(!adminIds(this.env.CATALOG_ADMIN_IDS_JSON).includes(body.actor))throw Error('owner-required');const key='recovery:command:'+await sha256(body.key);if(await this.storage.get(key))return {claimed:false};const session=await this.mint(body.actor);await this.storage.put(key,{at:this.now()});return {...session,claimed:true};});
  if(body.action==='routing'){const s=await this.state();return {active:s.active,maintenance:s.maintenance,revision:s.revision,settings:s.settings??{}};}
  if(body.action==='release'){await this.storage.delete('recovery:lease:'+body.id);return {released:true};}
  if(body.action==='acquire')return this.storage.transaction(async()=>{const s=await this.state();if(s.maintenance||body.generation!==s.active)return {allowed:false};const id=randomToken();await this.storage.put('recovery:lease:'+id,{until:this.now()+20*60000});return {allowed:true,id};});
  throw Error('Lệnh nội bộ không hợp lệ.');
 }
 async quiet(){const rows=await this.storage.list({prefix:'recovery:lease:'});return [...rows.values()].every(x=>x.until<=this.now());}
 async inspect(backup){const info=await checkBackup(backup);if(!basicNames.every(name=>backup.objects.some(o=>o.name===name)))throw Error('Bản sao thiếu phần dữ liệu quản lý bắt buộc. Chưa khôi phục.');if(backup.schema===1)for(const o of backup.objects)for(const[k,v]of o.rows)if(k==='extension:head'&&v.resources.some(x=>x.type==='photo'&&/^\/tai-nguyen\/[a-f0-9]{64}\.(png|jpg)$/.test(new URL(x.url).pathname)))throw Error('Bản sao cũ chỉ có link ảnh, chưa có ảnh gốc. Hãy tạo bản sao mới hoặc nhờ AI chuẩn bị ảnh gốc trước khi khôi phục.');return {...info,canRestore:true,legacy:backup.schema===1,images:backup.assets?.length??0};}
 stub(generation,name,settings={}){const e=generationEnv({...this.env,DATA_SETTINGS:settings},generation,true);return e.INBOX.get(e.INBOX.idFromName(name));}
 async call(generation,name,action,body={}){const s=await this.state(),settings=generation===s.active?s.settings:s.job?.settings;const r=await this.stub(generation,name,settings??{}).fetch(new Request('https://internal/extension/recovery-data',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({action,name,...body})}));if(!r.ok)throw Error('Chưa đọc hoặc ghi được một phần dữ liệu. Giữ nguyên bản đang dùng.');return r.json();}
 async api(body,token){
  const cap=await this.storage.get('recovery:session:'+await sha256(token??''));if(!cap||cap.expires<=this.now()||!adminIds(this.env.CATALOG_ADMIN_IDS_JSON).includes(cap.actor))return Response.json({error:'Link hết hạn. Gửi /khoiphuc trong chat riêng để mở lại.'},{status:403});
  const previous=this.apiTail??Promise.resolve();let release;this.apiTail=new Promise(r=>release=r);await previous;
  try{const result=await this.action(body,cap.actor);if(['cancel','activate','rollback'].includes(body.action)){const s=await this.state();const list=await this.call(s.active,EXT,'list');for(const name of list.names)await this.call(s.active,name,'wake');}return Response.json(result);}catch(e){return Response.json({error:e.message},{status:400});}finally{release();}
 }
 async action(b,actor){
  let s=await this.state();
  if(b.action==='session')return {owner:true,...s,current:await this.call(s.active,EXT,'summary'),busy:!await this.quiet()};
  if(b.action==='inspect')return {...await this.inspect(b.backup),current:await this.call(s.active,EXT,'summary')};
  if(['backup-start','restore-start'].includes(b.action)){
   return this.storage.transaction(async()=>{s=await this.state();if(s.job){if(s.job.actor!==actor)throw Error('Một người quản lý khác đang làm.');if(s.job.kind!==(b.action==='backup-start'?'backup':'restore'))throw Error('Hãy kết thúc hoặc hủy công việc hiện tại trước.');return {job:s.job.id,busy:!await this.quiet()};}
    s.maintenance=true;s.job={id:randomToken(),actor,kind:b.action==='backup-start'?'backup':'restore',generation:randomToken(),source:s.active,revision:s.revision,phase:'loading',created:this.now()};await this.storage.put('recovery:state',s);return {job:s.job.id,busy:!await this.quiet()};});
  }
  if(b.action==='cancel')return this.storage.transaction(async()=>{s=await this.state();if(s.job&&s.job.actor!==actor)throw Error('Công việc thuộc người quản lý khác.');s.maintenance=false;s.job=null;await this.storage.put('recovery:state',s);return {cancelled:true};});
  if(b.action==='rollback'){const leaving=await this.call(s.active,EXT,'summary');return this.storage.transaction(async()=>{s=await this.state();if(!s.previous||s.job||!await this.quiet())throw Error('Chưa thể quay lại. Hãy kết thúc tác vụ đang chạy rồi thử.');const old=s.active,oldSettings=s.settings,oldInfo=s.activeInfo;s.activeInfo=s.previousInfo;s.previousInfo={...oldInfo,...leaving,keptAt:this.now()};s.active=s.previous;s.settings=s.previousSettings??{};s.previous=old;s.previousSettings=oldSettings;s.revision++;s.maintenance=false;await this.storage.put('recovery:state',s);return {rolledBack:true};});}
  const j=s.job;if(!j||j.actor!==actor||j.id!==b.job||j.source!==s.active||j.revision!==s.revision)throw Error('Công việc không còn khớp. Mở lại trang để kiểm.');
  if(!await this.quiet())throw Error('Bot đang kết thúc tác vụ trước đó. Đợi rồi bấm tiếp tục.');
  if(b.action==='backup-list'){
   if(j.kind!=='backup')throw Error('Sai công việc.');const names=await this.call(s.active,EXT,'list');return {names:[...new Set([...basicNames,...names.names])],created:new Date(this.now()).toISOString(),origin:new URL(this.env.PUBLIC_BOT_ORIGIN).origin,settings:Object.fromEntries(SETTINGS.filter(k=>['true','false'].includes((s.settings??{})[k]??this.env[k])).map(k=>[k,(s.settings??{})[k]??this.env[k]]))};
  }
  if(b.action==='backup-object'){if(j.kind!=='backup')throw Error('Sai công việc.');const names=await this.call(s.active,EXT,'list');if(![...basicNames,...names.names].includes(b.name))throw Error('Không có phần dữ liệu này.');return {name:b.name,...await this.call(s.active,b.name,'export')};}
  if(b.action==='backup-asset'){if(j.kind!=='backup')throw Error('Sai công việc.');return this.call(s.active,EXT,'asset',{name:b.name});}
  if(b.action==='check-snapshot'){if(j.kind!=='backup')throw Error('Sai công việc.');return checkBackup(b.backup);}
  if(b.action==='preview'){
   if(j.kind!=='restore')throw Error('Sai công việc.');const info=await this.inspect(b.backup);const {checksum,...data}=b.backup;
   // Store bounded object expectations separately; never one large DO value.
   for(let i=0;i<data.objects.length;i++)await this.storage.put('recovery:expected:'+j.id+':'+i,{name:data.objects[i].name,hash:await sha256(JSON.stringify(normalizedRows(data.objects[i])))});
   const assets=data.assets??[];for(let i=0;i<assets.length;i++)await this.storage.put('recovery:asset:'+j.id+':'+i,{name:assets[i].name,hash:assets[i].hash});
   j.preservedInfo={...await this.call(s.active,EXT,'summary'),keptAt:this.now()};j.backupInfo={name:data.objects.flatMap(o=>o.rows).find(([k])=>k==='extension:head')?.[1]?.profile?.name??'Trợ lý',created:data.created??null};
   j.hash=checksum;j.count=data.objects.length;j.assets=assets.length;j.settings=data.settings??{};j.phase='preview';j.previewExpires=this.now()+15*60000;await this.storage.put('recovery:state',s);
   return {...info,canRestore:true,legacy:b.backup.schema===1,images:assets.length};
  }
  if(b.action==='import-object'){
   if(j.kind!=='restore'||!j.hash||j.previewExpires<=this.now())throw Error('Kiểm bản sao lại trước khi khôi phục.');const expected=await this.storage.get('recovery:expected:'+j.id+':'+b.index);if(!expected||b.object?.name!==expected.name||await sha256(JSON.stringify(normalizedRows(b.object)))!==expected.hash)throw Error('Dữ liệu đã đổi sau khi xem trước.');
   await this.call(j.generation,expected.name,'import',{rows:normalizedRows(b.object),hash:expected.hash});if(['PRIVATE','GROUP'].includes(JSON.parse(expected.name)[0]))await this.call(j.generation,EXT,'register',{name:expected.name});await this.storage.put('recovery:done:'+j.id+':'+b.index,true);return {loaded:true};
  }
  if(b.action==='import-asset'){
   const expected=await this.storage.get('recovery:asset:'+j.id+':'+b.index);const bytes=resourceImageBytes(b.data);if(!expected||expected.name!==b.name||!bytes||await sha256(bytes)!==expected.hash)throw Error('Ảnh không khớp bản sao.');await this.call(j.generation,EXT,'stage',{data:b.data,name:b.name});await this.storage.put('recovery:image-done:'+j.id+':'+b.index,true);return {loaded:true};
  }
  if(b.action==='verify'){
   for(let i=0;i<j.count;i++){if(!await this.storage.get('recovery:done:'+j.id+':'+i))throw Error('Chưa nạp đủ dữ liệu.');const x=await this.storage.get('recovery:expected:'+j.id+':'+i);const got=await this.call(j.generation,x.name,'export');if(await sha256(JSON.stringify(got.rows))!==x.hash)throw Error('Dữ liệu đọc lại không khớp.');}
   for(let i=0;i<j.assets;i++){if(!await this.storage.get('recovery:image-done:'+j.id+':'+i))throw Error('Chưa nạp đủ ảnh.');const x=await this.storage.get('recovery:asset:'+j.id+':'+i);const got=await this.call(j.generation,EXT,'asset',{name:x.name});if(got.hash!==x.hash)throw Error('Ảnh đọc lại không khớp.');}
   if(!j.count||!j.hash)throw Error('Chưa có bản phục hồi.');j.phase='verified';await this.storage.put('recovery:state',s);return {verified:true};
  }
  if(b.action==='activate')return this.storage.transaction(async()=>{s=await this.state();if(s.job?.id!==b.job||s.job.phase!=='verified'||!await this.quiet())throw Error('Bản phục hồi chưa kiểm xong.');s.previous=s.active;s.previousInfo=s.job.preservedInfo;s.activeInfo={...s.job.backupInfo,activatedAt:this.now()};s.previousSettings=s.settings??{};s.active=s.job.generation;s.settings=s.job.settings;s.revision++;s.job=null;s.maintenance=false;await this.storage.put('recovery:state',s);return {activated:true};});
  throw Error('Thao tác không hợp lệ.');
 }
}

export async function recoveryData(ctx,env,body){
 if(body.action==='summary')return {name:(await ctx.storage.get('extension:head'))?.profile?.name??'Trợ lý'};
 if(body.action==='list')return {names:[...await ctx.storage.list({prefix:'registry:'})].map(([,v])=>v.name)};
 if(body.action==='register'){await ctx.storage.put('registry:'+await sha256(body.name),{name:body.name});return {registered:true};}
 if(body.action==='wake'){await ctx.storage.setAlarm(Date.now()+1000);return {scheduled:true};}
 if(body.action==='export'){
  const rows=exportRows(await ctx.storage.list({prefix:''})).filter(([k,v])=>!k.startsWith('tin:')||v.created>=Date.now()-30*86400000);
  if(body.name==='["PRIVATE-ACCESS","v1"]'&&!rows.some(([k])=>k==='references:head')&&env.REFERENCE_DATA_JSON){const sources=readReferences(env.REFERENCE_DATA_JSON);if(sources)rows.push(['references:head',{revision:1,sources}]);}
  if(body.name==='["CATALOG","v1"]'&&!rows.some(([k])=>k==='catalog:head')&&env.PRODUCT_CATALOG_JSON)rows.push(['catalog:head',{revision:0,raw:env.PRODUCT_CATALOG_JSON}]);
  return {rows};
 }
 if(body.action==='import'){
  const rows=restoreRows(body.rows);if(await sha256(JSON.stringify(rows))!==body.hash)throw Error('restore-hash');
  await ctx.storage.transaction(async()=>{const old=await ctx.storage.get('restore:hash');if(old===body.hash)return;if(exportRows(await ctx.storage.list({prefix:''})).length)throw Error('restore-not-empty');for(const [k,v]of rows)await ctx.storage.put(k,v);if(rows.some(([k])=>k==='extension:head')&&approvedResourceBatch)await ctx.storage.put('restore:resource-seed',approvedResourceBatch.id);await ctx.storage.put('restore:hash',body.hash);});return {imported:true};
 }
 const images=new ResourceImages(ctx.storage),head=await ctx.storage.get('extension:head');
 if(body.action==='asset'){
  if(!/^[a-f0-9]{64}\.(png|jpg)$/.test(body.name??'')||!head?.resources.some(x=>x.type==='photo'&&new URL(x.url).pathname==='/tai-nguyen/'+body.name))throw Error('image-not-listed');
  let image=await images.read(body.name,[],true);
  if(!image&&env.RESOURCE_ASSETS){const res=await env.RESOURCE_ASSETS.fetch(new Request('https://assets.invalid/tai-nguyen/'+body.name));if(res.ok)image={bytes:new Uint8Array(await res.arrayBuffer())};}
  if(!image||await sha256(image.bytes)!==body.name.split('.')[0])throw Error('Không đọc được ảnh gốc đã nạp.');return {name:body.name,hash:await sha256(image.bytes),data:bytes64(image.bytes)};
 }
 if(body.action==='stage'){const bytes=resourceImageBytes(body.data);if(!bytes||!validateExtensions(head))throw Error('invalid-image');const result=await images.stage(bytes,head.resources);if(result.name!==body.name)throw Error('invalid-image');return {staged:true};}
 throw Error('invalid-recovery-data');
}
