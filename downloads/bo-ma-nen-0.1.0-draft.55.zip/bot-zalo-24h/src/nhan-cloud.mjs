import {recoveryPublic} from './trang-khoi-phuc.mjs';
import {recoveryCall} from './duong-du-lieu.mjs';
import {adminIds} from './quan-ly-kho.mjs';
import {createZaloSender} from './gui-tin.mjs';
import {serveResourceSnapshot} from './dong-bo-tai-nguyen.mjs';
import {resourceSyncRequest} from './tai-nguyen-dong-bo-da-duyet.mjs';
import {serveResource} from './tai-nguyen-ai.mjs';
import { normalizeEvent, eventShape } from './chuan-tin.mjs';
import { equalSecret, secretValid, readLimitedBody } from './webhook.mjs';
import { groupAllowed, inboxName } from './nhom-chat.mjs';
import { portalPage, portalScript } from './cong-quan-ly.mjs';
import { EXTENSION_NAME } from './mo-rong-cloud.mjs';
import { privateAllowed, privateAccessService, privateAccessPage, privateAccessScript, isPrivateAccessCommand } from './quyen-chat-rieng.mjs';

export async function handleCloud(request, env, ctx, syncRequest=resourceSyncRequest) {
  const path = new URL(request.url).pathname;
  if(env.RECOVERY_ENABLED==='true'){const result=await recoveryPublic(request,env);if(result)return result;}
  if(env.EXTENSIONS_ENABLED==='true'&&path.startsWith('/tai-nguyen-sync/'))return serveResourceSnapshot(request,syncRequest,async()=>{const r=await env.INBOX.get(env.INBOX.idFromName(EXTENSION_NAME)).fetch(new Request('https://internal/extension/state',{method:'POST',body:'{}'}));if(!r.ok)throw Error();return r.json();});
  if(env.EXTENSIONS_ENABLED==='true'&&path.startsWith('/tai-nguyen/')){try{return await serveResource(request,env,async()=>{const r=await env.INBOX.get(env.INBOX.idFromName(EXTENSION_NAME)).fetch(new Request('https://internal/extension/state',{method:'POST',body:'{}'}));if(!r.ok)throw Error();return r.json();},name=>env.INBOX.get(env.INBOX.idFromName(EXTENSION_NAME)).fetch(new Request('https://internal/extension/resource-image',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({name})})));}catch{return new Response(null,{status:503});}}
  if(env.PRIVATE_ACCESS_ENABLED==='true'&&['/quyen-rieng','/quyen-rieng.js','/quyen-rieng-api'].includes(path)){
    const headers={'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"};
    if(request.method==='GET'&&path!=='/quyen-rieng-api')return new Response(path==='/quyen-rieng'?privateAccessPage():privateAccessScript(),{headers:{...headers,'Content-Type':path==='/quyen-rieng'?'text/html; charset=utf-8':'application/javascript; charset=utf-8'}});
    if(path!=='/quyen-rieng-api'||request.method!=='POST')return new Response(null,{status:405,headers});
    if(request.headers.get('Origin')&&request.headers.get('Origin')!==new URL(request.url).origin)return new Response(null,{status:403,headers});
    if(request.headers.get('Content-Type')?.split(';')[0]!=='application/json')return new Response(null,{status:415,headers});
    const raw=await readLimitedBody(request,160000);if(raw===null)return new Response(null,{status:413,headers});
    try{const r=await privateAccessService(env).fetch(new Request('https://internal/private-access/api',{method:'POST',headers:{Authorization:request.headers.get('Authorization')??''},body:raw}));return new Response(r.body,{status:r.status,headers:{...headers,'Content-Type':'application/json'}});}catch{return Response.json({error:'Chưa đọc được cài đặt.'},{status:503,headers});}
  }
  if(env.EXTENSIONS_ENABLED==='true'&&['/tai-len','/portal.js','/portal-api'].includes(path)){
    const secure={'Cache-Control':'no-store','Referrer-Policy':'no-referrer','X-Content-Type-Options':'nosniff','Content-Security-Policy':"default-src 'none'; script-src 'self'; style-src 'unsafe-inline'; connect-src 'self'; media-src blob:; img-src blob: data:; frame-ancestors 'none'; base-uri 'none'; form-action 'none'"};
    if(request.method==='GET'&&path!=='/portal-api')return new Response(path==='/tai-len'?portalPage():portalScript,{headers:{...secure,'Content-Type':path==='/tai-len'?'text/html; charset=utf-8':'application/javascript; charset=utf-8'}});
    if(path!=='/portal-api'||request.method!=='POST')return new Response(null,{status:405,headers:secure});
    const origin=request.headers.get('Origin');if(origin&&origin!==new URL(request.url).origin)return new Response(null,{status:403,headers:secure});
    const auth=request.headers.get('Authorization');if(!/^Bearer [a-f0-9]{64}$/.test(auth??''))return Response.json({error:'Liên kết không hợp lệ.'},{status:403,headers:secure});
    const stub=env.INBOX.get(env.INBOX.idFromName(EXTENSION_NAME));
    try{
      const probe=await stub.fetch(new Request('https://internal/extension/portal',{method:'POST',headers:{'Content-Type':'application/json',Authorization:auth},body:JSON.stringify({action:'session'})}));
      if(!probe.ok)return new Response(probe.body,{status:probe.status,headers:{...secure,'Content-Type':'application/json'}});
      if(request.headers.get('Content-Type')?.split(';')[0]!=='application/json')return Response.json({error:'json-required'},{status:415,headers:secure});
      const max=32*1024*1024;if(Number(request.headers.get('Content-Length'))>max)return Response.json({error:'body-too-large'},{status:413,headers:secure});
      // Forward a bounded stream; do not buffer/parse a large base64 file again in the front Worker.
      let size=0,tooLarge=false;const reader=request.body?.getReader();if(!reader)return Response.json({error:'json-required'},{status:400,headers:secure});
      const stream=new ReadableStream({async pull(controller){try{const part=await reader.read();if(part.done){controller.close();return;}size+=part.value.byteLength;if(size>max){tooLarge=true;await reader.cancel();controller.error(Error('body-too-large'));return;}controller.enqueue(part.value);}catch(e){controller.error(e);}},cancel:()=>reader.cancel()});
      let r;try{r=await stub.fetch(new Request('https://internal/extension/portal',{method:'POST',headers:{'Content-Type':'application/json',Authorization:auth},body:stream,duplex:'half'}));}catch(e){if(tooLarge)return Response.json({error:'body-too-large'},{status:413,headers:secure});throw e;}
      if(tooLarge)return Response.json({error:'body-too-large'},{status:413,headers:secure});
      return new Response(r.body,{status:r.status,headers:{...secure,'Content-Type':['image/png','image/jpeg'].includes(r.headers.get('Content-Type'))?r.headers.get('Content-Type'):'application/json'}});
    }catch{return Response.json({error:'portal-unavailable'},{status:503,headers:secure});}
  }
  if (request.method === 'GET' && path === '/health') {let resourcesImport={status:'disabled'};if(env.EXTENSIONS_ENABLED==='true'){try{const r=await env.INBOX.get(env.INBOX.idFromName(EXTENSION_NAME)).fetch(new Request('https://internal/extension/resource-import-status',{method:'POST',body:'{}'}));resourcesImport=r.ok?await r.json():{status:'unavailable'};}catch{resourcesImport={status:'unavailable'};}}return Response.json({resourcesImport,
    mode: 'cloud-preparation', enabled: env.BOT_ENABLED === 'true',
    configured: secretValid(env.WEBHOOK_SECRET) && Boolean(env.ZALO_BOT_TOKEN) && Boolean(env.INBOX),
    realServiceVerified: false
  });}
  if (path !== '/webhook') return Response.json({ error: 'not-found' }, { status: 404 });
  if (request.method !== 'POST') return Response.json({ error: 'method-not-allowed' }, { status: 405 });
  if (!secretValid(env.WEBHOOK_SECRET) || !env.ZALO_BOT_TOKEN || !env.INBOX)
    return Response.json({ error: 'missing-config' }, { status: 503 });
  const suppliedSecret = request.headers.get('X-Bot-Api-Secret-Token');
  const secretMatches = equalSecret(suppliedSecret, env.WEBHOOK_SECRET);
  const diagnosticUntil = Date.parse(env.WEBHOOK_AUTH_CHECK_UNTIL ?? '');
  if (Number.isFinite(diagnosticUntil) && Date.now() < diagnosticUntil) {
    // Temporary boolean-only diagnostic. Never log headers, body, URL, or identifiers.
    try { console.log('WEBHOOK_AUTH_CHECK', JSON.stringify({
      headerPresent: suppliedSecret !== null, secretMatches,
      javaClient: /^Java\//i.test(request.headers.get('user-agent') ?? '')
    })); } catch {} // Diagnostics must not change authentication behavior.
  }
  if (!secretMatches)
    return Response.json({ error: 'unauthorized' }, { status: 403 });
  if (env.BOT_ENABLED !== 'true'&&env.RECOVERY_ENABLED!=='true') return Response.json({ error: 'paused' }, { status: 503 });
  if (request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json')
    return Response.json({ error: 'json-required' }, { status: 415 });
  let event;
  try {
    const raw = await readLimitedBody(request, 16384);
    if (raw === null) return Response.json({ error: 'body-too-large' }, { status: 413 });
    const body = JSON.parse(raw);
    if (Number.isFinite(diagnosticUntil) && Date.now() < diagnosticUntil) {
      try { console.log('WEBHOOK_SHAPE_CHECK', JSON.stringify(eventShape(body))); } catch {}
    }
    event = normalizeEvent(body, { includeText: true, includeTimestamp: env.DATA_RETENTION_ENABLED === 'true'||env.RECOVERY_ENABLED==='true', includeGroups: env.GROUP_ENABLED === 'true', includeImages: env.IMAGE_ENABLED === 'true' && env.AI_ENABLED === 'true',includeGroupImages:env.EXTENSIONS_ENABLED==='true'&&env.GROUP_IMAGE_ENABLED==='true',includeVoice:env.EXTENSIONS_ENABLED==='true'&&env.VOICE_ENABLED==='true'&&env.AI_ENABLED==='true' });
  } catch { return Response.json({ error: 'invalid-json' }, { status: 400 }); }
  if (Number.isFinite(diagnosticUntil) && Date.now() < diagnosticUntil) {
    try { console.log('WEBHOOK_EVENT_RESULT', JSON.stringify({kind:event.kind,reason:event.reason??null})); } catch {}
  }
  if(env.RECOVERY_ENABLED==='true'&&event.kind==='text'&&event.chatType!=='GROUP'&&/^\/khoiphuc$/i.test(event.text?.trim()??'')&&adminIds(env.CATALOG_ADMIN_IDS_JSON).includes(event.senderId)){
    if(!Number.isFinite(event.eventAt)||Math.abs(Date.now()-event.eventAt)>86400000)return Response.json({status:'ignored',reason:'expired-recovery-command'});
    const session=await recoveryCall(env,'command',{actor:event.senderId,key:event.key});if(session.claimed){
      const origin=new URL(env.PUBLIC_BOT_ORIGIN).origin;const sender=createZaloSender({botToken:env.ZALO_BOT_TOKEN,fetchImpl:(...args)=>globalThis.fetch(...args)});await sender.send({chat_id:event.chatId,text:'Mở trang sao lưu và khôi phục riêng (dùng trong 15 phút):\n'+origin+'/khoi-phuc#'+session.token+'\nGiữ riêng link này.'});
    }
    return Response.json({status:'accepted'});
  }
  if(env.RECOVERY_ROUTING?.maintenance)return Response.json({status:'ignored',reason:'recovery-maintenance'});
  if(env.BOT_ENABLED!=='true')return Response.json({error:'paused'},{status:503});
  const textEnabled=env.PRIVATE_ACCESS_ENABLED==='true'||env.EXTENSIONS_ENABLED==='true'||env.AI_ENABLED==='true'||env.CATALOG_ADMIN_ENABLED==='true'||env.GROUP_ACTIVATION_ENABLED==='true';
  if(!textEnabled&&!/^\/id(?:\s|$)/i.test(event.text??''))delete event.text;
  if (event.kind === 'invalid') return Response.json({ error: 'invalid-event' }, { status: 400 });
  if (event.kind === 'ignored') return Response.json({ status: 'ignored', reason: event.reason });
  if (event.chatType === 'GROUP' && env.GROUP_ACTIVATION_ENABLED !== 'true' && !groupAllowed(env, event.chatId))
    return Response.json({ status: 'ignored', reason: 'group-not-allowed' });
  try {
    if(!await privateAllowed(env,event))return Response.json({status:'ignored',reason:'private-user-not-allowed'});
    if(isPrivateAccessCommand(event.text))event.accessOrigin=new URL(request.url).origin;
    const id = env.INBOX.idFromName(inboxName(event));
    const response = await env.INBOX.get(id).fetch(new Request('https://inbox.internal/enqueue', {
      method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(event)
    }));
    if (Number.isFinite(diagnosticUntil) && Date.now() < diagnosticUntil) {
      try { const result=await response.clone().json(); console.log('INBOX_RESULT', JSON.stringify({httpStatus:response.status,status:result.status??null})); } catch {}
    }
    return response;
  } catch { return Response.json({ error: 'state-unavailable' }, { status: 503 }); }
}
