import { eventAgeReason, RECEIPT_TTL, FUTURE_SKEW, MAX_OPERATION_RECEIPTS, setEarlierAlarm } from './luu-du-lieu.mjs';
import { GROUP_ADMIN_REPLY } from './nhom-chat.mjs';
// Monthly conservative allowance, not a provider invoice or per-key token ledger.
// Existing trials remain untouched. October reserves their worst-case $0.30.
export const MONTH_LIMIT = 1000000;
export const ATTEMPT_ALLOWANCE = 2000;
export const isOperationCommand = text => typeof text === 'string' && /^\/(trangthai|tatai|batai)(?:\s|$)/i.test(text.trim());
export function monthVN(time) {
  if (!Number.isFinite(time)) throw Error('invalid-clock');
  const period = new Date(time + 7 * 3600000).toISOString().slice(0, 7);
  if (!/^20\d{2}-(0[1-9]|1[0-2])$/.test(period) || period < '2026-10') throw Error('invalid-period');
  return period;
}
const initial = period => ({ period, calls: 0, reservedMicroUsd: period === '2026-10' ? 300000 : 0 });
function validate(state, period) {
  const base = period === '2026-10' ? 300000 : 0;
  if (state?.period !== period || !Number.isSafeInteger(state.calls) || state.calls < 0 ||
      state.reservedMicroUsd !== base + state.calls * ATTEMPT_ALLOWANCE || state.reservedMicroUsd > MONTH_LIMIT)
    throw Error('invalid-month-state');
  return state;
}
async function digest(key) {
  if (typeof key !== 'string' || !key || key.length > 2048) throw Error('invalid-event-key');
  const bytes = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(key));
  return [...new Uint8Array(bytes)].map(v => v.toString(16).padStart(2, '0')).join('');
}
export class OperatingBudget {
  constructor(storage, { now = Date.now, admins = [] } = {}) {
    this.storage = storage; this.now = now; this.admins = new Set(admins);
  }
  async state() {
    const period = monthVN(this.now());
    const latest = await this.storage.get('operation:latest-month');
    if (latest !== undefined && (!/^20\d{2}-(0[1-9]|1[0-2])$/.test(latest) || latest > period))
      throw Error('clock-or-state-invalid');
    const control = await this.storage.get('operation:control') ?? { paused: false };
    if (typeof control.paused !== 'boolean') throw Error('invalid-control-state');
    const state = validate(await this.storage.get(`operation:month:${period}`) ?? initial(period), period);
    return { state, control };
  }
  async reserve(key) {
    const hashed = await digest(key);
    return this.storage.transaction(async () => {
      const { state, control } = await this.state();
      if (control.paused) return { allowed: false, reason: 'ai-paused' };
      // Separate persistent dedup survives a month change. Never replay an ambiguous paid call.
      if (await this.storage.get(`operation:allocated:${hashed}`) !== undefined)
        return { allowed: false, reason: 'already-allocated' };
      if (state.reservedMicroUsd + ATTEMPT_ALLOWANCE > MONTH_LIMIT)
        return { allowed: false, reason: 'monthly-limit' };
      state.calls++; state.reservedMicroUsd += ATTEMPT_ALLOWANCE;
      await this.storage.put(`operation:month:${state.period}`, state);
      await this.storage.put('operation:latest-month', state.period);
      await this.storage.put(`operation:allocated:${hashed}`, true);
      return { allowed: true };
    });
  }
  async handle(event) {
    if (event?.chatType === 'GROUP') return GROUP_ADMIN_REPLY;
    if (!isOperationCommand(event?.text)) return null;
    if (!this.admins.has(event.senderId) || typeof event.chatId !== 'string' || !event.chatId)
      return 'Anh/chị chưa có quyền quản lý vận hành bot.';
    const command = event.text.trim().toLowerCase();
    if (!['/trangthai', '/tatai', '/batai'].includes(command))
      return 'Các lệnh /trangthai, /tatai, /batai không nhận thêm tham số.';
    const hashed = await digest(JSON.stringify([event.chatId, event.key]));
    return this.storage.transaction(async () => {
      const previous = await this.storage.get(`operation:command:${hashed}`);
      if (previous !== undefined) return previous.actor === event.senderId ? previous.reply : 'Anh/chị chưa có quyền dùng lại thao tác này.';
      const { state, control } = await this.state();
      let reply;
      if (command === '/trangthai') {
        reply = `AI ${control.paused ? 'đang tắt' : 'đang bật'}. Tháng ${state.period.slice(5)}/${state.period.slice(0,4)} (giờ Việt Nam): hạn mức 1 USD; đã giữ dự phòng ${(state.reservedMicroUsd / 1000000).toFixed(3)} USD; còn ${((MONTH_LIMIT-state.reservedMicroUsd)/1000000).toFixed(3)} USD. Đây không phải hóa đơn OpenAI. Kho và quản lý kho vẫn hoạt động. Cấu hình có key không chứng minh API đang kết nối được.`;
      } else {
        control.paused = command === '/tatai';
        await this.storage.put('operation:control', control);
        reply = control.paused ? 'Đã tắt gọi AI. Kho và lệnh quản lý vẫn hoạt động; không hoàn lại hạn mức.'
          : 'Đã bật gọi AI trong hạn mức tháng còn lại. Không làm mới ngân sách hoặc gọi lại tin cũ.';
      }
      await this.storage.put(`operation:command:${hashed}`, { actor: event.senderId, reply });
      return reply;
    });
  }
}
export function aiFailureReply(reason, fallback, chatType = 'PRIVATE') {
  if (reason === 'receipt-capacity') return 'Bot đã đầy dấu chống gọi trùng đang giữ. Chưa gọi AI; người quản lý cần kiểm tra dung lượng. Kho vẫn hoạt động.';
  if (['expired-event', 'invalid-event-time', 'future-event'].includes(reason)) return 'Tin đã quá thời gian nhận hoặc sai thời gian. Bot chưa gọi AI và không tự chạy lại tin cũ.';
  if (reason === 'invalid-ai-key-format') return 'Key OpenAI đang lưu sai định dạng (có dấu hoặc khoảng trắng). Người quản lý cần copy lại key nguyên gốc vào OPENAI_API_KEY trên Cloudflare. Kho vẫn hoạt động; bot chưa gọi API AI.';
  if (reason === 'provider-setup') return 'Bot đang chờ người quản lý hoàn tất Project và key OpenAI riêng. Tra giá trong kho vẫn hoạt động.';
  if (reason === 'monthly-limit') return 'Bot đã hết hạn mức AI tháng này. Hạn mức mới bắt đầu ngày 01 tháng kế tiếp theo giờ Việt Nam; tra giá trong kho vẫn hoạt động.';
  if (reason === 'ai-paused') return `Em đang tạm ngừng trả lời bằng AI trong ${chatType === 'GROUP' ? 'nhóm này' : 'chat riêng'}.`;
  if (reason === 'quota') return 'Dịch vụ AI đang giới hạn lượt gọi hoặc hết số dư. Bot chưa tạo được câu trả lời; người quản lý cần kiểm tra OpenAI.';
  if (reason === 'api-rejected') return 'Kết nối AI bị từ chối. Bot chưa tạo được câu trả lời; người quản lý cần kiểm tra key và model.';
  if (reason === 'timeout') return 'AI chưa phản hồi trong thời gian cho phép. Bot không tự gọi lại lượt này; anh/chị có thể gửi câu hỏi mới.';
  return fallback;
}

// Active provider mode: no local monetary counter. Preserve old records without reading them.
export class OperatingControl {
  constructor(storage, { admins = [], providerReady = false, retentionEnabled = false, now = Date.now } = {}) {
    this.storage = storage; this.admins = new Set(admins); this.providerReady = providerReady === true;
    this.retentionEnabled = retentionEnabled === true; this.now = now;
  }
  async maintainRows() {
    let retained = 0, next = Infinity, removed = 0;
    for (const prefix of ['operation:allocated:', 'operation:command:']) {
      const rows = await this.storage.list({ prefix });
      for (const [key, row] of rows) {
        // Historical booleans/commands have no reliable receipt time: never erase them.
        if (row?.retentionVersion !== 1 || !Number.isSafeInteger(row.at) || row.at <= 0 ||
          !Number.isSafeInteger(row.eventAt) || row.eventAt <= 0 || row.at > this.now() || row.eventAt > row.at + FUTURE_SKEW) continue;
        const until = Math.max(row.at, row.eventAt) + RECEIPT_TTL + 1;
        if (this.now() >= until) { await this.storage.delete(key); removed++; }
        else { retained++; next = Math.min(next, until); }
      }
    }
    await setEarlierAlarm(this.storage, next, this.now());
    return { retained, removed };
  }
  async maintain() {
    if (!this.retentionEnabled) return { retained: 0, removed: 0 };
    return this.storage.transaction(() => this.maintainRows());
  }
  async control() {
    const value = await this.storage.get('operation:control') ?? { paused: false };
    if (typeof value.paused !== 'boolean' || ['privatePaused','groupPaused'].some(k=>value[k]!==undefined&&typeof value[k]!=='boolean')) throw Error('invalid-control-state');
    return {...value,privatePaused:value.privatePaused??value.paused,groupPaused:value.groupPaused??value.paused};
  }
  async permission(chatType='PRIVATE') {
    if(!['PRIVATE','GROUP'].includes(chatType))return {allowed:false,reason:'invalid-ai-scope'};
    const control=await this.control();
    if(chatType==='GROUP'?control.groupPaused:control.privatePaused)return {allowed:false,reason:'ai-paused'};
    return this.providerReady?{allowed:true}:{allowed:false,reason:'provider-setup'};
  }
  async reserve(key, { eventAt, chatType='PRIVATE' } = {}) {
    const hashed = await digest(key);
    return this.storage.transaction(async () => {
      if (this.retentionEnabled) {
        const reason = eventAgeReason(eventAt, this.now());
        if (reason) return { allowed: false, reason };
      }
      const permission=await this.permission(chatType);if(!permission.allowed)return permission;
      if (await this.storage.get(`operation:allocated:${hashed}`) !== undefined)
        return { allowed: false, reason: 'already-allocated' };
      if (this.retentionEnabled && (await this.maintainRows()).retained >= MAX_OPERATION_RECEIPTS)
        return { allowed: false, reason: 'receipt-capacity' };
      await this.storage.put(`operation:allocated:${hashed}`, this.retentionEnabled
        ? { retentionVersion: 1, at: this.now(), eventAt } : true);
      if (this.retentionEnabled) await setEarlierAlarm(this.storage, Math.max(this.now(), eventAt) + RECEIPT_TTL + 1, this.now());
      return { allowed: true };
    });
  }
  async handle(event) {
    if (event?.chatType === 'GROUP') return GROUP_ADMIN_REPLY;
    if (!isOperationCommand(event?.text)) return null;
    if (!this.admins.has(event.senderId) || typeof event.chatId !== 'string' || !event.chatId)
      return 'Anh/chị chưa có quyền quản lý vận hành bot.';
    const command = event.text.trim().toLowerCase(),match=command.match(/^\/(tatai|batai)(?:\s+(rieng|nhom))?$/);
    if (command!=='/trangthai'&&!match)
      return 'Dùng /trangthai, /tatai hoặc /batai. Thêm rieng hay nhom để chọn phạm vi.';
    const hashed = await digest(JSON.stringify([event.chatId, event.key]));
    return this.storage.transaction(async () => {
      if (this.retentionEnabled && eventAgeReason(event.eventAt, this.now()))
        return 'Tin quản lý đã cũ hoặc sai thời gian. Chưa thay đổi trạng thái bot.';
      const previous = await this.storage.get(`operation:command:${hashed}`);
      if (previous !== undefined) return previous.actor === event.senderId ? previous.reply : 'Anh/chị chưa có quyền dùng lại thao tác này.';
      const control = await this.control();
      if (this.retentionEnabled && (await this.maintainRows()).retained >= MAX_OPERATION_RECEIPTS)
        return 'Bot đã đầy dấu chống trùng đang giữ. Chưa thay đổi trạng thái; người quản lý cần kiểm tra.';
      let reply;
      const status=()=>`AI chat riêng: ${control.privatePaused?'TẮT':this.providerReady?'BẬT':'đang chờ cấu hình Project OpenAI riêng'}.\nAI nhóm: ${control.groupPaused?'TẮT':this.providerReady?'BẬT':'đang chờ cấu hình Project OpenAI riêng'}.`;
      if (command === '/trangthai') {
        reply = status();
      } else {
        const paused=match[1]==='tatai',scope=match[2];
        if(scope!=='nhom')control.privatePaused=paused;
        if(scope!=='rieng')control.groupPaused=paused;
        control.paused=control.privatePaused&&control.groupPaused;
        await this.storage.put('operation:control', control);
        reply = `Đã ${paused?'tắt':'bật'} AI ${scope==='rieng'?'trong chat riêng':scope==='nhom'?'trong nhóm':'cho chat riêng và nhóm'}.\n`+status();
      }
      await this.storage.put(`operation:command:${hashed}`, { actor: event.senderId, reply,
        ...(this.retentionEnabled ? { retentionVersion: 1, at: this.now(), eventAt: event.eventAt } : {}) });
      if (this.retentionEnabled) await setEarlierAlarm(this.storage, Math.max(this.now(), event.eventAt) + RECEIPT_TTL + 1, this.now());
      return reply;
    });
  }
}
