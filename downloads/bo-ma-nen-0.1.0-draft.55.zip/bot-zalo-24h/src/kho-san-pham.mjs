const codesIn = text => [...new Set(text.toUpperCase().match(/\b[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+\b/g) ?? [])];
const exactKeys = (o,keys) => o && typeof o === 'object' && !Array.isArray(o) &&
  Object.keys(o).length === keys.length && keys.every(k => Object.hasOwn(o,k));
// Read-only configuration; no chat upload/update route or executable source text.
export function readCatalog(raw) {
  if (typeof raw !== 'string' || new TextEncoder().encode(raw).length > 24000) return null;
  try {
    const body=JSON.parse(raw);
    if (!exactKeys(body,['version','products']) || ![1,2].includes(body.version) ||
      !Array.isArray(body.products) || body.products.length > 100) return null;
    const codes=new Set();
    for(const p of body.products) {
      const shape=body.version===1?exactKeys(p,['code','name','priceVnd','warrantyDays','status','source','updated']):exactKeys(p,['code','name','fields','status','source','updated']);
      const facts=body.version===1?Number.isSafeInteger(p.priceVnd)&&p.priceVnd>=0&&p.priceVnd<=1000000000&&Number.isSafeInteger(p.warrantyDays)&&p.warrantyDays>=0&&p.warrantyDays<=3650:
        Array.isArray(p.fields)&&p.fields.length>0&&p.fields.length<=20&&new Set(p.fields.map(f=>f?.key)).size===p.fields.length&&p.fields.every(f=>exactKeys(f,['key','label','value'])&&typeof f.key==='string'&&/^[a-z][a-z0-9-]{0,39}$/.test(f.key)&&typeof f.label==='string'&&f.label.trim()&&f.label.length<=80&&typeof f.value==='string'&&f.value.trim()&&f.value.length<=500&&!/[\x00-\x1f]/.test(f.label+f.value));
      if(!shape || !facts ||
        typeof p.code !== 'string' || !/^[A-Z][A-Z0-9]*(?:-[A-Z0-9]+)+$/.test(p.code) || p.code.length>40 || codes.has(p.code) ||
        typeof p.name !== 'string' || !p.name.trim() || p.name.length>100 || /[\r\n\x00-\x1f]/.test(p.name) ||
        !['active','draft','revoked'].includes(p.status) || typeof p.source !== 'string' ||
        !/^[a-z0-9-]{1,60}$/.test(p.source) || typeof p.updated !== 'string' ||
        !/^\d{2}\/\d{2}\/\d{4}$/.test(p.updated)) return null;
      const [d,m,y]=p.updated.split('/').map(Number), date=new Date(Date.UTC(y,m-1,d));
      if(date.getUTCFullYear()!==y || date.getUTCMonth()!==m-1 || date.getUTCDate()!==d) return null;
      codes.add(p.code);
    }
    return body.products.filter(p=>p.status==='active').map(p=>({...p}));
  } catch {return null;}
}

export const formatProduct=p=>p.fields?`${p.code} — ${p.name} — `+p.fields.map(f=>`${f.label}: ${f.value}`).join('; '):`${p.code} — ${p.name} — ${p.priceVnd.toLocaleString('vi-VN')} đồng — Bảo hành ${p.warrantyDays} ngày.`;
const words=t=>t.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').replace(/[^a-z0-9]+/g,' ').trim();

// Returns null only for questions outside the bounded product contract.
// Numbers come from current configured facts, never from earlier chat claims.
export function productReply(text,history,catalog) {
  let codes=codesIn(text);
  // Internal codes are optional in customer questions. Match complete names, never guess a similar item.
  if(!codes.length&&Array.isArray(catalog)){
    const query=' '+words(text)+' ';
    codes=catalog.filter(p=>query.includes(' '+words(p.name)+' ')).map(p=>p.code);
  }
  const productQuestion=/giá|bảo hành|bao nhiêu tiền/i.test(text);
  const productCode=code=>code.startsWith('SP-')||Array.isArray(catalog)&&catalog.some(p=>p.code===code);
  // A source/document ID is not a product request just because it has hyphens.
  if(!productQuestion&&codes.length&&!codes.some(productCode)) return null;
  if(!codes.length && !productQuestion) return null;
  if(!codes.length && productQuestion) {
    for(const msg of [...history].reverse()) {
      if(msg.role==='user') {codes=codesIn(msg.content).filter(productCode);if(codes.length) break;}
    }
  }
  if(catalog===null) return 'Kho sản phẩm hiện chưa sẵn sàng. Anh/chị vui lòng chờ người quản lý kiểm tra dữ liệu.';
  if(!codes.length) return 'Anh/chị cho em mã sản phẩm cần hỏi giá hoặc bảo hành nhé.';
  if(codes.length>3) return 'Anh/chị hỏi tối đa 3 mã sản phẩm trong một tin nhé.';
  return codes.map(code=>{
    const p=catalog.find(v=>v.code===code);
    if(!p) return `${code}: chưa có dữ liệu sản phẩm có hiệu lực; em không thể xác định giá hoặc bảo hành.`;
    if(p.fields){
      if(/bảo hành/i.test(text)&&!p.fields.some(f=>/bao hanh/.test(words(f.label))))return `${p.name}: chưa có thông tin bảo hành trong nguồn đã duyệt.`;
      if(/giá|bao nhiêu tiền|học phí/i.test(text)&&!p.fields.some(f=>/\bgia\b|hoc phi|price/.test(words(f.label))))return `${p.name}: chưa có thông tin giá hoặc học phí trong nguồn đã duyệt.`;
    }
    return formatProduct(p);
  }).join('\n');
}
