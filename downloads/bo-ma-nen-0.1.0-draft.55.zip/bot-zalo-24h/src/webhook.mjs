import { normalizeEvent } from './chuan-tin.mjs';
import { FIXED_REPLY } from './gui-tin.mjs';

const json = (status, body) => Response.json(body, { status });
export const secretValid = value => typeof value === 'string' && value.length >= 8 && value.length <= 256;
export function equalSecret(actual, expected) {
  if (typeof actual !== 'string' || actual.length > 256) return false;
  let diff = actual.length ^ expected.length;
  for (let i = 0; i < expected.length; i++) diff |= (actual.charCodeAt(i) || 0) ^ expected.charCodeAt(i);
  return diff === 0;
}
export async function readLimitedBody(request, limit) {
  const reader = request.body?.getReader();
  if (!reader) return '';
  const chunks = [];
  let count = 0;
  try {
    while (true) {
      const part = await reader.read();
      if (part.done) break;
      count += part.value.byteLength;
      if (count > limit) { await reader.cancel(); return null; }
      chunks.push(part.value);
    }
  } finally { reader.releaseLock(); }
  const bytes = new Uint8Array(count);
  let offset = 0;
  for (const chunk of chunks) { bytes.set(chunk, offset); offset += chunk.byteLength; }
  return new TextDecoder('utf-8', { fatal: true }).decode(bytes);
}

export function createLocalHandler({ webhookSecret, sender, store, maxBodyBytes = 16384 } = {}) {
  return async function handle(request) {
    const path = new URL(request.url).pathname;
    if (request.method === 'GET' && path === '/health') {
      return json(200, { mode: 'local-only', productionReady: false });
    }
    if (path !== '/webhook') return json(404, { error: 'not-found' });
    if (request.method !== 'POST') return json(405, { error: 'method-not-allowed' });
    if (!secretValid(webhookSecret) || typeof sender?.send !== 'function' ||
        typeof store?.claim !== 'function' || typeof store?.finish !== 'function' ||
        !Number.isInteger(maxBodyBytes) || maxBodyBytes < 1) return json(503, { error: 'missing-or-invalid-local-config' });
    if (!equalSecret(request.headers.get('X-Bot-Api-Secret-Token'), webhookSecret)) {
      return json(403, { error: 'unauthorized' });
    }
    if (request.headers.get('content-type')?.split(';')[0].trim().toLowerCase() !== 'application/json') {
      return json(415, { error: 'json-required' });
    }
    let body;
    try {
      const raw = await readLimitedBody(request, maxBodyBytes);
      if (raw === null) return json(413, { error: 'body-too-large' });
      body = JSON.parse(raw);
    } catch { return json(400, { error: 'invalid-json' }); }
    const event = normalizeEvent(body);
    if (event.kind === 'invalid') return json(400, { error: 'invalid-event' });
    if (event.kind === 'ignored') return json(200, { status: 'ignored', reason: event.reason });
    let claim;
    try { claim = store.claim(event.key); }
    catch { return json(503, { error: 'state-unavailable' }); }
    if (!claim.claimed) {
      if (claim.status === 'capacity') return json(503, { error: 'state-capacity' });
      return json(200, { status: 'duplicate', delivery: claim.status });
    }
    let outcome;
    try { outcome = await sender.send({ chat_id: event.chatId, text: FIXED_REPLY }); }
    catch { outcome = { status: 'uncertain' }; }
    const status = ['sent', 'rejected', 'uncertain'].includes(outcome?.status) ? outcome.status : 'uncertain';
    try { store.finish(event.key, status); }
    catch { return json(503, { error: 'state-write-failed' }); }
    return json(200, { status, attempts: claim.attempts });
  };
}

// No production entrypoint, credentials, global memory wiring, or outbound transport.
export default {
  async fetch() { return json(503, { error: 'local-prototype-only', productionReady: false }); }
};
