// Bounded AAC-LC ADTS to M4A remux. Copies compressed samples; no decoding,
// external process, disk, network, or additional AI request is required.
const rates=[96000,88200,64000,48000,44100,32000,24000,22050,16000,12000,11025,8000,7350];
const join=(...parts)=>{const out=new Uint8Array(parts.reduce((n,p)=>n+p.length,0));let at=0;for(const p of parts){out.set(p,at);at+=p.length;}return out;};
const text=s=>new TextEncoder().encode(s);
const zero=n=>new Uint8Array(n);
const u16=n=>new Uint8Array([n>>>8&255,n&255]);
const u32=n=>new Uint8Array([n>>>24&255,n>>>16&255,n>>>8&255,n&255]);
const box=(type,...parts)=>{const body=join(...parts);return join(u32(body.length+8),text(type),body);};
const full=(type,flags,...parts)=>box(type,u32(flags),...parts);
const matrix=join(u32(65536),u32(0),u32(0),u32(0),u32(65536),u32(0),u32(0),u32(0),u32(0x40000000));
const descriptor=(tag,body)=>{if(body.length>=128)throw Error('descriptor-too-long');return join(new Uint8Array([tag,body.length]),body);};
export const isAdts=b=>b?.length>=7&&b[0]===255&&(b[1]&246)===240;
export function remuxAdts(bytes){
 if(!isAdts(bytes)||bytes.length>8*1024*1024)return null;
 const samples=[];let at=0,config;
 while(at<bytes.length){
  const b=bytes.subarray(at);if(!isAdts(b))return null;
  const profile=(b[2]>>>6)+1,index=b[2]>>>2&15,channels=(b[2]&1)<<2|b[3]>>>6;
  const header=b[1]&1?7:9,size=(b[3]&3)<<11|b[4]<<3|b[5]>>>5;
  if(profile!==2||!rates[index]||rates[index]>48000||channels<1||channels>2||(b[6]&3)!==0||size<=header||at+size>bytes.length)return null;
  const key=profile+':'+index+':'+channels;if(config&&config.key!==key)return null;
  config={key,profile,index,channels,rate:rates[index]};
  samples.push(bytes.subarray(at+header,at+size));at+=size;
  if(samples.length>30000)return null;
 }
 if(!samples.length)return null;
 const {profile,index,channels,rate}=config,duration=samples.length*1024;
 const asc=new Uint8Array([profile<<3|index>>>1,(index&1)<<7|channels<<3]);
 const es=descriptor(3,join(u16(1),zero(1),descriptor(4,join(new Uint8Array([0x40,0x15]),zero(3),u32(0),u32(0),descriptor(5,asc))),descriptor(6,new Uint8Array([2]))));
 const sample=box('mp4a',zero(6),u16(1),zero(8),u16(channels),u16(16),zero(4),u32(rate*65536),full('esds',0,es));
 const ftyp=box('ftyp',text('M4A '),u32(0),text('M4A '),text('isom'),text('mp42'));
 const moov=offset=>box('moov',
  full('mvhd',0,zero(8),u32(rate),u32(duration),u32(65536),u16(256),zero(10),matrix,zero(24),u32(2)),
  box('trak',full('tkhd',7,zero(8),u32(1),u32(0),u32(duration),zero(8),u16(0),u16(0),u16(256),u16(0),matrix,zero(8)),
   box('mdia',full('mdhd',0,zero(8),u32(rate),u32(duration),u16(0x55c4),u16(0)),
    full('hdlr',0,u32(0),text('soun'),zero(12),text('Audio\0')),
    box('minf',full('smhd',0,zero(4)),box('dinf',full('dref',0,u32(1),full('url ',1))),
     box('stbl',full('stsd',0,u32(1),sample),full('stts',0,u32(1),u32(samples.length),u32(1024)),
      full('stsc',0,u32(1),u32(1),u32(samples.length),u32(1)),
      full('stsz',0,u32(0),u32(samples.length),...samples.map(s=>u32(s.length))),
      full('stco',0,u32(1),u32(offset)))))));
 const metadata=moov(0),offset=ftyp.length+metadata.length+8;
 return join(ftyp,moov(offset),box('mdat',...samples));
}
