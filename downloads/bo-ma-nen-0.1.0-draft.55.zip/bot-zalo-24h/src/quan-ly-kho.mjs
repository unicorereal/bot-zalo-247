import { readCatalog, formatProduct } from './kho-san-pham.mjs';
import { isOperationCommand } from './van-hanh-ai.mjs';
import { GROUP_ADMIN_REPLY } from './nhom-chat.mjs';

const validId = v => typeof v === 'string' && v.length > 0 && v.length <= 256;
const commandPattern = /^\/(suakho|thuhoikho|duyetkho|huykho|xemkho|id|quyenrieng|nguon)(?:\s|$)/i;
// All administrative commands are excluded from AI history by this shared predicate.
export const isCatalogCommand = text => typeof text === 'string' && (commandPattern.test(text.trim()) || isOperationCommand(text));
export function adminIds(raw) {
  try {
    const ids = JSON.parse(raw);
    return Array.isArray(ids) && ids.length > 0 && ids.length <= 10 && ids.every(validId)
      && new Set(ids).size === ids.length ? ids : [];
  } catch { return []; }
}
const parse = raw => readCatalog(raw) === null ? null : JSON.parse(raw);
const format = p => p.fields?formatProduct(p)+`, ${p.status}`:`${p.code}: ${p.priceVnd.toLocaleString('vi-VN')} đồng, bảo hành ${p.warrantyDays} ngày, ${p.status}`;
export const identityReply=event=>{
  if(!/^\/id(?:\s|$)/i.test(event?.text?.trim()??''))return null;
  if(event.chatType==='GROUP')return GROUP_ADMIN_REPLY;
  if(event.text.trim().toLowerCase()!=='/id')return 'Lệnh /id không nhận thêm tham số và không duyệt thay đổi kho.';
  return validId(event.senderId)&&validId(event.chatId)?`ID của tài khoản anh/chị: ${event.senderId}. Lệnh này không cấp quyền quản lý.`:'Chưa xác định được ID tài khoản.';
};
const denied = 'Anh/chị chưa có quyền quản lý kho. Người sở hữu bot cần cấu hình quyền riêng.';

// Internal service only. Actor/chat come from authenticated, normalized webhook,
// never display names, quotes, catalog text, or a public request body.
export class CatalogManager {
  constructor(storage, { admins = [], initialCatalog, initialImport, now = Date.now } = {}) {
    this.storage = storage;
    this.admins = new Set(admins.filter(validId));
    this.initial = initialCatalog;
    this.initialImport=typeof initialImport==='string'&&/^[a-zA-Z0-9-]{1,80}$/.test(initialImport)?initialImport:null;
    this.now = now;
  }
  async current() {
    if(this.initialImport){
      const imported=parse(this.initial);if(!imported)return null;
      await this.storage.transaction(async()=>{
        const old=await this.storage.get('catalog:head');if(old?.importRevision===this.initialImport)return;
        if(old&&(!Number.isSafeInteger(old.revision)||old.revision<0))throw Error('catalog-corrupt');
        const revision=old?old.revision+1:0;
        if(old)await this.storage.put(`catalog:revision:${old.revision}`,{raw:old.raw,revision:old.revision});
        await this.storage.put('catalog:head',{revision,raw:this.initial,events:old?.events??0,drafts:old?.drafts??0,importRevision:this.initialImport});
      });
    }
    const head = await this.storage.get('catalog:head');
    if (head === undefined) return parse(this.initial);
    if (!Number.isSafeInteger(head.revision) || head.revision < 0) return null;
    return parse(head.raw);
  }
  async handle(event) {
    if (event?.chatType === 'GROUP') return GROUP_ADMIN_REPLY;
    if (typeof event?.text !== 'string' || !commandPattern.test(event.text.trim())) return null;
    // Send only the requester's ID back to their own authenticated private chat.
    // This does not enroll anyone and is never included in shared reports/logs.
    if (identityReply(event)!==null)return identityReply(event);
    if (!validId(event.senderId) || !validId(event.chatId) || !this.admins.has(event.senderId)) return denied;
    if (typeof event.key !== 'string' || event.key.length > 1200 || !event.key || event.text.length > 1000)
      return 'Yêu cầu quản lý kho không hợp lệ.';
    if(this.initialImport&&await this.current()===null)return 'Dữ liệu nạp chưa hợp lệ. Chưa thay đổi kho.';
    return this.storage.transaction(async () => {
      const txKey = `catalog:event:${event.key}`;
      const previous = await this.storage.get(txKey);
      if (previous !== undefined) {
        return previous.actor === event.senderId && previous.chat === event.chatId ? previous.reply : denied;
      }
      let head = await this.storage.get('catalog:head');
      if (head === undefined) head = { revision: 0, raw: this.initial, events: 0, drafts: 0 };
      const body = parse(head.raw);
      if (!body || !Number.isSafeInteger(head.revision) || head.revision < 0 ||
          !Number.isSafeInteger(head.events) || head.events < 0 ||
          !Number.isSafeInteger(head.drafts) || head.drafts < 0)
        return 'Kho hiện lỗi dữ liệu. Chưa thay đổi kho; người sở hữu bot cần kiểm tra.';
      if (head.events >= 1000) return 'Kho đã đạt giới hạn 1.000 thao tác quản lý. Chưa thay đổi kho; cần người sở hữu kiểm tra.';
      const [command, ...args] = event.text.trim().split(/\s+/);
      const action = command.toLowerCase();
      let reply;
      const when = this.now();
      if (!Number.isFinite(when)) throw Error('invalid-clock');
      if (action === '/xemkho') {
        const p = body.products.find(p => p.code === args[0]?.toUpperCase());
        reply = args.length !== 1 ? 'Dùng /xemkho MÃ-SẢN-PHẨM.' : p ? format(p) : 'Chưa có mã này trong kho.';
      } else if (action === '/suakho' || action === '/thuhoikho') {
        const code = args[0]?.toUpperCase();
        const p = body.products.find(p => p.code === code);
        const numbers = args.slice(1);
        if (!p) reply = 'Chưa có mã này. Bản đầu chỉ sửa hoặc thu hồi sản phẩm đã có; chưa thêm sản phẩm mới.';
        else if (action === '/suakho' && body.version===1 && (args.length !== 3 || !numbers.every(n => /^\d+$/.test(n))))
          reply = 'Dùng /suakho MÃ-SẢN-PHẨM GIÁ-ĐỒNG SỐ-NGÀY-BẢO-HÀNH (số nguyên, không dấu phân cách).';
        else if (action === '/thuhoikho' && args.length !== 1) reply = 'Dùng /thuhoikho MÃ-SẢN-PHẨM.';
        else if (action === '/suakho' && p.status !== 'active') reply = 'Chỉ sửa sản phẩm đang có hiệu lực; không tự kích hoạt bản nháp hoặc sản phẩm đã thu hồi.';
        else {
          const next = structuredClone(p);
          if (action === '/thuhoikho') next.status = 'revoked';
          else if(body.version===2){
            const field=next.fields.find(f=>f.key===args[1]);
            const value=args.slice(2).join(' ');
            if(!field||!value||value.length>500)return 'Dùng /suakho MÃ-SẢN-PHẨM MÃ-TRƯỜNG GIÁ-TRỊ. Mã trường hiện có: '+next.fields.map(f=>f.key).join(', ')+'. Chưa thay đổi dữ liệu.';
            field.value=value;
          }else { next.priceVnd = Number(numbers[0]); next.warrantyDays = Number(numbers[1]); }
          const vn = new Date(when + 7 * 3600000).toISOString().slice(0, 10).split('-');
          next.updated = `${vn[2]}/${vn[1]}/${vn[0]}`;
          const proposed = structuredClone(body);
          proposed.products[proposed.products.findIndex(p => p.code === code)] = next;
          if (readCatalog(JSON.stringify(proposed)) === null) reply = 'Giá hoặc bảo hành ngoài giới hạn. Chưa thay đổi kho.';
          else {
            const number = ++head.drafts;
            await this.storage.put(`catalog:draft:${number}`, { number, actor: event.senderId, chat: event.chatId,
              base: head.revision, expires: when + 10 * 60000, status: 'pending', raw: JSON.stringify(proposed) });
            reply = `Bản nháp ${number}, chưa có hiệu lực.\nTrước: ${format(p)}\nSau: ${format(next)}\nGửi /duyetkho ${number} trong 10 phút để áp dụng, hoặc /huykho ${number}.`;
          }
        }
      } else {
        const number = args.length === 1 && /^[1-9]\d{0,3}$/.test(args[0]) ? Number(args[0]) : null;
        const draft = number === null ? null : await this.storage.get(`catalog:draft:${number}`);
        if (!draft || draft.actor !== event.senderId || draft.chat !== event.chatId)
          reply = 'Không có bản nháp này của anh/chị trong chat này.';
        else if (draft.status !== 'pending') reply = 'Bản nháp này đã kết thúc; không áp dụng lại.';
        else if (!Number.isFinite(draft.expires) || !Number.isSafeInteger(draft.base) || draft.base < 0 || draft.number !== number)
          reply = 'Bản nháp lỗi dữ liệu; chưa thay đổi kho.';
        else if (when >= draft.expires) {
          draft.status = 'expired'; reply = 'Bản nháp đã hết 10 phút. Hãy tạo bản nháp mới.';
          await this.storage.put(`catalog:draft:${number}`, draft);
        } else if (action === '/huykho') {
          draft.status = 'cancelled'; reply = 'Đã hủy bản nháp, giữ nguyên kho đang có hiệu lực.';
          await this.storage.put(`catalog:draft:${number}`, draft);
        } else if (draft.base !== head.revision) {
          draft.status = 'conflict'; reply = 'Kho đã có thay đổi mới. Chưa áp dụng bản nháp cũ; hãy tạo lại để xem dữ liệu mới.';
          await this.storage.put(`catalog:draft:${number}`, draft);
        } else if (parse(draft.raw) === null) reply = 'Bản nháp lỗi dữ liệu; chưa thay đổi kho.';
        else {
          await this.storage.put(`catalog:revision:${head.revision}`, { raw: head.raw, revision: head.revision });
          head.raw = draft.raw; head.revision++;
          draft.status = 'approved'; draft.approvedAt = when;
          await this.storage.put(`catalog:draft:${number}`, draft);
          await this.storage.put(`catalog:audit:${head.revision}`, { actor: event.senderId, chat: event.chatId,
            at: when, draft: number, revision: head.revision });
          reply = `Đã áp dụng bản nháp ${number}; kho đang có hiệu lực phiên bản ${head.revision}.`;
        }
      }
      head.events++;
      await this.storage.put('catalog:head', head);
      await this.storage.put(txKey, { actor: event.senderId, chat: event.chatId, reply });
      return reply;
    });
  }
}
