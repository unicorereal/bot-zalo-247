import {emptyExtensions,validateExtensions,selectKnowledge} from './mo-rong-du-lieu.mjs';
// AI prepares this private file from real sources; no runtime fetching of arbitrary links.
export function readReferences(raw){
 if(raw===undefined)return [];
 if(typeof raw!=='string'||new TextEncoder().encode(raw).length>120000)return null;
 try{
  const d=JSON.parse(raw);if(!d||Object.keys(d).sort().join(',')!=='sources,version'||d.version!==1||!Array.isArray(d.sources))return null;
  const normalized=validateExtensions({...emptyExtensions(),knowledge:d.sources});
  return normalized?.knowledge??null;
 }catch{return null;}
}
export function referenceContext(raw,text,owner=false){
 const sources=readReferences(raw);if(sources===null)throw Error('reference-data-invalid');
 return selectKnowledge({...emptyExtensions(),knowledge:sources},text,owner);
}
