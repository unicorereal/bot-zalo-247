import {emptyExtensions,validateExtensions,publicUrl,sha256} from './mo-rong-du-lieu.mjs';
// Shared with the browser. Blank metadata is derived; required URLs are never invented.
export function resourceMetadata(value,codes=[]){
 const url=String(value.url??'').trim();let title=String(value.title??'').trim();
 if(!title){try{title=decodeURIComponent(new URL(url).pathname.split('/').filter(Boolean).at(-1)??'').replace(/\.[a-z0-9]{1,8}$/i,'').replace(/[-_]+/g,' ');}catch{}title=title||'Tài nguyên';}
 let code=String(value.code??'').trim().toUpperCase();if(!code){const stem=title.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[đĐ]/g,'D').toUpperCase().replace(/[^A-Z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,28)||'TAI-NGUYEN';code=stem;let n=2;while(codes.includes(code))code=stem+'-'+n++;}
 const description=String(value.description??'').trim().replace(/\s+/g,' ');const keywords=(Array.isArray(value.keywords)?value.keywords:String(value.keywords??'').split(',')).map(x=>String(x).trim()).filter(Boolean);
 return {code,title:title.slice(0,160),type:value.type??'photo',url,scope:value.scope??'private',status:value.status??'active',...(description?{description}:{}),...(keywords.length?{keywords}: {})};
}
export async function makeResourceBatch(target,items){const body={schema:1,target,items};return {...body,id:await sha256(JSON.stringify(body))};}
export async function validResourceBatch(batch){
 if(!batch||batch.schema!==1||typeof batch.target!=='string'||!/^[a-z0-9][a-z0-9-]{0,62}$/.test(batch.target)||!Array.isArray(batch.items)||batch.items.length<1||batch.items.length>100)return false;
 if(batch.id!==(await makeResourceBatch(batch.target,batch.items)).id)return false;
 const docs=batch.items.map(x=>x?.item);if(!validateExtensions({...emptyExtensions(),resources:docs}))return false;
 return batch.items.every(x=>x.expected===null||typeof x.expected==='string'&&/^[a-f0-9]{64}$/.test(x.expected));
}
// Runs only for the immutable batch deployed by the account owner, never from chat text.
export async function applyResourceBatch(store,batch){
 if(batch===null)return {status:'none'};
 if(!await validResourceBatch(batch))return {id:batch?.id,status:'invalid'};
 return store.storage.transaction(async()=>{
  const head=await store.current();if((head.resourceImports??[]).includes(batch.id))return {id:batch.id,status:'applied',count:batch.items.length};
  for(const {item,expected}of batch.items){const old=head.resources.find(x=>x.code===item.code);if(expected===null?Boolean(old):!old||await sha256(JSON.stringify(old))!==expected)return {id:batch.id,status:'conflict'};}
  const next={...head,revision:head.revision+1,resourceImports:[...(head.resourceImports??[]),batch.id],resources:[...head.resources.filter(x=>!batch.items.some(y=>y.item.code===x.code)),...batch.items.map(x=>x.item)]};
  const checked=validateExtensions(next);if(!checked)return {id:batch.id,status:'capacity'};
  await store.storage.put('extension:head',checked);return {id:batch.id,status:'applied',count:batch.items.length};
 });
}
export async function serveResource(request,env,readState,readImage){
 const u=new URL(request.url);if(!/^\/tai-nguyen\/[a-f0-9]{64}\.(png|jpg)$/.test(u.pathname))return new Response(null,{status:404});
 if(!['GET','HEAD'].includes(request.method))return new Response(null,{status:405});
 const state=await readState();if(!state.resources.some(x=>x.status==='active'&&x.type==='photo'&&x.url===u.origin+u.pathname))return new Response(null,{status:404,headers:{'Cache-Control':'no-store'}});
 let result=env.RESOURCE_ASSETS?await env.RESOURCE_ASSETS.fetch(new Request(u.origin+u.pathname,{method:request.method})):null;if(!result||result.status===404)result=readImage?await readImage(u.pathname.split('/').at(-1)):new Response(null,{status:404});
 return new Response(request.method==='HEAD'?null:result.body,{status:result.status,headers:{'Content-Type':u.pathname.endsWith('.png')?'image/png':'image/jpeg','X-Content-Type-Options':'nosniff','Cache-Control':'no-store'}});
}
