const words=s=>String(s??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').match(/[a-z0-9]+/g)??[];
const noise=new Set('bot tro ly the gui cho toi minh anh chi em ban xem xin lay muon can vui long giup hinh tai lieu link mau cac nhung mot tam cai nay voi nhe a di duoc khong co va moi nhat'.split(' '));
export function resourceIntent(text){
 const raw=String(text??'').trim();if(/^\/tainguyen(?:\s|$)/i.test(raw))return {query:raw.replace(/^\/tainguyen\s*/i,''),kind:null,list:!raw.replace(/^\/tainguyen\s*/i,'')};
 const n=words(raw).join(' ').replace(/^(?:bot|em|ban|tro ly) /,'').replace(/^co the /,'');if(!/^(?:(?:gui|cho(?: toi| minh| anh| chi| em| ban)? xem|cho xem|xem|xin)(?: (?:cho|toi|minh|anh|chi|em|ban|xin|giup))* (?:anh|hinh|link|tai lieu)|cho(?: toi| minh| anh| chi| em| ban)? xem mau)(?: |$)/.test(n))return null;
 return {query:raw,kind:/^(?:gui|cho.*xem|xem|xin).*\b(?:link|tai lieu)\b/.test(n)?'link':'photo',list:false};
}
export function resourceChoice(text){const n=words(text).join(' ');if(['xem them','trang tiep'].includes(n))return 'more';const m=n.match(/^(?:(?:chon|cai|anh|muc) )?(?:so )?([0-9]{1,3})$/);return m?Number(m[1]):null;}
export function rankResources(state,intent,chatType){
 const all=state.resources.filter(x=>x.status==='active'&&(x.scope==='both'||x.scope===(chatType==='GROUP'?'group':'private'))&&(!intent.kind||x.type===intent.kind));
 const exact=all.filter(x=>x.code===intent.query.trim().toUpperCase()||words(x.title).join(' ')===words(intent.query).join(' '));if(exact.length)return exact;
 const query=[...new Set(words(intent.query).filter(x=>!noise.has(x)))];if(!query.length)return all;
 return all.map(item=>{const title=new Set(words(item.title)),tokens=new Set(words([item.code,item.title,item.description??'',...(item.keywords??[])].join(' ')));return {item,score:query.every(w=>tokens.has(w))?query.reduce((n,w)=>n+(title.has(w)?3:1),0):0};}).filter(x=>x.score>0).sort((a,b)=>b.score-a.score||a.item.title.localeCompare(b.item.title)).map(x=>x.item);
}
export function resourceMenu(items,offset=0){const page=items.slice(offset,offset+5);return {page,reply:'Em tìm thấy '+items.length+' mục phù hợp:\n'+page.map((x,i)=>`${i+1}. ${x.title.slice(0,80)}${x.description?' — '+x.description.slice(0,100):''}`).join('\n')+'\nTrả lời “chọn 1”, “chọn 2”… để nhận đúng mục.'+(offset+5<items.length?' Gửi “xem thêm” để xem trang tiếp.':'')};}
