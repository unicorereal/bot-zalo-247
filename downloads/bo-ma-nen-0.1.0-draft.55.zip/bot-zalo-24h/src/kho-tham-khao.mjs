import {readReferences} from './du-lieu-tham-khao.mjs';
import {randomToken} from './mo-rong-du-lieu.mjs';
// One SQLite object per bot; imports replace the reference set only after owner approval.
export class ReferenceStore{
 constructor(storage,{now=Date.now}={}){this.storage=storage;this.now=now;}
 async current(){const head=await this.storage.get('references:head');if(head===undefined)return {configured:false,revision:0,sources:[]};
  if(!Number.isSafeInteger(head.revision)||head.revision<1||readReferences(JSON.stringify({version:1,sources:head.sources}))===null)throw Error('reference-store-corrupt');return {...head,configured:true};}
 async draft(document,actor){const sources=readReferences(JSON.stringify(document));if(sources===null)throw Error('reference-import-invalid');
  const head=await this.current(),id=randomToken();const d={id,base:head.revision,sources,expires:this.now()+600000};
  await this.storage.put('references:draft:'+actor,d);return {id,revision:head.revision,sources,beforeCount:head.sources.length,expiresInSeconds:600};}
 async apply(id,actor){return this.storage.transaction(async()=>{const d=await this.storage.get('references:draft:'+actor),head=await this.current();
  if(!d||d.id!==id||d.expires<=this.now())throw Error('reference-draft-expired');if(d.base!==head.revision)throw Error('reference-revision-conflict');
  const sources=readReferences(JSON.stringify({version:1,sources:d.sources}));if(sources===null)throw Error('reference-import-invalid');
  const next={revision:head.revision+1,sources};await this.storage.put('references:head',next);await this.storage.delete('references:draft:'+actor);return {revision:next.revision,count:sources.length};});}
}
