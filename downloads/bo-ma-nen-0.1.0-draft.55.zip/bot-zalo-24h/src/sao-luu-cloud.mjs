import { sha256, validateExtensions, cleanText } from './mo-rong-du-lieu.mjs';
import { readCatalog } from './kho-san-pham.mjs';
import { readReferences } from './du-lieu-tham-khao.mjs';
import {SETTINGS} from './duong-du-lieu.mjs';
const allowedKey=k=>k==='private-access:policy'||k.startsWith('memory:')||k==='references:head'||k==='extension:head'||k==='catalog:head'||k==='operation:control'||k==='group:permission'||k.startsWith('tin:')||k.startsWith('reminder:');
const hasPrivateLink=text=>typeof text==='string'&&/\/(?:tai-len|quyen-rieng|khoi-phuc)(?:\?[^#\s]*)?#/.test(text);
export function exportRows(rows){return [...rows].filter(([k])=>allowedKey(k)).map(([k,value])=>{
  const v=structuredClone(value);if(k.startsWith('memory:'))v.job=null;if(k.startsWith('tin:')){delete v.photo;delete v.uploadId;delete v.mediaUrl;delete v.portalToken;if(v.memoryErased||hasPrivateLink(v.ai?.reply)||hasPrivateLink(v.text)){delete v.ai;delete v.text;}}
  return [k,v];
});}
export function restoreRows(rows){
  if(!Array.isArray(rows)||rows.length>2000)throw Error('backup-rows-limit');
  const seen=new Set();
  return rows.map(([key,value])=>{
    if(!cleanText(key,1300)||!allowedKey(key)||seen.has(key)||!value||typeof value!=='object')throw Error('backup-invalid-row');seen.add(key);
    const row=structuredClone(value);
    if(key==='private-access:policy'&&(typeof row.restricted!=='boolean'||!Array.isArray(row.ids)||row.ids.length>100||new Set(row.ids).size!==row.ids.length||row.ids.some(x=>!cleanText(x,256)||/\s/.test(x))||!Number.isSafeInteger(row.revision)||row.revision<0))throw Error('backup-invalid-configuration');
    if(key.startsWith('memory:')){if(row.version!==1||!Array.isArray(row.facts)||row.facts.length>20||row.facts.some(f=>!cleanText(f.topic,80)||!cleanText(f.text,300)||!Array.isArray(f.sources)||f.sources.some(s=>!cleanText(s,1300)))||!Number.isSafeInteger(row.epoch)||row.epoch<0)throw Error('backup-invalid-configuration');row.job=null;}
    if(JSON.stringify(row).length>120000)throw Error('backup-row-size');
    if(key==='extension:head'&&!validateExtensions(row))throw Error('backup-invalid-configuration');
    if(key==='references:head'&&(!Number.isSafeInteger(row.revision)||row.revision<1||readReferences(JSON.stringify({version:1,sources:row.sources}))===null))throw Error('backup-invalid-configuration');
    if(key==='catalog:head'&&(readCatalog(row.raw)===null||!Number.isSafeInteger(row.revision)||row.revision<0))throw Error('backup-invalid-catalog');
    if(key==='operation:control'){row.paused=true;row.privatePaused=true;row.groupPaused=true;}
    if(key==='group:permission')row.enabled=false;
    if(key.startsWith('tin:')){
      // Never restore queue I/O; keep receipts, history, and original timestamps only.
      if(!['sent','rejected','uncertain'].includes(row.status))row.status='uncertain';
      delete row.photo;delete row.mediaUrl;delete row.uploadId;delete row.portalToken;
      if(hasPrivateLink(row.ai?.reply)){delete row.ai;delete row.text;}
      if(!Number.isSafeInteger(row.created)||row.created<=0)throw Error('backup-invalid-time');
    }
    if(key.startsWith('reminder:')){if(!Number.isSafeInteger(row.due)||!cleanText(row.text,700))throw Error('backup-invalid-reminder');if(['pending','sending'].includes(row.status))row.status='restored-paused';}
    return [key,row];
  });
}
export async function makeBackup(objects,now=Date.now()){
  const body={format:'bot-zalo-cloud',schema:1,created:new Date(now).toISOString(),coverage:{mode:'registered-chats',completeLegacyCoverage:false,note:'Chỉ các chat được đăng ký từ khi bật module. Không chứa key/token hoặc file đang chờ xử lý. Các đối tượng được đọc lần lượt, không phải ảnh chụp đồng thời toàn hệ thống.'},objects};
  return {...body,checksum:await sha256(JSON.stringify(body))};
}
export async function checkBackup(backup){
  if(!backup||backup.format!=='bot-zalo-cloud'||![1,2].includes(backup.schema)||!Array.isArray(backup.objects)||backup.objects.length>1004)throw Error('backup-format');
  const {checksum,...body}=backup;
  if(checksum!==await sha256(JSON.stringify(body)))throw Error('backup-checksum');
  const names=new Set();for(const o of backup.objects){
    if(!cleanText(o.name,600)||names.has(o.name))throw Error('backup-duplicate-object');names.add(o.name);
    const name=JSON.parse(o.name);if(!Array.isArray(name)||name.length!==2||!['PRIVATE','GROUP','CATALOG','AI-OPERATION','EXTENSIONS','PRIVATE-ACCESS'].includes(name[0])||!cleanText(name[1],256))throw Error('backup-object-name');
    if(['CATALOG','AI-OPERATION','EXTENSIONS','PRIVATE-ACCESS'].includes(name[0])&&name[1]!=='v1')throw Error('backup-object-version');
    const rows=restoreRows(o.rows);
    if(['PRIVATE','GROUP'].includes(name[0])&&rows.some(([k,v])=>(k.startsWith('tin:')||k.startsWith('reminder:'))&&!v.receipt&&v.chatId!==name[1]))throw Error('backup-wrong-object');
    if(rows.some(([k])=>name[0]==='CATALOG'?k!=='catalog:head':name[0]==='AI-OPERATION'?k!=='operation:control':name[0]==='EXTENSIONS'?k!=='extension:head':name[0]==='PRIVATE-ACCESS'?!['references:head','private-access:policy'].includes(k):['catalog:head','operation:control','extension:head','references:head','private-access:policy'].includes(k)))throw Error('backup-wrong-object');
  }
  if(backup.schema===2){
    if(!backup.settings||Object.entries(backup.settings).some(([k,v])=>!SETTINGS.includes(k)||!['true','false'].includes(v)))throw Error('backup-settings');
    if(!Array.isArray(backup.assets)||backup.assets.length>100||!/^https:\/\//.test(backup.origin??''))throw Error('backup-format');
    const assetNames=new Set();let size=0;
    for(const a of backup.assets){if(!Number.isSafeInteger(a.size)||a.size<1||a.size>8*1024*1024||!(/^[a-f0-9]{64}\.(png|jpg)$/).test(a.name??'')||a.name.split('.')[0]!==a.hash||assetNames.has(a.name))throw Error('backup-image');assetNames.add(a.name);size+=a.size;}
    if(size>64*1024*1024)throw Error('backup-image-size');
    for(const o of backup.objects)for(const [k,v]of o.rows)if(k==='extension:head')for(const x of v.resources)if(x.type==='photo'){const u=new URL(x.url);if(u.origin===new URL(backup.origin).origin&&/^\/tai-nguyen\/[a-f0-9]{64}\.(png|jpg)$/.test(u.pathname)&&!assetNames.has(u.pathname.split('/').at(-1)))throw Error('backup-image-missing');}
  }
  return {hash:checksum,objects:backup.objects.length,records:backup.objects.reduce((n,o)=>n+o.rows.length,0),coverage:backup.coverage};
}
