// Extract an unencrypted AAC track without decoding/re-encoding the full video.
// All reads are bounded Blob slices; raw video bytes are never uploaded.
export async function extractMp4Audio(file){
 const audioMax=16*1024*1024,metaMax=8*1024*1024;
 const fail=()=>{throw Error('Chưa tách được âm thanh của video này; chưa gửi sang AI.');};
 const u32=(b,n)=>{if(n<0||n+4>b.length)fail();return new DataView(b.buffer,b.byteOffset,b.byteLength).getUint32(n);};
 const u64=(b,n)=>{const v=u32(b,n)*4294967296+u32(b,n+4);if(!Number.isSafeInteger(v))fail();return v;};
 const text=(b,n)=>String.fromCharCode(...b.subarray(n,n+4));
 const boxes=(b,start=0,end=b.length)=>{const out=[];let pos=start;while(pos<end){if(out.length>10000||pos+8>end)fail();let size=u32(b,pos),header=8;const type=text(b,pos+4);if(size===1){size=u64(b,pos+8);header=16;}else if(size===0)size=end-pos;if(size<header||pos+size>end)fail();out.push({type,start:pos,end:pos+size,header});pos+=size;}return out;};
 const child=(b,parent,type)=>boxes(b,parent.start+parent.header,parent.end).find(x=>x.type===type);
 const box=(type,parts)=>{const size=8+parts.reduce((n,b)=>n+b.length,0),out=new Uint8Array(size);new DataView(out.buffer).setUint32(0,size);out.set(new TextEncoder().encode(type),4);let at=8;for(const part of parts){out.set(part,at);at+=part.length;}return out;};
 let moov;for(let offset=0,count=0;offset<file.size;count++){if(count>10000||offset+8>file.size)fail();const h=new Uint8Array(await file.slice(offset,Math.min(offset+16,file.size)).arrayBuffer());let size=u32(h,0),header=8;if(size===1){size=u64(h,8);header=16;}else if(size===0)size=file.size-offset;if(size<header||offset+size>file.size)fail();if(text(h,4)==='moov'){if(size>metaMax)fail();moov=new Uint8Array(await file.slice(offset,offset+size).arrayBuffer());break;}offset+=size;}
 if(!moov)fail();const root=boxes(moov)[0],children=boxes(moov,root.header,root.end);if(children.some(x=>x.type==='mvex'))fail();
 const mvhd=children.find(x=>x.type==='mvhd');if(!mvhd)fail();let audio;
 for(const trak of children.filter(x=>x.type==='trak')){const mdia=child(moov,trak,'mdia');if(!mdia)continue;const handler=child(moov,mdia,'hdlr');if(handler&&text(moov,handler.start+handler.header+8)==='soun'){audio={trak,mdia};break;}}
 if(!audio)return null;
 const minf=child(moov,audio.mdia,'minf'),stbl=minf&&child(moov,minf,'stbl');if(!stbl)fail();const table=boxes(moov,stbl.start+stbl.header,stbl.end),get=t=>table.find(x=>x.type===t);
 const stsd=get('stsd'),stsc=get('stsc'),stsz=get('stsz'),offsets=get('stco')??get('co64');if(!stsd||!stsc||!stsz||!offsets)fail();
 const entries=boxes(moov,stsd.start+stsd.header+8,stsd.end);if(u32(moov,stsd.start+stsd.header+4)!==1||entries.length!==1||entries[0].type!=='mp4a')fail();
 const z=stsz.start+stsz.header,fixed=u32(moov,z+4),samples=u32(moov,z+8);if(samples<1||samples>1000000||(!fixed&&z+12+samples*4!==stsz.end))fail();
 const c=stsc.start+stsc.header,runs=u32(moov,c+4);if(runs<1||runs>100000||c+8+runs*12!==stsc.end)fail();const map=[];
 for(let i=0;i<runs;i++){const p=c+8+i*12,first=u32(moov,p),per=u32(moov,p+4),description=u32(moov,p+8);if(!per||description!==1||(!i&&first!==1)||(i&&first<=map[i-1].first))fail();map.push({first,per});}
 const o=offsets.start+offsets.header,chunks=u32(moov,o+4),stride=offsets.type==='co64'?8:4;if(chunks<1||chunks>100000||o+8+chunks*stride!==offsets.end||map.at(-1).first>chunks)fail();
 const ftyp=box('ftyp',[new TextEncoder().encode('M4A '),new Uint8Array(4),new TextEncoder().encode('M4A isommp42')]);
 const track=moov.slice(audio.trak.start,audio.trak.end),trackView=new DataView(track.buffer);let sample=0,run=0,bytes=0;const parts=[];
 for(let i=0;i<chunks;i++){while(run+1<map.length&&map[run+1].first<=i+1)run++;let length=0;for(let k=0;k<map[run].per;k++){if(sample>=samples)fail();length+=fixed||u32(moov,z+12+sample*4);sample++;if(length+bytes>audioMax)fail();}const pos=offsets.type==='co64'?u64(moov,o+8+i*8):u32(moov,o+8+i*4);if(length<=0||pos+length>file.size)fail();const newPos=ftyp.length+8+bytes,patch=o+8+i*stride-audio.trak.start;if(stride===8){trackView.setUint32(patch,0);trackView.setUint32(patch+4,newPos);}else trackView.setUint32(patch,newPos);parts.push(file.slice(pos,pos+length));bytes+=length;}
 if(sample!==samples)fail();const newMoov=box('moov',[moov.slice(mvhd.start,mvhd.end),track]),mdat=new Uint8Array(8);new DataView(mdat.buffer).setUint32(0,8+bytes);mdat.set(new TextEncoder().encode('mdat'),4);const result=new Blob([ftyp,mdat,...parts,newMoov],{type:'audio/mp4'});if(result.size>audioMax)fail();return result;
}
