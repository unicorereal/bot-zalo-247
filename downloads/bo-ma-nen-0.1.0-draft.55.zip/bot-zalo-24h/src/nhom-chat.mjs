// Membership/invitation alone never authorizes paid replies. Explicit owner configuration only.
export function groupAllowed(env, chatId) {
  if (env.GROUP_ENABLED !== 'true' || typeof chatId !== 'string') return false;
  try {
    const ids = JSON.parse(env.GROUP_ALLOWED_IDS_JSON);
    return Array.isArray(ids) && ids.length > 0 && ids.length <= 100 &&
      ids.every(v => typeof v === 'string' && v.length > 0 && v.length <= 256) &&
      new Set(ids).size === ids.length && ids.includes(chatId);
  } catch { return false; }
}

export const GROUP_ADMIN_REPLY = 'Lệnh quản lý chỉ dùng trong chat riêng với bot. Chưa thay đổi dữ liệu.';
export const GROUP_ACTIVATED_REPLY = 'Đã bật bot trong nhóm này. Thành viên có thể @bot hoặc Trả lời tin bot để hỏi; quyền quản lý kho vẫn dùng trong chat riêng.';

export function isGroupActivation(text) {
  // Parse the new text only; quote bodies, names and claimed roles never authorize.
  return typeof text === 'string' && text.length <= 150 &&
    /^(?:@[^\r\n]{1,100}?\s+)?bật nhóm[.!]?$/iu.test(text.trim().normalize('NFC'));
}
export function groupOwner(env) {
  try {
    const ids=JSON.parse(env.CATALOG_ADMIN_IDS_JSON);
    if(!Array.isArray(ids)||!ids.length||ids.length>10||new Set(ids).size!==ids.length||
      !ids.every(v=>typeof v==='string'&&v.length>0&&v.length<=256))return null;
    if(env.GROUP_OWNER_ID!==undefined)return ids.includes(env.GROUP_OWNER_ID)?env.GROUP_OWNER_ID:null;
    return ids.length===1?ids[0]:null;
  }catch{return null;}
}
export class GroupPermission {
  constructor(storage,env){this.storage=storage;this.env=env;}
  canActivate(event){return this.env.GROUP_ENABLED==='true'&&this.env.GROUP_ACTIVATION_ENABLED==='true'&&
    event.chatType==='GROUP'&&isGroupActivation(event.text)&&groupOwner(this.env)!==null&&
    event.senderId===groupOwner(this.env);}
  async allowed(chatId){
    if(this.env.GROUP_ENABLED!=='true')return false;
    if(groupAllowed(this.env,chatId))return true;
    const p=await this.storage.get('group:permission');
    return p?.enabled===true&&p.chatId===chatId&&p.actor===groupOwner(this.env)&&typeof p.actor==='string';
  }
  // Called inside the same transaction that durably queues the acknowledgement.
  async activate(event){
    if(!this.canActivate(event))throw Error('group-activation-denied');
    await this.storage.put('group:permission',{enabled:true,chatId:event.chatId,actor:event.senderId});
  }
}

// PRIVATE namespace remains byte-for-byte compatible with existing deployed objects.
export const inboxName = event => JSON.stringify([event.chatType === 'GROUP' ? 'GROUP' : 'PRIVATE', event.chatId]);

export function conversationRows(rows, current) {
  if (current.chatType !== 'GROUP') return rows;
  return new Map([...rows].filter(([, r]) => r.chatType === 'GROUP' &&
    r.chatId === current.chatId && r.senderId === current.senderId));
}
