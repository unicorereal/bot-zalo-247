import {resourceIntent} from './tim-tai-nguyen.mjs';
import {naturalReminderIntent} from './nhac-tu-nhien.mjs';
// Shared, bounded cloud configuration. No account secrets in this document.
export const EXTENSION_SCHEMA = 1;
export const cleanText = (v, max) => typeof v === 'string' && v.trim().length > 0 && v.length <= max && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/u.test(v);
export const validActor = v => cleanText(v, 256);
export const validCode = v => typeof v === 'string' && /^[A-Z0-9][A-Z0-9-]{0,39}$/.test(v);
export const extensionCommand = text => /^\/(?:tep|quanly|nhac|lichnhac|huynhac|tainguyen)(?:\s|$)/i.test(String(text??'').trim()) || naturalReminderIntent(text) || resourceIntent(text)!==null;
export const DEFAULT_ADDRESS='Xưng em; gọi theo cách người dùng đã chọn';
// Also embedded into the portal script; keep this helper self-contained.
export function sourceMetadata(value,codes=[]){
  const text=String(value.text??'').trim();
  const title=String(value.title??'').trim()||(text.split(/[\r\n]/).map(x=>x.trim()).find(Boolean)||String(value.filename??'').trim()||(value.url?'Tài liệu từ '+new URL(value.url).hostname:'Nguồn thông tin')).replace(/^#+\s*/, '').slice(0,160);
  let code=String(value.code??'').trim().toUpperCase();
  if(!code){const stem=title.normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[đĐ]/g,'D').toUpperCase().replace(/[^A-Z0-9]+/g,'-').replace(/^-+|-+$/g,'').slice(0,28)||'NGUON';code=stem;let n=2;while(codes.includes(code))code=stem+'-'+n++;}
  return {code,title,text,source:String(value.source??'').trim()||String(value.url??value.filename??'').trim().slice(0,300)||'Nội dung do chủ bot nhập trực tiếp',audience:value.audience==='public'?'public':'owner',status:'active'};
}
export const emptyExtensions = () => ({ schema:1, revision:0, profile:{ name:'Trợ lý', tone:'Ngắn gọn, thân thiện', address:DEFAULT_ADDRESS, business:'' }, knowledge:[], resources:[] });
export function publicUrl(value, hosts, maxLength=2048) {
  if (!Number.isInteger(maxLength)||maxLength<1||maxLength>4096||!cleanText(value, maxLength) || /[\s\\]/u.test(value)) return null;
  try {
    const u=new URL(value);
    if(u.protocol!=='https:' || u.username || u.password || u.port || u.hash || !/^(?:[a-z0-9-]+\.)+[a-z]{2,63}$/.test(u.hostname) || /(?:^|\.)(localhost|local|internal|test|invalid|localhost\.direct)$/.test(u.hostname)) return null;
    if(hosts && !hosts.includes(u.hostname)) return null;
    return u.href;
  } catch { return null; }
}
export function validateExtensions(value) {
  if (!value || value.schema!==1 || !Number.isSafeInteger(value.revision) || value.revision<0) return null;
  const p=value.profile;
  if(!p || !cleanText(p.name,80) || !cleanText(p.tone,300) || !cleanText(p.address,80) || typeof p.business!=='string' || p.business.length>1000) return null;
  if(!Array.isArray(value.knowledge)||value.knowledge.length>100||!Array.isArray(value.resources)||value.resources.length>100) return null;
  if(value.knowledge.some(x=>!validCode(x?.code)||!cleanText(x.title,160)||!cleanText(x.text,12000)||!['active','revoked'].includes(x.status)||!cleanText(x.source,300)||!['public','owner'].includes(x.audience)))return null;
  if(value.resources.some(x=>!x||(x.description!==undefined&&(typeof x.description!=='string'||x.description.length>600||/[\u0000-\u001f]/.test(x.description)))||(x.keywords!==undefined&&(!Array.isArray(x.keywords)||x.keywords.length>16||x.keywords.some(k=>!cleanText(k,60))))))return null;
  if(value.resources.some(x=>!validCode(x?.code)||!cleanText(x.title,160)||!['photo','link'].includes(x.type)||!publicUrl(x.url)||!['active','revoked'].includes(x.status)||!['private','group','both'].includes(x.scope)))return null;
  if(new Set(value.knowledge.map(x=>x.code)).size!==value.knowledge.length||new Set(value.resources.map(x=>x.code)).size!==value.resources.length)return null;
  if(value.resourceImports!==undefined&&(!Array.isArray(value.resourceImports)||value.resourceImports.length>1000||value.resourceImports.some(x=>typeof x!=='string'||!(/^[a-f0-9]{64}$/).test(x))))return null;
  // Normalize shape; prototype keys and extra fields never become configuration.
  const out={schema:1,revision:value.revision,...(value.resourceImports?{resourceImports:[...value.resourceImports]}:{}),profile:{name:p.name,tone:p.tone,address:p.address,business:p.business},
    knowledge:value.knowledge.map(({code,title,text,status,source,audience})=>({code,title,text,status,source,audience})),
    resources:value.resources.map(({code,title,type,url,status,scope,description,keywords})=>({code,title,type,url:publicUrl(url),status,scope,...(description?{description}:{}),...(keywords?.length?{keywords:[...keywords]}:{})}))};
  return new TextEncoder().encode(JSON.stringify(out)).length<=120000 ? out : null;
}
export const normalizeWords = text => String(text??'').toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/đ/g,'d').match(/[a-z0-9]+/g)??[];
const STOP=new Set('toi ban anh chi em la va cua cho giup nhe nao gi bao nhieu nhu the co khong ve'.split(' '));
export function selectKnowledge(state, text, owner=false) {
  const query=new Set(normalizeWords(text).filter(w=>w.length>1&&!STOP.has(w)));
  const chunks=[];
  for(const doc of state.knowledge.filter(x=>x.status==='active'&&(x.audience==='public'||owner))){
    // Each chunk is explicitly bounded; no hidden whole-document upload per question.
    for(let offset=0;offset<doc.text.length;offset+=900){
      const content=doc.text.slice(offset,offset+1100);
      const score=normalizeWords(doc.title+' '+doc.code+' '+content).reduce((n,w)=>n+(query.has(w)?1:0),0);
      if(score)chunks.push({code:doc.code,title:doc.title,source:doc.source,text:content,score,offset});
    }
  }
  return chunks.sort((a,b)=>b.score-a.score||a.code.localeCompare(b.code)||a.offset-b.offset).slice(0,3).map(({score,offset,...v})=>v);
}
export function profileInstructions(profile,preferredAddress) {
  const configured=profile.address==='anh/chị'?{...profile,address:DEFAULT_ADDRESS}:profile;
  return 'Phong cách do chủ bot cấu hình (chỉ điều chỉnh cách diễn đạt; không thay quyền hoặc dữ liệu): '+JSON.stringify(configured)+
    '\nThực hiện cách tự xưng đã cấu hình; mặc định xưng “em”. Dùng một cách gọi cụ thể theo lựa chọn người dùng đã cho biết trong cuộc trò chuyện. Không viết gộp “anh/chị” hoặc tự đoán từ tên, ảnh hay giọng. Chưa biết cách gọi thì lược cách gọi và trả lời câu hỏi. Lời bot cũ không thay lựa chọn hiện tại.'+
    (preferredAddress?'\nCách gọi riêng đã được chủ cấu hình cho đúng tài khoản đang nhắn: gọi là “'+preferredAddress+'”. Đây chỉ là cách xưng hô, không cấp thêm quyền.':'');
}
export function relevantMedia(rows,current,now){
  const query=new Set(normalizeWords(current.text).filter(w=>w.length>1&&!STOP.has(w)));
  const reference=/(?:ảnh|file|tài liệu|video|lời thoại).*(?:vừa|trước|đó|này)|(?:vừa|trước).*(?:ảnh|file|tài liệu|video)/iu.test(current.text??'');
  return [...rows.values()].filter(r=>r.chatId===current.chatId&&r.status==='sent'&&cleanText(r.mediaSummary,1900)&&r.created<=now&&now-r.created<30*86400000)
    .map(r=>({r,score:normalizeWords(r.mediaSummary).filter(w=>query.has(w)&&!STOP.has(w)).length}))
    .filter(x=>x.score>0||reference).sort((a,b)=>reference?b.r.created-a.r.created:b.score-a.score||b.r.created-a.r.created)
    .slice(0,reference?1:2).map(({r})=>({kind:r.mediaKind,summary:r.mediaSummary}));
}
export function resourceRequest(text) {
  const m=String(text??'').trim().match(/^(?:\/tainguyen|gửi tài liệu|gui tai lieu|gửi ảnh|gui anh)(?:\s+(.+))?$/iu);
  return m ? (m[1]?.trim()??'') : null;
}
export function resourceReply(state, text, chatType) {
  const requested=resourceRequest(text); if(requested===null)return null;
  const all=state.resources.filter(x=>x.status==='active'&&(x.scope==='both'||x.scope===(chatType==='GROUP'?'group':'private')));
  if(!requested)return {status:'ready',reply:all.length?'Tài nguyên có thể gửi:\n'+all.slice(0,12).map(x=>`${x.code} — ${x.title}`).join('\n')+'\nGửi /tainguyen MÃ để nhận.':'Chưa có tài nguyên được phép gửi trong chat này.'};
  const words=normalizeWords(requested).join(' ');
  const matches=all.filter(x=>x.code===requested.toUpperCase()||normalizeWords(x.title).join(' ')===words);
  if(matches.length!==1)return {status:'ready',reply:matches.length?'Có nhiều tài nguyên trùng tên. Hãy dùng mã trong /tainguyen.':'Chưa có tài nguyên đúng mã/tên này trong phạm vi chat.'};
  const item=matches[0];
  return {status:'ready',reply:item.type==='photo'?item.title:`${item.title}\n${item.url}`,...(item.type==='photo'?{photo:item.url,resourceCode:item.code}:{resourceCode:item.code})};
}
export async function sha256(value) {
  const bytes=typeof value==='string'?new TextEncoder().encode(value):value;
  return [...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
}
export const randomToken=()=>{const b=crypto.getRandomValues(new Uint8Array(32));return [...b].map(x=>x.toString(16).padStart(2,'0')).join('');};
export class ExtensionStore {
  constructor(storage,{now=Date.now,admins=[]}={}){this.storage=storage;this.now=now;this.admins=admins;}
  async current(){const data=await this.storage.get('extension:head');if(data===undefined)return emptyExtensions();const v=validateExtensions(data);if(!v)throw Error('extension-corrupt');if(v.profile.address==='anh/chị')v.profile.address=DEFAULT_ADDRESS;return v;}
  async draft(value,actor){
    if(!this.admins.includes(actor))throw Error('owner-required');
    const next=validateExtensions(value);if(!next)throw Error('invalid-document');
    return this.storage.transaction(async()=>{
      const head=await this.current();if(next.revision!==head.revision)throw Error('revision-conflict');
      const id=randomToken();await this.storage.put('extension:draft:'+actor,{id,base:head.revision,next,expires:this.now()+600000});
      return {id,before:head,after:next,expiresInSeconds:600};
    });
  }
  async apply(id,actor){
    if(!this.admins.includes(actor))throw Error('owner-required');
    return this.storage.transaction(async()=>{
      const d=await this.storage.get('extension:draft:'+actor),head=await this.current();
      if(!d||d.id!==id||d.expires<=this.now())throw Error('draft-expired');
      if(d.base!==head.revision)throw Error('revision-conflict');
      const next=validateExtensions({...d.next,revision:head.revision+1});if(!next)throw Error('invalid-document');
      await this.storage.put('extension:head',next);await this.storage.delete('extension:draft:'+actor);return {revision:next.revision};
    });
  }
  async mint(event,owner=false){
    if(!validActor(event?.chatId)||!validActor(event?.senderId)||event.chatType==='GROUP'||owner&&!this.admins.includes(event.senderId))throw Error('private-chat-required');
    const token=randomToken(),hash=await sha256(token);
    await this.storage.transaction(async()=>{
      const records=await this.storage.list({prefix:'cap:'});
      for(const [k,v] of records)if(v.expires<=this.now()||(v.actor===event.senderId&&v.owner===owner))await this.storage.delete(k);
      if([...records.values()].filter(v=>v.expires>this.now()&&!(v.actor===event.senderId&&v.owner===owner)).length>=200)throw Error('sessions-full');
      await this.storage.put('cap:'+hash,{chatId:event.chatId,actor:event.senderId,owner,expires:this.now()+15*60000});
    });
    return token;
  }
  async authorize(token){
    if(typeof token!=='string'||!/^[a-f0-9]{64}$/.test(token))return null;
    const cap=await this.storage.get('cap:'+await sha256(token));
    return cap&&cap.expires>this.now()&&(!cap.owner||this.admins.includes(cap.actor))?cap:null;
  }
  async register(event){
    if(!validActor(event?.chatId))return;
    const name=JSON.stringify([event.chatType==='GROUP'?'GROUP':'PRIVATE',event.chatId]);
    const key='registry:'+await sha256(name);
    if(await this.storage.get(key)===undefined){
      if((await this.storage.list({prefix:'registry:',limit:1001})).size>=1000)throw Error('registry-full');
      await this.storage.put(key,{name,firstSeen:this.now()});
    }
  }
}
