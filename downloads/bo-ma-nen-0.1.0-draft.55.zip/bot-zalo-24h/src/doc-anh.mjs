// One direct PRIVATE image. URLs and bytes are never logged or added to memory.
export const IMAGE_MAX_BYTES = 8 * 1024 * 1024;
export const IMAGE_DEFAULT_QUESTION = 'Đọc chữ trong ảnh này và mô tả ngắn phần nhìn rõ. Nếu không có chữ, hãy mô tả ảnh; không suy đoán phần không nhìn rõ.';
export const IMAGE_QUESTION_REPLY = 'Anh/chị vui lòng gửi lại một ảnh kèm câu hỏi trong chú thích, ví dụ “Đọc chữ trong ảnh này”. Bot chưa đọc ảnh vừa gửi.';
export const IMAGE_FAILURE_REPLY = 'Bot chưa đọc được ảnh này: ảnh có thể không tải được, sai định dạng hoặc vượt giới hạn. Hỗ trợ một ảnh PNG/JPEG tối đa 8 MiB; người quản lý cần kiểm mã lỗi trước khi yêu cầu gửi lại.';
export function imageFailureReply(result){
  if(result?.sizeOverLimit===true)return 'Ảnh Zalo gửi về vượt giới hạn dung lượng của bot. Chọn ảnh nhỏ hơn 8 MB; giới hạn kỹ thuật là 8 MiB, khoảng 8,39 MB.';
  if(result?.dimensionsOverLimit===true)return 'Ảnh có kích thước hoặc số điểm ảnh vượt giới hạn của bot. Cần giảm kích thước ảnh, không chỉ đổi dung lượng file.';
  if(result?.bodyKind==='html'||result?.reason==='image-url'||result?.reason==='image-http')return 'Bot chưa tải được ảnh từ Zalo. Thông báo này không khẳng định ảnh quá lớn; người cài cần kiểm đường tải ảnh, chưa cần cắt hoặc gửi lại liên tục.';
  if(['image-timeout','image-transport'].includes(result?.reason))return 'Bot chưa tải xong ảnh từ Zalo do kết nối hoặc thời gian tải. Chưa có bằng chứng ảnh vượt dung lượng; người cài cần kiểm kết nối.';
  if(result?.headerInvalid===true)return 'Ảnh tải về chưa được nhận dạng là PNG/JPEG hợp lệ. Người cài cần kiểm định dạng ảnh thực tế; cắt nhỏ ảnh chưa chắc giải quyết được lỗi.';
  return IMAGE_FAILURE_REPLY;
}
export function imageHosts(raw) {
  try {
    const hosts = JSON.parse(raw ?? '[]');
    if (!Array.isArray(hosts) || hosts.length > 10 || hosts.some(h => typeof h !== 'string' ||
      h !== h.toLowerCase() || h.length > 253 || !/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/.test(h) ||
      /(?:^|\.)(?:localhost|local|internal|test)$/.test(h))) return [];
    return [...new Set(hosts)];
  } catch { return []; }
}
// f119-zpc was observed on an authenticated PRIVATE image on 14/10/2026.
export const zaloPhotoHost = hostname => typeof hostname==='string'&&(hostname==='f119-zpc.zdn.vn'||/^photo-stal-[1-9][0-9]{0,2}\.zdn\.vn$/.test(hostname));
export function imageUrl(value, hosts, {zaloPhotoCdn=false}={}) {
  if (typeof value !== 'string' || value.length > 4096 || value !== value.trim() || /[\x00-\x20\\]/.test(value)) return null;
  try {
    const u = new URL(value);
    return u.protocol === 'https:' && !u.username && !u.password && !u.port && !u.hash &&
      (Array.isArray(hosts) && hosts.includes(u.hostname) || zaloPhotoCdn===true && zaloPhotoHost(u.hostname)) ? u.href : null;
  } catch { return null; }
}
// Header checks bound dimensions before sending to vision; not a complete image decoder.
export function imageDimensions(bytes, mime) {
  const v = new DataView(bytes.buffer, bytes.byteOffset, bytes.byteLength);
  if (mime === 'image/png' && bytes.length >= 33 &&
    [137,80,78,71,13,10,26,10].every((n,i) => bytes[i] === n) && v.getUint32(8) === 13 &&
    [73,72,68,82].every((n,i) => bytes[12+i] === n)) return [v.getUint32(16),v.getUint32(20)];
  if (mime === 'image/jpeg' && bytes.length >= 12 && bytes[0] === 255 && bytes[1] === 216 &&
    bytes.at(-2) === 255 && bytes.at(-1) === 217) {
    let p = 2;
    while (p + 4 <= bytes.length) {
      if (bytes[p++] !== 255) return null;
      while (bytes[p] === 255) p++;
      const marker = bytes[p++];
      if ([216,217,0,218].includes(marker)) return null;
      if (marker === 1 || marker >= 208 && marker <= 215) continue;
      if (p + 2 > bytes.length) return null;
      const size = v.getUint16(p);
      if (size < 2 || p + size > bytes.length) return null;
      if ([192,193,194].includes(marker)) return size >= 8 ? [v.getUint16(p+5),v.getUint16(p+3)] : null;
      p += size;
    }
  }
  return null;
}
export function validImageData(value) {
  return typeof value === 'string' && value.length <= Math.ceil(IMAGE_MAX_BYTES / 3) * 4 + 64 &&
    /^data:image\/(?:png|jpeg);base64,[A-Za-z0-9+/]+={0,2}$/.test(value);
}
export function imageLoadDiagnostic(value,result){
  const reasons=['image-url','image-timeout','image-http','image-format-or-size','image-size-or-timeout','image-header-or-dimensions','image-transport'];
  let hostname=null;try{const u=new URL(value);if(u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/.test(u.hostname))hostname=u.hostname;}catch{}
  return {ready:result?.status==='ready',reason:reasons.includes(result?.reason)?result.reason:null,hostname,
    profile:['default','browser','browser-referrer'].includes(result?.profile)?result.profile:'default',
    bodyKind:['empty','png','jpeg','html','other'].includes(result?.bodyKind)?result.bodyKind:null,
    bodyBytes:Number.isInteger(result?.bodyBytes)&&result.bodyBytes>=0&&result.bodyBytes<=IMAGE_MAX_BYTES?result.bodyBytes:null,
    httpStatus:Number.isInteger(result?.httpStatus)&&result.httpStatus>=100&&result.httpStatus<=599?result.httpStatus:null,
    mimeKind:['png','jpeg','webp','gif','octet-stream','html','other','missing'].includes(result?.mimeKind)?result.mimeKind:null,
    sizeOverLimit:result?.sizeOverLimit===true,headerInvalid:result?.headerInvalid===true,dimensionsOverLimit:result?.dimensionsOverLimit===true};
}
export function createImageLoader({ hosts = [], zaloPhotoCdn=false, profile='default', fetchImpl, timeoutMs = 5000 } = {}) {
  if (typeof fetchImpl !== 'function' || !Number.isInteger(timeoutMs) || timeoutMs < 1 || timeoutMs > 5000)
    throw Error('invalid-image-loader');
  if(!['default','browser','browser-referrer'].includes(profile))throw Error('invalid-image-profile');
  return async value => {
    const url = imageUrl(value, hosts,{zaloPhotoCdn});
    if (!url) return { status:'failed', reason:'image-url' };
    const controller = new AbortController(); let timer;
    const deadline = new Promise(resolve => { timer = setTimeout(() => {
      controller.abort(); resolve({ status:'failed', reason:'image-timeout' });
    }, timeoutMs); });
    const operation = (async () => {
      let reader;
      const cancel = () => { reader?.cancel().catch(() => {}); };
      controller.signal.addEventListener('abort',cancel,{once:true});
      try {
        const headers={Accept:'image/png,image/jpeg'};
        if(profile!=='default')headers['User-Agent']='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36';
        if(profile==='browser-referrer')headers.Referer='https://chat.zalo.me/';
        const r = await fetchImpl(url, { method:'GET', redirect:'manual', signal:controller.signal,headers });
        if (controller.signal.aborted) { await r.body?.cancel(); return { status:'failed', reason:'image-timeout' }; }
        if (!r.ok) { await r.body?.cancel(); return { status:'failed', reason:'image-http',httpStatus:r.status }; }
        const declaredMime = r.headers.get('content-type')?.split(';')[0].trim().toLowerCase();
        const mimeKind=({'image/png':'png','image/jpeg':'jpeg','image/webp':'webp','image/gif':'gif','application/octet-stream':'octet-stream','text/html':'html'})[declaredMime]??(declaredMime?'other':'missing');
        const size = r.headers.get('content-length');
        if (size !== null &&
          (!/^\d+$/.test(size) || Number(size) > IMAGE_MAX_BYTES) || !r.body) {
          await r.body?.cancel(); return { status:'failed', reason:'image-format-or-size',httpStatus:r.status,mimeKind,sizeOverLimit:Number(size)>IMAGE_MAX_BYTES,bodyKind:!r.body?'empty':null,bodyBytes:!r.body?0:null };
        }
        reader = r.body.getReader(); const chunks = []; let length = 0;
        while (true) {
          const { value:chunk, done } = await reader.read();
          if (done) break;
          length += chunk.length;
          if (length > IMAGE_MAX_BYTES || controller.signal.aborted) {
            await reader.cancel(); return { status:'failed', reason:'image-size-or-timeout',sizeOverLimit:length>IMAGE_MAX_BYTES };
          }
          chunks.push(chunk);
        }
        const bytes = new Uint8Array(length); let offset = 0;
        if (controller.signal.aborted) return { status:'failed', reason:'image-timeout' };
        for (const chunk of chunks) { bytes.set(chunk,offset); offset += chunk.length; }
        // CDN labels are not reliable; actual PNG/JPEG headers decide the image type.
        const pngDimensions=imageDimensions(bytes,'image/png');
        const mime=pngDimensions?'image/png':'image/jpeg';
        const dimensions=pngDimensions??imageDimensions(bytes,'image/jpeg');
        const bodyKind=length===0?'empty':pngDimensions?'png':dimensions?'jpeg':bytes[0]===60?'html':'other';
        if (!dimensions || dimensions.some(v => v < 1 || v > 8192) || dimensions[0]*dimensions[1] > 16000000)
          return { status:'failed', reason:'image-header-or-dimensions',httpStatus:r.status,mimeKind,headerInvalid:!dimensions,dimensionsOverLimit:Boolean(dimensions),bodyKind,bodyBytes:length };
        let binary = '';
        for (let p=0;p<bytes.length;p+=32768) binary += String.fromCharCode(...bytes.subarray(p,p+32768));
        return { status:'ready', dataUrl:`data:${mime};base64,${btoa(binary)}`,mimeKind:pngDimensions?'png':'jpeg',httpStatus:r.status,bodyKind,bodyBytes:length };
      } catch { return { status:'failed', reason:'image-transport' }; }
      finally { controller.signal.removeEventListener('abort',cancel); try { reader?.releaseLock(); } catch {} }
    })();
    try { return await Promise.race([operation,deadline]); } finally { clearTimeout(timer); }
  };
}
