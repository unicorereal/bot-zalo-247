// Observed Platform event has no quote text or reference ID. Not a quote reader.
export const MISSING_QUOTE_REPLY = 'Bot chưa nhận được nội dung tin trích dẫn từ Zalo. Anh/chị vui lòng chép nội dung tin gốc kèm câu hỏi vào một tin mới để bot đọc đúng.';
export function missingQuoteRequest(text) {
  if(typeof text!=='string'||!text.trim()||text.length>1000)return false;
  const value=text.normalize('NFC').toLowerCase().trim();
  if(/(?:nội dung gốc|tin gốc|nội dung trích dẫn|tin trích dẫn)\s*:\s*\S/u.test(value))return false;
  return /(?:tin|nội dung|đoạn|câu)\s+(?:(?:được|đã|đang)\s+)?(?:trích dẫn|quote)(?:\s|[?.!,:]|$)/u.test(value)||
    /(?:^|\s)đây là (?:món gì|phép tính gì|gì)(?:\s+(?:vậy|thế|ạ))?[?.!\s]*$/u.test(value);
}
