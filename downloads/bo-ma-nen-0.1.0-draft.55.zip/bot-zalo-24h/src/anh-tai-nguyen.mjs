import {imageDimensions,IMAGE_MAX_BYTES} from './doc-anh.mjs';
import {sha256} from './mo-rong-du-lieu.mjs';
const PART=120*1024,MAX_TOTAL=100*IMAGE_MAX_BYTES;
export function resourceImageBytes(value){
 if(typeof value!=='string'||!value.length||value.length%4||value.length>Math.ceil(IMAGE_MAX_BYTES/3)*4||/[^A-Za-z0-9+/=]/.test(value))return null;
 try{if(typeof Uint8Array.fromBase64==='function'){const bytes=Uint8Array.fromBase64(value);return bytes.length<=IMAGE_MAX_BYTES?bytes:null;}const raw=atob(value);if(raw.length>IMAGE_MAX_BYTES)return null;const bytes=new Uint8Array(raw.length);for(let i=0;i<raw.length;i++)bytes[i]=raw.charCodeAt(i);return bytes;}catch{return null;}
}
export class ResourceImages{
 constructor(storage,{now=Date.now}={}){this.storage=storage;this.now=now;}
 async stage(bytes,references=[]){
  if(!(bytes instanceof Uint8Array)||!bytes.length||bytes.length>IMAGE_MAX_BYTES)throw Error('image-size');
  const mime=bytes[0]===137?'image/png':'image/jpeg',dimensions=imageDimensions(bytes,mime);
  if(!dimensions||dimensions.some(x=>x<1||x>16000)||dimensions[0]*dimensions[1]>40000000)throw Error('image-format');
  const hash=await sha256(bytes),name=hash+(mime==='image/png'?'.png':'.jpg');
  await this.storage.transaction(async()=>{
   const all=await this.storage.list({prefix:'resource-image-meta:'});let removed=0;
   for(const [key,meta]of all){if(removed<5&&meta.stagedAt+86400000<this.now()&&!references.some(x=>{try{return new URL(x.url).pathname==='/tai-nguyen/'+meta.name;}catch{return false;}})){
    for(let i=0;i<meta.parts;i++)await this.storage.delete('resource-image:'+meta.hash+':'+i);await this.storage.delete(key);all.delete(key);removed++;
   }}
   if(all.has('resource-image-meta:'+hash))return;
   if(all.size>=100||[...all.values()].reduce((n,x)=>n+x.size,0)+bytes.length>MAX_TOTAL)throw Error('image-capacity');
   const parts=Math.ceil(bytes.length/PART);for(let i=0;i<parts;i++)await this.storage.put('resource-image:'+hash+':'+i,bytes.slice(i*PART,(i+1)*PART));
   await this.storage.put('resource-image-meta:'+hash,{hash,name,mime,size:bytes.length,parts,stagedAt:this.now()});
  });
  return {hash,name,mime,size:bytes.length};
 }
 async read(name,references=[],owner=false){
  if(!/^[a-f0-9]{64}\.(png|jpg)$/.test(name)||!owner&&!references.some(x=>{try{return x.type==='photo'&&x.status==='active'&&new URL(x.url).pathname==='/tai-nguyen/'+name;}catch{return false;}}))return null;
  const meta=await this.storage.get('resource-image-meta:'+name.split('.')[0]);if(!meta||meta.name!==name)return null;
  const bytes=new Uint8Array(meta.size);let offset=0;for(let i=0;i<meta.parts;i++){const part=await this.storage.get('resource-image:'+meta.hash+':'+i);if(!(part instanceof Uint8Array)||offset+part.length>bytes.length)return null;bytes.set(part,offset);offset+=part.length;}if(offset!==meta.size)return null;
  return {bytes,mime:meta.mime};
 }
}
