// Deliberately local-only. No TTL/restart/cross-isolate durability guarantee.
export class MemoryDeliveryStore {
  #records = new Map();
  constructor({ maxAttempts = 2, maxRecords = 1000 } = {}) {
    if (!Number.isInteger(maxAttempts) || maxAttempts < 1 || maxAttempts > 2 ||
        !Number.isInteger(maxRecords) || maxRecords < 1) throw new Error('invalid-store-config');
    this.maxAttempts = maxAttempts;
    this.maxRecords = maxRecords;
  }
  claim(key) {
    const previous = this.#records.get(key);
    if (previous && (previous.status !== 'rejected' || previous.attempts >= this.maxAttempts)) {
      return { claimed: false, status: previous.status };
    }
    if (!previous && this.#records.size >= this.maxRecords) return { claimed: false, status: 'capacity' };
    const record = { status: 'processing', attempts: (previous?.attempts ?? 0) + 1 };
    this.#records.set(key, record);
    return { claimed: true, ...record };
  }
  finish(key, status) {
    if (!['sent', 'rejected', 'uncertain'].includes(status)) throw new Error('invalid-delivery-state');
    const record = this.#records.get(key);
    if (!record || record.status !== 'processing') throw new Error('missing-delivery-claim');
    record.status = status;
  }
  inspect(key) {
    const record = this.#records.get(key);
    return record ? { ...record } : null;
  }
}
