import {recoveryCall,generationEnv} from './duong-du-lieu.mjs';
import {RecoveryManager,recoveryData} from './khoi-phuc-du-lieu.mjs';
import { ChatMemory, createSummarizer } from './tom-tat-chat.mjs';
import { referenceContext } from './du-lieu-tham-khao.mjs';
import { DurableObject } from 'cloudflare:workers';
import { DurableInbox } from './hang-doi-ben.mjs';
import { createZaloSender } from './gui-tin.mjs';
import { handleCloud } from './nhan-cloud.mjs';
import { createLuna, TrialBudget, trialName } from './ai-luna.mjs';
import { readCatalog } from './kho-san-pham.mjs';
import { CatalogManager, adminIds } from './quan-ly-kho.mjs';
import { OperatingBudget, OperatingControl, isOperationCommand } from './van-hanh-ai.mjs';
import { GroupPermission, GROUP_ADMIN_REPLY } from './nhom-chat.mjs';
import { createImageLoader, imageHosts, imageLoadDiagnostic } from './doc-anh.mjs';
import { CloudExtensions } from './mo-rong-cloud.mjs';
import { resourceReply } from './mo-rong-du-lieu.mjs';
import { PrivateAccess, privateAccessService, privateAllowed } from './quyen-chat-rieng.mjs';

export class ChatInbox extends DurableObject {
  constructor(ctx, env) {
    super(ctx, env);this.rawEnv=env;this.localGeneration='legacy';this.recovery=new RecoveryManager(ctx.storage,env);this.setup(env);
  }
  setup(env){const ctx=this.ctx;
    this.group = new GroupPermission(ctx.storage, env);
    this.privateAccess=new PrivateAccess(ctx.storage,env);
    this.memory=new ChatMemory(ctx.storage,{enabled:env.SUMMARY_ENABLED==='true'&&env.MEMORY_ENABLED==='true'});
    this.extensions=env.EXTENSIONS_ENABLED==='true'?new CloudExtensions(ctx,env):null;
    this.inbox = new DurableInbox(ctx.storage, { memory:this.memory, aiEnabled: env.AI_ENABLED === 'true',
      privateAccessEnabled:env.PRIVATE_ACCESS_ENABLED==='true',allowPrivate:event=>privateAllowed(env,event),
      handlePrivateAccess:async event=>{const r=await privateAccessService(env).fetch(new Request('https://internal/private-access/command',{method:'POST',body:JSON.stringify(event)}));if(!r.ok)throw Error('private-access-unavailable');return (await r.json()).reply;},
      imageEnabled: env.IMAGE_ENABLED === 'true',
      extensionsEnabled:!!this.extensions,groupImageEnabled:env.GROUP_IMAGE_ENABLED==='true',
      handleExtension:event=>this.extensions.command(event),handleResource:event=>this.extensions.resourceTalk(event),isResourceFollowup:event=>this.extensions.hasResourceChoice(event),isReminderFollowup:event=>this.extensions.reminders.hasFollowup(event),nextReminder:()=>this.extensions.reminders.next(),
      stageUpload:(id,payload)=>this.extensions.uploads.save(id,payload),
      refreshResource:async(code,row)=>resourceReply(await this.extensions.config(),'/tainguyen '+code,row.chatType),
      allowGroup: chatId => this.group.allowed(chatId),
      canActivateGroup: event => this.group.canActivate(event), activateGroup: event => this.group.activate(event),
      retentionEnabled: env.DATA_RETENTION_ENABLED === 'true',
      memoryEnabled: env.MEMORY_ENABLED === 'true', historyRetrievalEnabled: env.HISTORY_RETRIEVAL_ENABLED === 'true',
      knowledgeEnabled: env.KNOWLEDGE_ENABLED === 'true',
      catalog: env.KNOWLEDGE_ENABLED === 'true' ? readCatalog(env.PRODUCT_CATALOG_JSON) : null,
      catalogAdminEnabled: env.CATALOG_MANAGED === 'true' && env.CATALOG_ADMIN_ENABLED === 'true',
      manageCatalog: async event => {
        if (event.chatType === 'GROUP') return GROUP_ADMIN_REPLY;
        const operation = isOperationCommand(event.text);
        const response = await (operation ? this.operationService() : this.catalogService()).fetch(new Request(operation ? 'https://inbox.internal/operation/manage' : 'https://inbox.internal/catalog/manage', {
          method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(event)
        }));
        if (!response.ok) throw Error('catalog-manager-unavailable');
        return (await response.json()).reply;
      },
      loadCatalog: env.CATALOG_MANAGED === 'true' ? async () => {
        const response = await this.catalogService().fetch(new Request('https://inbox.internal/catalog/read'));
        if (!response.ok) return null;
        return readCatalog(JSON.stringify(await response.json()));
      } : null });
    this.catalog = new CatalogManager(ctx.storage, { admins: adminIds(env.CATALOG_ADMIN_IDS_JSON),
      initialImport: env.DATA_GENERATION&&env.DATA_GENERATION!=='legacy'?undefined:env.CATALOG_IMPORT_REVISION, initialCatalog: env.PRODUCT_CATALOG_JSON });
    this.budget = new TrialBudget(ctx.storage);
    this.operation = env.AI_BUDGET_MODE === 'provider-v1'
      ? new OperatingControl(ctx.storage, { admins: adminIds(env.CATALOG_ADMIN_IDS_JSON), providerReady: env.AI_PROVIDER_READY === 'true', retentionEnabled: env.DATA_RETENTION_ENABLED === 'true' })
      : new OperatingBudget(ctx.storage, { admins: adminIds(env.CATALOG_ADMIN_IDS_JSON) });
    this.env = env;
  }
  catalogService() {
    return this.env.INBOX.get(this.env.INBOX.idFromName(JSON.stringify(['CATALOG', 'v1'])));
  }
  operationService() {
    return this.env.INBOX.get(this.env.INBOX.idFromName(JSON.stringify(['AI-OPERATION', 'v1'])));
  }
  async fetch(request){
    const path=new URL(request.url).pathname;
    if(this.rawEnv.RECOVERY_ENABLED==='true'&&path==='/recovery/internal'){
      try{return Response.json(await this.recovery.internal(await request.json()));}catch(e){return Response.json({error:e.message},{status:400});}
    }
    if(this.rawEnv.RECOVERY_ENABLED==='true'&&path==='/recovery/api')return this.recovery.api(await request.json(),request.headers.get('Authorization')?.replace(/^Bearer /,''));
    let lease;
    if(this.rawEnv.RECOVERY_ENABLED==='true'){
      const incoming=request.headers.get('X-Data-Generation')??'legacy';
      const stored=await this.ctx.storage.get('routing:generation');if(stored&&stored!==incoming)return Response.json({error:'wrong-generation'},{status:409});
      if(incoming!=='legacy'&&!stored)await this.ctx.storage.put('routing:generation',incoming);
      const settingsText=request.headers.get('X-Data-Settings')??'{}';if(incoming!=='legacy'&&(incoming!==this.localGeneration||settingsText!==this.dataSettingsRaw)){this.localGeneration=incoming;this.dataSettingsRaw=settingsText;const settings=JSON.parse(settingsText);await this.ctx.storage.put('routing:settings',settings);this.setup(generationEnv({...this.rawEnv,DATA_SETTINGS:settings},incoming));}
      if(request.headers.get('X-Recovery-Write')==='true'&&path==='/extension/recovery-data'){
        try{return Response.json(await recoveryData(this.ctx,this.env,await request.json()));}catch(e){return Response.json({error:e.message},{status:400});}
      }
      lease=await recoveryCall(this.rawEnv,'acquire',{generation:incoming});if(!lease.allowed)return Response.json({error:'Đang chuẩn bị bản sao hoặc khôi phục. Hãy chờ hoàn tất.'},{status:409});
    }
    try{return await this.dataFetch(request);}finally{if(lease?.id)await recoveryCall(this.rawEnv,'release',{id:lease.id});}
  }
  async dataFetch(request) {
    const path = new URL(request.url).pathname;
    if((this.env.PRIVATE_ACCESS_ENABLED==='true'||this.env.REFERENCE_SQLITE_ENABLED==='true'&&path==='/private-access/reference-read')&&path.startsWith('/private-access/')&&request.method==='POST'){
      try{return await this.privateAccess.handle(request);}catch{return Response.json({error:'private-access-unavailable'},{status:503});}
    }
    if(this.extensions&&path.startsWith('/extension/'))return this.extensions.handleInternal(request,this.inbox);
    if (path === '/operation/manage' && request.method === 'POST' && ['monthly-v1', 'provider-v1'].includes(this.env.AI_BUDGET_MODE) && this.env.CATALOG_ADMIN_ENABLED === 'true') {
      try { return Response.json({ reply: await this.operation.handle(await request.json()) }); }
      catch { return Response.json({ error: 'operation-unavailable' }, { status: 503 }); }
    }
    if (path === '/catalog/read' && request.method === 'GET' && this.env.CATALOG_MANAGED === 'true') {
      try {
        const catalog = await this.catalog.current();
        return catalog === null ? Response.json({ error: 'catalog-unavailable' }, { status: 503 }) : Response.json(catalog);
      } catch { return Response.json({ error: 'catalog-unavailable' }, { status: 503 }); }
    }
    if (path === '/catalog/manage' && request.method === 'POST' && this.env.CATALOG_MANAGED === 'true' && this.env.CATALOG_ADMIN_ENABLED === 'true') {
      try { return Response.json({ reply: await this.catalog.handle(await request.json()) }); }
      catch { return Response.json({ error: 'catalog-unavailable' }, { status: 503 }); }
    }
    if (new URL(request.url).pathname === '/reserve' && request.method === 'POST') {
      if (this.env.AI_ENABLED !== 'true') return Response.json({ allowed: false });
      try {
        const body = await request.json();
        return Response.json(await (['monthly-v1', 'provider-v1'].includes(this.env.AI_BUDGET_MODE) ? this.operation : this.budget).reserve(body.key, { eventAt: body.eventAt,chatType:body.chatType??null }));
      }
      catch { return Response.json({ error: 'budget-unavailable' }, { status: 503 }); }
    }
    if(path==='/operation/check'&&request.method==='POST'){
      if(this.env.AI_ENABLED!=='true')return Response.json({allowed:false,reason:'ai-paused'});
      try{const body=await request.json();if(this.env.AI_BUDGET_MODE==='provider-v1')return Response.json(await this.operation.permission(body.chatType??null));const {control}=await this.operation.state();return Response.json({allowed:!control.paused,reason:control.paused?'ai-paused':undefined});}catch{return Response.json({allowed:false,reason:'operation-unavailable'},{status:503});}
    }
    if (new URL(request.url).pathname !== '/enqueue' || request.method !== 'POST')
      return new Response(null, { status: 404 });
    // This object has no public URL; only the authenticated Worker can route here.
    try {
      const event=await request.json();
      if(this.extensions)await this.extensions.call('/extension/register',event);
      const result = await this.inbox.enqueue(event);
      return Response.json(result, { status: result.status === 'capacity' ? 503 : 200 });
    } catch { return Response.json({ error: 'state-unavailable' }, { status: 503 }); }
  }
  summaryAI(existing){
    return {configured:Boolean(this.env.OPENAI_API_KEY),
      summarize:createSummarizer({apiKey:this.env.OPENAI_API_KEY,model:this.env.OPENAI_MODEL,fetchImpl:(...a)=>globalThis.fetch(...a)}),
      reserve:existing?.reserve??(async(key,{eventAt,chatType})=>{
        if(this.env.AI_BUDGET_MODE!=='provider-v1')return {allowed:false};
        const response=await this.operationService().fetch(new Request('https://inbox.internal/reserve',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({key,eventAt,chatType})}));
        return response.ok?response.json():{allowed:false};
      })};
  }
  async alarm(){
    let lease;
    if(this.rawEnv.RECOVERY_ENABLED==='true'){
      const gen=await this.ctx.storage.get('routing:generation')??'legacy';
      if(gen!==this.localGeneration){this.localGeneration=gen;this.setup(generationEnv({...this.rawEnv,DATA_SETTINGS:await this.ctx.storage.get('routing:settings')??{}},gen));}
      lease=await recoveryCall(this.rawEnv,'acquire',{generation:gen});if(!lease.allowed)return;
    }
    try{return await this.dataAlarm();}finally{if(lease?.id)await recoveryCall(this.rawEnv,'release',{id:lease.id});}
  }
  async dataAlarm() {
    if(this.extensions){await this.extensions.uploads.maintain();await this.extensions.reminders.maintain();}
    if(this.memory&&this.env.BOT_ENABLED==='true'&&this.env.AI_ENABLED==='true'&&this.env.AI_PROVIDER_READY==='true'){
      const expiryAI=this.summaryAI();await this.memory.update(expiryAI,{expiringOnly:true});
    }
    if (this.env.DATA_RETENTION_ENABLED === 'true') {
      await this.inbox.maintain({ sendEnabled: this.env.BOT_ENABLED === 'true' });
      if (this.env.AI_BUDGET_MODE === 'provider-v1') await this.operation.maintain();
    }
    if (this.env.BOT_ENABLED !== 'true' || !this.env.ZALO_BOT_TOKEN) return;
    const ai = createLuna({ apiKey: this.env.OPENAI_API_KEY, model: this.env.OPENAI_MODEL,
      onRejected: diagnostic => console.info('AI_API_REJECTED', JSON.stringify(diagnostic)),
      fetchImpl: (...args) => globalThis.fetch(...args) });
    if(this.extensions)this.extensions.attachAI(ai,this.inbox);
    const previousContext=ai.context;
    if(this.env.REFERENCE_DATA_JSON!==undefined||this.env.REFERENCE_SQLITE_ENABLED==='true')ai.context=async row=>{
      const context=previousContext?await previousContext(row):{};
      const owner=row.chatType!=='GROUP'&&adminIds(this.env.CATALOG_ADMIN_IDS_JSON).includes(row.senderId);
      let raw=this.env.REFERENCE_DATA_JSON;
      if(this.env.REFERENCE_SQLITE_ENABLED==='true'){
        const r=await privateAccessService(this.env).fetch(new Request('https://internal/private-access/reference-read',{method:'POST',body:'{}'}));
        if(!r.ok)throw Error('reference-store-unavailable');const head=await r.json();
        if(head.configured)raw=JSON.stringify({version:1,sources:head.sources});
      }
      const imported=referenceContext(raw,row.text,owner);
      return {...context,knowledge:[...imported,...(context.knowledge??[])].slice(0,3)};
    };
    const loadImage = createImageLoader({ hosts:imageHosts(this.env.IMAGE_ALLOWED_HOSTS_JSON),zaloPhotoCdn:this.env.IMAGE_ZALO_PHOTO_CDN_ENABLED==='true',
      fetchImpl:(...args) => globalThis.fetch(...args) });
    ai.loadImage=async(value,{senderId}={})=>{
      let result=await loadImage(value);const until=Date.parse(this.env.IMAGE_PROTOCOL_CHECK_UNTIL??'');
      if(this.env.IMAGE_DIAGNOSTICS_ENABLED==='true')console.info('IMAGE_LOAD_RESULT',JSON.stringify(imageLoadDiagnostic(value,result)));
      const owners=adminIds(this.env.CATALOG_ADMIN_IDS_JSON);
      if(until>Date.now()&&until-Date.now()<=600000&&owners.length===1&&owners[0]===senderId){
        console.info('IMAGE_LOAD_CHECK',JSON.stringify(imageLoadDiagnostic(value,result)));
        if(result.status!=='ready'&&['image-http','image-header-or-dimensions'].includes(result.reason)){
          for(const profile of ['browser','browser-referrer']){
            if(Date.now()>=until)break;
            result=await createImageLoader({hosts:imageHosts(this.env.IMAGE_ALLOWED_HOSTS_JSON),zaloPhotoCdn:this.env.IMAGE_ZALO_PHOTO_CDN_ENABLED==='true',profile,timeoutMs:2000,fetchImpl:(...args)=>globalThis.fetch(...args)})(value);
            console.info('IMAGE_LOAD_CHECK',JSON.stringify(imageLoadDiagnostic(value,{...result,profile})));
            if(result.status==='ready')break;
          }
        }
      }
      return result;
    };
    let activeChatType=null;
    ai.checkScope=async(chatType=activeChatType)=>{
      const response=await this.operationService().fetch(new Request('https://inbox.internal/operation/check',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({chatType})}));
      return response.ok?response.json():{allowed:false,reason:'operation-unavailable'};
    };
    const generate=ai.generate;
    ai.generate=async(...args)=>{const permission=await ai.checkScope();return permission.allowed?generate.apply(ai,args):{status:'failed',reason:permission.reason};};
    ai.reserve = async (key, { eventAt,chatType } = {}) => {
      activeChatType=chatType;
      if (this.env.AI_BUDGET_MODE !== undefined && !['monthly-v1', 'provider-v1'].includes(this.env.AI_BUDGET_MODE)) throw Error('unauthorized-budget-mode');
      const service = ['monthly-v1', 'provider-v1'].includes(this.env.AI_BUDGET_MODE) ? this.operationService()
        : this.env.INBOX.get(this.env.INBOX.idFromName(JSON.stringify(['AI-BUDGET', trialName(this.env.AI_TRIAL_ID)])));
      const response = await service.fetch(new Request('https://inbox.internal/reserve', {
        method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify({ key, eventAt,chatType })
      }));
      if (!response.ok) throw Error('budget-unavailable');
      return response.json();
    };
    const sender=createZaloSender({ botToken: this.env.ZALO_BOT_TOKEN,fetchImpl:(...args)=>globalThis.fetch(...args),timeoutMs:3000 });
    if(Date.parse(this.env.WEBHOOK_AUTH_CHECK_UNTIL??'')>Date.now()){
      const reserve=ai.reserve,generate=ai.generate,send=sender.send;
      ai.reserve=async(...args)=>{const r=await reserve(...args);console.info('AI_ALLOCATION_RESULT',JSON.stringify({allowed:r.allowed===true}));return r;};
      ai.generate=async(...args)=>{const r=await generate.call(ai,...args);console.info('AI_GENERATION_RESULT',JSON.stringify({status:['ready','failed','uncertain'].includes(r?.status)?r.status:'unknown'}));return r;};
      sender.send=async(...args)=>{const r=await send(...args);console.info('ZALO_SEND_RESULT',JSON.stringify({status:['sent','rejected','uncertain'].includes(r?.status)?r.status:'unknown'}));return r;};
    }
    if(this.extensions)await this.extensions.reminders.drain(sender,{allowGroup:id=>this.group.allowed(id)});
    await this.inbox.drain(sender, ai);
    if(this.memory&&this.env.AI_ENABLED==='true'&&this.env.AI_PROVIDER_READY==='true'){
      const rows=await this.ctx.storage.list({prefix:'tin:'});
      if(![...rows.values()].some(r=>r.status==='queued'))await this.memory.update(this.summaryAI(ai));
      await this.memory.schedule();
    }
    if(this.extensions){
      await this.inbox.schedule(await this.ctx.storage.list({prefix:'tin:'}));
      const expiry=await this.extensions.uploads.next(),alarm=await this.ctx.storage.getAlarm();
      if(expiry!==null&&(alarm===null||expiry<alarm))await this.ctx.storage.setAlarm(Math.max(Date.now()+1,expiry));
    }
  }
}
export default {async fetch(request,env,ctx){
  if(env.RECOVERY_ENABLED!=='true')return handleCloud(request,env,ctx);
  const route=await recoveryCall(env,'routing');return handleCloud(request,{...generationEnv({...env,DATA_SETTINGS:route.settings},route.active),RECOVERY_ROUTING:route},ctx);
}};
