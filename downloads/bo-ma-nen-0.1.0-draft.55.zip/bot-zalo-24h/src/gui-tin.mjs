export const FIXED_REPLY = 'Đã nhận tin thử. Bot Zalo 24/7 đang kiểm tra kết nối.';

export function createZaloSender({ botToken, fetchImpl, timeoutMs = 3000 } = {}) {
  // No ambient fetch fallback: the caller must explicitly provide a transport.
  if (typeof botToken !== 'string' || !botToken.trim()) throw new Error('missing-bot-token');
  if (typeof fetchImpl !== 'function') throw new Error('missing-transport');
  if (!Number.isInteger(timeoutMs) || timeoutMs < 1) throw new Error('invalid-timeout');
  return {
    async send({ chat_id, text, photo }) {
      if (typeof chat_id !== 'string' || !chat_id || typeof text !== 'string' ||
          text.length < 1 || text.length > 2000) throw new Error('invalid-send-input');
      if(photo!==undefined){let u;try{u=new URL(photo);}catch{throw Error('invalid-photo-url');}if(u.protocol!=='https:'||u.username||u.password||photo.length>2048)throw Error('invalid-photo-url');}
      const controller = new AbortController();
      let timer;
      const deadline = new Promise(resolve => {
        timer = setTimeout(() => {
          controller.abort();
          resolve({ status: 'uncertain', reason: 'timeout' });
        }, timeoutMs);
      });
      const operation = (async () => {
        try {
          const response = await fetchImpl(
            `https://bot-api.zaloplatforms.com/bot${encodeURIComponent(botToken)}/${photo?'sendPhoto':'sendMessage'}`,
            { method: 'POST', redirect: 'manual', headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify(photo?{chat_id,photo,caption:text}:{chat_id,text}), signal: controller.signal }
          );
          const body = await response.json();
          if (response.ok && body?.ok === true && typeof body.result?.message_id === 'string' &&
              body.result.message_id.length > 0 && Number.isSafeInteger(body.result?.date)) {
            return { status: 'sent' };
          }
          // 5xx/redirect/conflicting success body leave delivery outcome ambiguous.
          if (((response.status >= 200 && response.status < 300) ||
              (response.status >= 400 && response.status < 500)) && body?.ok === false) {
            return { status: 'rejected', reason: 'api-rejected' };
          }
          return { status: 'uncertain', reason: 'ambiguous-response' };
        } catch {
          // Exception text may contain the token URL. Do not expose or log it.
          return { status: 'uncertain', reason: 'transport-failed' };
        }
      })();
      try { return await Promise.race([operation, deadline]); }
      finally { clearTimeout(timer); }
    }
  };
}
