# Bộ mã nền bot Zalo 24/7 [?]

Phiên bản nguồn và bộ học ghi trong manifest.json đi kèm. Đây là bản học thử cục bộ, chưa phát hành hoặc sẵn sàng bán. Không chứa key/tài khoản/domain/kho thật của người làm mẫu. Có mã và test giả để các AI cùng dựa một cấu trúc; từng bài giải thích và bật phần phù hợp, không viết lại bot tùy ý.

Nhận KHOI-TAO-BOT.md riêng từ người hướng dẫn, đặt vào gốc bộ mã và yêu cầu AI đọc rõ đường dẫn. Không giả định đổi tên file làm mọi AI tự đọc. Đọc [10 bài](docs/giao-trinh.md), [chi phí](docs/chi-phi.md), [vận hành](docs/van-hanh.md).

Chuẩn bị Node.js>=22 và một công cụ AI đọc được thư mục. Windows: npm.cmd ci; macOS: npm ci. Dùng lockfile, không npm update. Có mạng khi cài dependencies; kiểm giả không gọi API AI/Zalo. Chưa chứng minh cài trên Mac.

Kiểm gói bằng node scripts/kiem-goi.mjs; npm.cmd test chạy test giả; npm.cmd run check:build chỉ dry-run, không upload. Mặc định mọi chức năng ngoài tắt, không bí mật; tên Worker mẫu cần đổi trước deploy. Secrets nhập riêng trên Cloudflare, không dán vào prompt.

Mã nguồn có logic đã hỗ trợ nhưng cấu hình bật theo bài. Không gồm thư viện đã cài/node_modules, công cụ giữ phiên, công cụ triển khai riêng của tài khoản mẫu hoặc báo cáo/chat thật. Skill học được đóng riêng trên website; chưa chốt license thương mại hoặc phát hành công khai.
