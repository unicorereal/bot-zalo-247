# Bộ nhớ hội thoại — 14/10/2026

- Tin gốc: 30 ngày khi đồng ý lưu. Chọn tối đa 12 lượt gần đây và bổ sung lượt liên quan, tổng tối đa 20; trần nội dung UTF-8 24.000 byte gồm lịch sử/câu hiện tại/chỉ dẫn và phần tóm tắt được dự phòng. Tin dài có thể làm giảm số lượt.
- SUMMARY_ENABLED cần sự đồng ý riêng: một bản tóm tắt hiện hành theo người/chat, giữ đến khi xóa, tối đa 20 mục/4.000 ký tự nội dung. Cloudflare Durable Object SQLite lưu tóm tắt, máy tính không cần bật.
- Tạo lần đầu sau 20 lượt đã gửi thành công; kiểm sau mỗi 10 lượt mới. Kiểm vẫn có thể gọi API để biết có gì cần nhớ; không có nội dung mới thì giữ nội dung cũ, chỉ đánh dấu phần đã kiểm. Bổ sung một lượt kiểm trước hạn tin gốc ở ngày 29. API lỗi/quota có thể khiến chưa có tóm tắt; không tự gọi lặp một đợt không rõ kết quả.
- Viết tóm tắt sau khi gửi câu trả lời; đọc tóm tắt hiện hành cùng lịch sử khi trả lời. Ưu tiên tin hiện tại/lời sửa mới. Không coi tóm tắt là kiến thức cửa hàng, quyền quản trị hoặc bằng chứng đặt hàng.
- /bonho: xem các mục và mã mục (nội dung hiển thị rút gọn). /quen MA-MUC: thay mã bằng mã đã xem. Xóa mục và các nguồn có liên quan; xóa thêm tin chưa phân loại trong cùng phạm vi để chúng không ghi lại mục đã quên, giữ các mục tóm tắt khác.
- /xoabonho xac-nhan: xóa cả tin gốc và tóm tắt của chính người gửi trong chat đó, giữ biên nhận chống xử lý trùng. Không xóa dữ liệu người khác, không xóa tài liệu/kho sản phẩm. Tin gửi sau lệnh có thể được nhớ lại.
- Lệnh xóa phải viết rõ như trên; câu nói thông thường chưa tự thực hiện xóa. Việc tóm tắt có thể sai hoặc bỏ sót, giữ nguồn và kiểm cấu trúc không chứng minh mọi ý đều đúng. Phí tóm tắt dùng cùng Project/hạn mức/pause với AI; chưa đo chi phí thực tế.
