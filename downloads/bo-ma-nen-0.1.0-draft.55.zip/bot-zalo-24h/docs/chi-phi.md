# Tài khoản và chi phí — kiểm nguồn 10/10/2026

AI giúp xây bot và AI vận hành bot là hai khoản riêng. Bản nền vận hành qua OpenAI API với model gpt-6-luna; người học dùng một công cụ AI lập trình có quyền đọc thư mục để học. File khởi tạo không tự cấp API hay nơi chạy.

Tạo một Project riêng trong OpenAI API Platform, tạo key của Project đó và đặt cảnh báo chi tiêu theo mức tự chọn. Người học tự nhập OPENAI_API_KEY vào Cloudflare Secret. Không lấy key từ bộ bot của người khác.

**Spend alert và giới hạn chi tiêu:** Spend alert chỉ cảnh báo. Trong Project → Limits → Set spend limit, nhập Monthly spend limit và bật Enforce a hard limit, lưu rồi kiểm nhãn Limit enforced. Khi đạt hạn mức, yêu cầu mới có thể trả 429/project_spend_limit_exceeded. Chặn không tức thì nên chi tiêu có thể vượt nhẹ; không hứa trần tuyệt đối. Rate limit là giới hạn tốc độ, không thay hạn mức tháng. Bản này không có sổ dự phòng tiền nội bộ; chủ xem Usage/Billing và dùng /tatai khi muốn ngừng gọi AI. Nguồn kiểm 14/10/2026: https://developers.openai.com/api/docs/guides/spend-limits.
[OpenAI: rate limits and spend](https://developers.openai.com/api/docs/guides/terraform/rate-limits-and-spend).

Cloudflare Workers Free hỗ trợ Durable Objects SQLite; gói có giới hạn và thao tác có thể lỗi khi vượt quota. Không hứa miễn phí vô hạn hoặc uptime tuyệt đối. Kiểm gói của tài khoản trước deploy; không tự nâng Paid. Gói Zalo và giới hạn trên tài khoản cũng cần kiểm tại lúc cài.
[Cloudflare Durable Objects pricing](https://developers.cloudflare.com/durable-objects/platform/pricing/).
