import {loadSync,verifyCurrentResourcePlan}from './quan-ly-tai-nguyen-ai.mjs';
// Local account-authorized workflow: prepare -> human review -> apply exact hash -> deploy.
// Does not read account tokens, bot secrets or management links.
import {readFileSync,writeFileSync,mkdirSync,existsSync,copyFileSync,statSync,readdirSync,realpathSync} from 'node:fs';
import {resolve,dirname,basename,relative,isAbsolute} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawnSync} from 'node:child_process';
import {resourceMetadata,makeResourceBatch,validResourceBatch} from '../src/tai-nguyen-ai.mjs';
import {publicUrl,sha256,validateExtensions,emptyExtensions} from '../src/mo-rong-du-lieu.mjs';
import {imageDimensions,IMAGE_MAX_BYTES} from '../src/doc-anh.mjs';
export async function scanResourceFolder(folder,{known=[],origin}={}){
 const root=realpathSync(folder),items=[],skipped=[],seen=new Set(known.filter(x=>x.type==='photo'&&x.status==='active').map(x=>{try{const u=new URL(x.url);return u.origin===origin?u.pathname.match(/^\/tai-nguyen\/([a-f0-9]{64})\.(?:png|jpg)$/)?.[1]:null;}catch{return null;}}).filter(Boolean));let visited=0;
 async function walk(dir){for(const entry of readdirSync(dir,{withFileTypes:true}).sort((a,b)=>a.name.localeCompare(b.name))){if(++visited>5000)throw Error('Thư mục có quá nhiều tệp. Chọn thư mục nhỏ hơn.');const path=resolve(dir,entry.name),label=relative(root,path);
  if(entry.isSymbolicLink()){skipped.push({file:label,reason:'Liên kết tắt không được tự đọc.'});continue;}
  if(entry.isDirectory()){await walk(path);continue;}if(!entry.isFile()||!/\.(png|jpe?g)$/i.test(entry.name)){skipped.push({file:label,reason:'Không phải JPG/PNG.'});continue;}
  try{const actual=realpathSync(path),rel=relative(root,actual);if(rel.startsWith('..')||isAbsolute(rel))throw Error('Tệp nằm ngoài thư mục đã chọn.');if(statSync(actual).size>IMAGE_MAX_BYTES)throw Error('Ảnh vượt 8 MiB.');const bytes=readFileSync(actual),mime=bytes[0]===137?'image/png':'image/jpeg',dims=imageDimensions(bytes,mime);if(!dims||dims.some(x=>x<1||x>16000)||dims[0]*dims[1]>40000000)throw Error('Ảnh không hợp lệ hoặc kích thước quá lớn.');const hash=await sha256(bytes);if(seen.has(hash)){skipped.push({file:label,reason:'Trùng nội dung ảnh đã chọn hoặc đã nạp trên máy này.'});continue;}seen.add(hash);items.push({file:actual,type:'photo',title:entry.name.replace(/\.[^.]+$/,''),scope:'private'});}catch(e){skipped.push({file:label,reason:e.message});}
 }}
 await walk(root);if(items.length>100)throw Error('Có hơn 100 ảnh hợp lệ. Chọn thư mục nhỏ hơn; chưa nạp ảnh nào.');return {items,skipped};
}
export async function prepareResources(input,{root,config,inputDir=root,known=[]}){
 if(!Array.isArray(input)||!input.length||input.length>100)throw Error('Cần từ 1 đến 100 ảnh/link.');
 const origin=publicUrl(config.vars?.PUBLIC_BOT_ORIGIN);if(!origin||new URL(origin).pathname!=='/')throw Error('AI cần cấu hình địa chỉ HTTPS của Worker trước.');
 const assets=[],items=[],codes=known.map(x=>x.code);
 for(const raw of input){
  let value={...raw};if(raw.file){
   if(raw.url)throw Error('Mỗi mục chỉ chọn file ảnh hoặc link.');
   const path=resolve(inputDir,raw.file);if(statSync(path).size>IMAGE_MAX_BYTES)throw Error('Ảnh vượt 8 MiB.');const bytes=readFileSync(path);if(bytes.length>IMAGE_MAX_BYTES)throw Error('Ảnh vượt 8 MiB.');
   const mime=bytes[0]===137?'image/png':'image/jpeg',dims=imageDimensions(bytes,mime);if(!dims||dims.some(x=>x<1||x>16000)||dims[0]*dims[1]>40000000)throw Error('Ảnh không phải PNG/JPEG hợp lệ hoặc quá lớn.');
   const hash=await sha256(bytes),name=hash+(mime==='image/png'?'.png':'.jpg');
   assets.push({path,name,hash});value={...value,type:'photo',title:value.title||basename(path).replace(/\.[^.]+$/,''),url:new URL('/tai-nguyen/'+name,origin).href};
  }
  const item=resourceMetadata(value,codes);codes.push(item.code);
  if(!publicUrl(item.url))throw Error('Cần link HTTPS công khai, không phải đường dẫn trên máy.');
  const previous=known.find(x=>x.code===item.code);if(raw.update===true&&!previous&&!raw.expected)throw Error('Chưa có bản hiện hành để sửa an toàn.');
  items.push({item,expected:raw.expected??(raw.update===true?await sha256(JSON.stringify(previous)):null)});
 }
 const batch=await makeResourceBatch(config.name,items);if(!await validResourceBatch(batch))throw Error('Thông tin ảnh/link chưa hợp lệ hoặc mã bị trùng.');
 return {format:'bot-resources-review',publicSharingNotice:'Ảnh và link đã duyệt được chia sẻ công khai khi bot gửi. Chỉ duyệt nội dung được phép chia sẻ.',batch,assets};
}
export async function verifyPlan(plan,config){
 if(plan?.format!=='bot-resources-review'||!await validResourceBatch(plan.batch)||plan.batch.target!==config.name||!Array.isArray(plan.assets)||plan.assets.length>100)throw Error('Bản duyệt không hợp lệ hoặc sai Worker.');
 const origin=new URL(config.vars.PUBLIC_BOT_ORIGIN).origin;
 for(const a of plan.assets){if(statSync(a.path).size>IMAGE_MAX_BYTES)throw Error('Ảnh đã vượt giới hạn sau khi chuẩn bị.');if(!plan.batch.items.some(x=>x.item.type==='photo'&&x.item.url===origin+'/tai-nguyen/'+a.name))throw Error('Ảnh không nằm trong danh sách đã duyệt.');if(!/^[a-f0-9]{64}\.(png|jpg)$/.test(a.name)||a.hash!==a.name.split('.')[0]||await sha256(readFileSync(a.path))!==a.hash)throw Error('Ảnh đã thay đổi sau khi chuẩn bị; cần duyệt bản mới.');}
}
async function verifyRemote(item){
 let response=await fetch(item.url,{method:item.type==='photo'?'GET':'HEAD',redirect:'manual',signal:AbortSignal.timeout(15000)});if(item.type==='link'&&[405,501].includes(response.status)){response=await fetch(item.url,{method:'GET',redirect:'manual',signal:AbortSignal.timeout(15000)});await response.body?.cancel();}if(!response.ok)throw Error('Link không mở trực tiếp được; không nạp.');
 if(item.type==='photo'){const len=Number(response.headers.get('content-length'));if(len>IMAGE_MAX_BYTES)throw Error('Ảnh link quá lớn.');const reader=response.body.getReader(),parts=[];let total=0;try{while(true){const {value,done}=await reader.read();if(done)break;total+=value.length;if(total>IMAGE_MAX_BYTES)throw Error('Ảnh link quá lớn.');parts.push(value);}}finally{await reader.cancel();}const bytes=Buffer.concat(parts);const dims=imageDimensions(bytes,bytes[0]===137?'image/png':'image/jpeg');if(!dims||dims.some(x=>x<1||x>16000)||dims[0]*dims[1]>40000000)throw Error('Link ảnh không trả về ảnh PNG/JPEG hợp lệ.');}
}
async function main(){
 const root=fileURLToPath(new URL('../',import.meta.url)),[action,file,approval]=process.argv.slice(2),configPath=resolve(root,'wrangler.json');
 const config=JSON.parse(readFileSync(configPath,'utf8').replace(/^\uFEFF/,''));if(!file)throw Error('Dùng prepare <file-json> hoặc apply <ban-duyet-json> <ma-duyet>.');
 const inputPath=resolve(file),ledgerPath=resolve(root,'du-lieu-rieng/tai-nguyen/danh-muc-da-nap.json');let known=[];if(existsSync(ledgerPath)){const ledger=JSON.parse(readFileSync(ledgerPath,'utf8'));if(ledger.target===config.name)known=ledger.items;}
 if(action==='prepare'){
  const scan=statSync(inputPath).isDirectory()?await scanResourceFolder(inputPath,{known,origin:new URL(config.vars.PUBLIC_BOT_ORIGIN).origin}):null;if(scan&&!scan.items.length){console.log(JSON.stringify({deployed:false,items:[],skipped:scan.skipped,notice:'Không có ảnh mới hợp lệ để chuẩn bị.'}));return;}const plan=await prepareResources(scan?scan.items:JSON.parse(readFileSync(inputPath,'utf8').replace(/^\uFEFF/,'')),{root,config,inputDir:dirname(inputPath),known});if(scan)plan.skipped=scan.skipped;
  const out=resolve(root,'du-lieu-rieng/tai-nguyen/ban-duyet-'+plan.batch.id+'.json');mkdirSync(dirname(out),{recursive:true});writeFileSync(out,JSON.stringify(plan,null,2)+'\n');
  console.log(JSON.stringify({draft:out,approval:plan.batch.id,notice:plan.publicSharingNotice,skipped:plan.skipped??[],items:plan.batch.items.map(x=>x.item),deployed:false}));return;
 }
 if(action!=='apply')throw Error('Lệnh không hợp lệ.');
 const plan=JSON.parse(readFileSync(inputPath,'utf8'));await verifyPlan(plan,config);
 if(approval!==plan.batch.id)throw Error('Chưa có xác nhận cho đúng bản đã duyệt.');if(plan.syncId)loadSync(root,config,plan.syncId);
 if(config.vars?.EXTENSIONS_ENABLED!=='true')throw Error('AI cần bật trang quản lý trước.');
 const origin=new URL(config.vars.PUBLIC_BOT_ORIGIN).origin;
 for(const {item}of plan.batch.items)if(item.status!=='revoked'&&!plan.assets.some(a=>item.url===origin+'/tai-nguyen/'+a.name))await verifyRemote(item);
 const assetDir=resolve(root,'du-lieu-rieng/anh-gui-bot'),modulePath=resolve(root,'src/tai-nguyen-da-duyet.mjs');
 if(config.assets&&(config.assets.binding!=='RESOURCE_ASSETS'||resolve(root,config.assets.directory)!==assetDir||config.assets.run_worker_first!==true))throw Error('Đã có cấu hình file khác; AI cần kiểm trước, không tự ghi đè.');
 for(const a of plan.assets){const target=resolve(assetDir,'tai-nguyen',a.name);mkdirSync(dirname(target),{recursive:true});copyFileSync(a.path,target);}
 if(plan.assets.length||config.assets)config.assets={directory:'du-lieu-rieng/anh-gui-bot',binding:'RESOURCE_ASSETS',run_worker_first:true};
 writeFileSync(modulePath,'// Approved by the owner; keep out of public learner releases.\nexport const approvedResourceBatch='+JSON.stringify(plan.batch)+';\n');writeFileSync(configPath,JSON.stringify(config,null,2)+'\n');
 const run=spawnSync(process.execPath,[resolve(root,'node_modules/wrangler/bin/wrangler.js'),'deploy','--name',config.name],{cwd:root,windowsHide:true,encoding:'utf8',timeout:180000});
 for(let i=0;i<3;i++){
  let h;try{const r=await fetch(origin+'/health',{signal:AbortSignal.timeout(15000)});h=await r.json();}catch{continue;}if(h.resourcesImport?.id===plan.batch.id){if(h.resourcesImport.status!=='applied')throw Error('Đã triển khai nhưng chưa nạp: '+h.resourcesImport.status+'. Dữ liệu cũ được giữ; không ghi đè để thử.');
   const verified=await verifyCurrentResourcePlan(plan,{root,config});const normalized=validateExtensions({...emptyExtensions(),resources:plan.batch.items.map(x=>x.item)}).resources;mkdirSync(dirname(ledgerPath),{recursive:true});writeFileSync(ledgerPath,JSON.stringify({target:config.name,items:verified?verified.items.map(x=>x.item):[...known.filter(x=>!normalized.some(y=>y.code===x.code)),...normalized]},null,2)+'\n');
   console.log(JSON.stringify({deployed:true,imported:true,currentVerified:!!verified,count:h.resourcesImport.count,approval:plan.batch.id,testCommand:'/tainguyen '+plan.batch.items[0].item.code}));return;}
 }
 throw Error('Chưa xác nhận nạp thật (kết quả deploy: '+(run.status??run.error?.code??'chưa rõ')+'). Giữ bản đã duyệt và ảnh trên máy. Kiểm /health trước khi nạp lại.');
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});
