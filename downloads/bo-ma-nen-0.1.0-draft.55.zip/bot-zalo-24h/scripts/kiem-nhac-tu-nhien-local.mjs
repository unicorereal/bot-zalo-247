// Real Worker + SQLite. All outbound traffic is intercepted; no live account or model.
import {Miniflare,Response as MFResponse,convertV4MiniflareOptions} from 'miniflare';
import {readFileSync,writeFileSync,mkdirSync} from 'node:fs';
import {resolve} from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {fixture,FAKE_SECRET} from '../test/fixtures.mjs';
const root=fileURLToPath(new URL('../',import.meta.url)),persist=resolve(root,'verification/natural-reminder-fake-'+Date.now());mkdirSync(persist,{recursive:true});
let mf,aiCalls=0,sends=[];const checks=[];
const options={name:'natural-reminder-local',modules:true,script:readFileSync(resolve(root,'verification/worker-dryrun/worker-cloud.js'),'utf8'),compatibilityDate:'2026-10-08',host:'127.0.0.1',cf:false,resourcePersistencePath:persist,telemetry:{enabled:false},durableObjects:{INBOX:{className:'ChatInbox',useSQLite:true}},bindings:{BOT_ENABLED:'true',EXTENSIONS_ENABLED:'true',AI_ENABLED:'false',WEBHOOK_SECRET:FAKE_SECRET,ZALO_BOT_TOKEN:'fake-token'},outboundService:async req=>{const host=new URL(req.url).hostname;if(host==='api.openai.com'){aiCalls++;throw Error('forbidden-ai-call');}assert.equal(host,'bot-api.zaloplatforms.com');sends.push(await req.json());return MFResponse.json({ok:true,result:{message_id:'fake-reply',date:Date.now()}});}};
async function message(text,id,chat='fake-chat',sender='fake-user'){
 const body=fixture({text,chatId:chat,senderId:sender,messageId:id}).result;body.message.date=Date.now();
 const r=await mf.dispatchFetch('https://fake.invalid/webhook',{method:'POST',headers:{'Content-Type':'application/json','X-Bot-Api-Secret-Token':FAKE_SECRET},body:JSON.stringify(body)});assert.equal(r.status,200);return r.json();
}
async function waitSent(n){for(let i=0;i<100&&sends.length<n;i++)await new Promise(r=>setTimeout(r,25));assert.equal(sends.length,n);return sends[n-1].text;}
async function reopen(){await mf?.dispose();mf=new Miniflare(convertV4MiniflareOptions(options));await mf.dispatchFetch('https://fake.invalid/health');}
try{
 await reopen();await message('Nhắc t vào 9h sáng mai đi mua hoa quả','complete');assert.match(await waitSent(1),/Đã hẹn nhắc: đi mua hoa quả/);checks.push('natural-request-saved-by-worker');
 const duplicate=await message('Nhắc t vào 9h sáng mai đi mua hoa quả','complete');assert.equal(duplicate.status,'duplicate');assert.equal(sends.length,1);checks.push('duplicate-no-new-schedule');
 await message('Nhắc t sau 1 phút kiểm câu thường','relative');assert.match(await waitSent(2),/Đã hẹn nhắc: kiểm câu thường/);checks.push('one-minute-works-after-queue-delay');
 await message('Nhắc t lúc 9h đọc sách','missing');assert.match(await waitSent(3),/ngày nhắc/);
 await message('ngày mai','other-user','fake-chat','another-user');assert.doesNotMatch(await waitSent(4),/Đã hẹn nhắc/);
 await message('ngày mai','clarify');assert.match(await waitSent(5),/Đã hẹn nhắc: đọc sách/);checks.push('clarification-isolated-and-saved');
 await reopen();await message('/lichnhac','list');const list=await waitSent(6);assert.match(list,/đi mua hoa quả/);assert.match(list,/đọc sách/);checks.push('sqlite-reopen-preserves-reminders');
 await message('/huynhac 1','cancel');assert.match(await waitSent(7),/Đã hủy: đi mua hoa quả/);checks.push('legacy-list-and-cancel-work');
 assert.equal(aiCalls,0);checks.push('zero-paid-ai-calls');
 const report={date:'16/10/2026',checks,passed:checks.length,realAiOrZaloCalls:0};writeFileSync(resolve(root,'verification/natural-reminder-runtime.json'),JSON.stringify(report,null,2));console.log(JSON.stringify(report));
}finally{await mf?.dispose();}
