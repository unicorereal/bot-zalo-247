// Uses only the existing Wrangler deployment session; account tokens are never read.
import {readFileSync,writeFileSync,mkdirSync,existsSync}from'node:fs';
import {resolve,dirname}from'node:path';import{fileURLToPath}from'node:url';import{spawnSync}from'node:child_process';
import{emptyExtensions,validateExtensions,sha256}from'../src/mo-rong-du-lieu.mjs';
import{makeResourceBatch,validResourceBatch}from'../src/tai-nguyen-ai.mjs';import{validSyncRequest}from'../src/dong-bo-tai-nguyen.mjs';
const parse=p=>JSON.parse(readFileSync(p,'utf8').replace(/^\uFEFF/,''));
const encode=new TextEncoder();const from64=s=>Uint8Array.from(Buffer.from(s,'base64'));
export async function makeSyncSession(config,now=Date.now()){
 const origin=new URL(config.vars.PUBLIC_BOT_ORIGIN).origin;if(!/^https:\/\/[a-z0-9.-]+$/.test(origin)||!/^[a-z0-9][a-z0-9-]{0,62}$/.test(config.name??''))throw Error('Cần đúng Worker và địa chỉ HTTPS.');
 const keys=await crypto.subtle.generateKey({name:'RSA-OAEP',modulusLength:2048,publicExponent:new Uint8Array([1,0,1]),hash:'SHA-256'},true,['encrypt','decrypt']);
 const spec={schema:1,id:await sha256(crypto.getRandomValues(new Uint8Array(32))),target:config.name,origin,issued:now,expires:now+900000,publicKey:await crypto.subtle.exportKey('jwk',keys.publicKey)};
 return {spec,privateKey:await crypto.subtle.exportKey('jwk',keys.privateKey)};
}
export async function decryptSnapshot(envelope,session,now=Date.now()){
 const spec=session.spec;if(!validSyncRequest(spec,now)||envelope?.id!==spec.id||envelope.schema!==1||typeof envelope.data!=='string'||envelope.data.length>200000||typeof envelope.key!=='string'||envelope.key.length>400||typeof envelope.iv!=='string')throw Error('Phiên đồng bộ không hợp lệ hoặc hết hạn.');
 const privateKey=await crypto.subtle.importKey('jwk',session.privateKey,{name:'RSA-OAEP',hash:'SHA-256'},false,['decrypt']);const raw=await crypto.subtle.decrypt({name:'RSA-OAEP'},privateKey,from64(envelope.key));
 const key=await crypto.subtle.importKey('raw',raw,{name:'AES-GCM'},false,['decrypt']),aad=encode.encode(JSON.stringify([spec.id,spec.target,spec.origin,spec.issued,spec.expires]));
 const bytes=await crypto.subtle.decrypt({name:'AES-GCM',iv:from64(envelope.iv),additionalData:aad},key,from64(envelope.data));const data=JSON.parse(new TextDecoder().decode(bytes));
 if(data.schema!==1||data.id!==spec.id||data.target!==spec.target||data.origin!==spec.origin||!Number.isSafeInteger(data.revision)||!Number.isSafeInteger(data.at)||data.at<spec.issued-30000||data.at>now+30000||!Array.isArray(data.items)||data.items.length>100||!validateExtensions({...emptyExtensions(),resources:data.items.map(x=>x.item)}))throw Error('Danh mục trả về không hợp lệ.');
 for(const row of data.items)if(row.expected!==await sha256(JSON.stringify(row.item)))throw Error('Danh mục không khớp bản hiện hành.');return {...data,expires:spec.expires};
}
export async function fetchCurrent(session,fetchImpl=fetch){
 if(!validSyncRequest(session.spec))throw Error('Phiên đã hết hạn; đồng bộ lại trước khi sửa.');
 const response=await fetchImpl(session.spec.origin+'/tai-nguyen-sync/'+session.spec.id,{redirect:'error',signal:AbortSignal.timeout(15000),headers:{'Cache-Control':'no-cache'}});if(!response.ok)throw Error('Chưa đọc được danh mục thật; không thay đổi dữ liệu.');
 const reader=response.body.getReader(),chunks=[];let size=0;for(;;){const {done,value}=await reader.read();if(done)break;size+=value.length;if(size>220000){await reader.cancel();throw Error('Kết quả đồng bộ quá lớn.');}chunks.push(value);}const raw=Buffer.concat(chunks).toString('utf8');return decryptSnapshot(JSON.parse(raw),session);
}
export function loadSync(root,config,id){
 const session=parse(resolve(root,'du-lieu-rieng/tai-nguyen/phien-dong-bo.json'));
 if(!validSyncRequest(session.spec)||session.spec.id!==id||session.spec.target!==config.name||session.spec.origin!==new URL(config.vars.PUBLIC_BOT_ORIGIN).origin)throw Error('Đồng bộ lại danh mục trước khi sửa; không dùng bản cũ.');return session;
}
export async function verifyCurrentResourcePlan(plan,{root,config,fetchImpl=fetch}){
 if(!plan.syncId)return null;const data=await fetchCurrent(loadSync(root,config,plan.syncId),fetchImpl);
 for(const {item}of plan.batch.items){const actual=data.items.find(x=>x.item.code===item.code)?.item;const wanted=validateExtensions({...emptyExtensions(),resources:[item]}).resources[0];if(!actual||await sha256(JSON.stringify(actual))!==await sha256(JSON.stringify(wanted)))throw Error('Chưa xác nhận thay đổi thật. Không nạp lại trước khi kiểm.');}
 return data;
}
export async function prepareResourceChange(snapshot,selector,action,patch={},now=Date.now()){
 if(snapshot?.schema!==1||snapshot.expires<=now||!Array.isArray(snapshot.items)||!snapshot.items.length)throw Error('Cần đồng bộ danh mục hiện hành trước.');
 const exact=snapshot.items.filter(x=>x.item.code===selector.trim().toUpperCase()),matches=exact.length?exact:snapshot.items.filter(x=>x.item.title.trim().toLocaleLowerCase('vi')===selector.trim().toLocaleLowerCase('vi'));
 if(matches.length!==1)throw Error(matches.length?'Có nhiều mục cùng tên; chọn đúng mã trong danh sách đồng bộ.':'Chưa có đúng tên này trong danh mục hiện hành; không đoán mục khác.');
 const previous=matches[0];if(previous.expected!==await sha256(JSON.stringify(previous.item)))throw Error('Bản hiện hành không khớp.');let item={...previous.item};
 if(action==='revoke')item.status='revoked';else if(action==='resume')item.status='active';else if(action==='edit'){if(!patch||Array.isArray(patch)||Object.keys(patch).some(k=>!['title','description','keywords','scope','url'].includes(k)))throw Error('Chỉ sửa tên, mô tả, từ khóa, nơi gửi hoặc link của đúng mục.');item={...item,...patch};}else throw Error('Dùng revoke để ngừng gửi, resume để bật lại, edit để sửa. Chưa có xóa hẳn file.');
 if(JSON.stringify(item)===JSON.stringify(previous.item))return {unchanged:true,item};const batch=await makeResourceBatch(snapshot.target,[{item,expected:previous.expected}]);if(!await validResourceBatch(batch))throw Error('Thông tin mới chưa hợp lệ.');
 return {format:'bot-resources-review',syncId:snapshot.id,operation:action,publicSharingNotice:action==='revoke'?'Chỉ ngừng gửi đúng mục; không xóa file hoặc thay các mục khác.':'Ảnh/link được bật sẽ có thể chia sẻ công khai; kiểm đúng nội dung và nơi gửi.',batch,assets:[]};
}
// Called only by the account-authorized local CLI, never by a Zalo message.
export async function stopResourceByName(selector,{sync,apply}={}){
 if(typeof selector!=='string'||!selector.trim()||selector.length>160)throw Error('Cần đúng tên ảnh hoặc link muốn ngừng gửi.');
 if(typeof sync!=='function'||typeof apply!=='function')throw Error('Thiếu công cụ đồng bộ hoặc áp dụng.');
 const snapshot=await sync(),plan=await prepareResourceChange(snapshot,selector,'revoke');
 if(plan.unchanged)return {stopped:true,currentVerified:true,unchanged:true,title:plan.item.title,code:plan.item.code};
 const result=await apply(plan);if(result?.imported!==true||result.currentVerified!==true)throw Error('Chưa xác nhận đã ngừng gửi thật. Không báo thành công hoặc gửi lại liên tục.');
 return {stopped:true,currentVerified:true,title:plan.batch.items[0].item.title,code:plan.batch.items[0].item.code};
}
function toolResult(root,script,args,logName){
 const run=spawnSync(process.execPath,[resolve(root,script),...args],{cwd:root,windowsHide:true,encoding:'utf8',timeout:360000,maxBuffer:2*1024*1024});const path=resolve(root,'verification',logName);mkdirSync(dirname(path),{recursive:true});writeFileSync(path,(run.stdout??'')+'\n'+(run.stderr??''));
 if(run.status!==0)throw Error('Công cụ chưa hoàn tất. Xem verification/'+logName+'; chưa chuyển sang thao tác tay khi chưa kiểm lỗi.');
 for(const line of(run.stdout??'').split(/\r?\n/).reverse()){try{return JSON.parse(line);}catch{}}throw Error('Công cụ chưa trả biên nhận hợp lệ.');
}
async function main(){
 const root=process.cwd(),config=parse(resolve(root,'wrangler.json')),folder=resolve(root,'du-lieu-rieng/tai-nguyen');mkdirSync(folder,{recursive:true});const [action,...args]=process.argv.slice(2);
 if(action==='stop'){
  if(args.length!==1)throw Error('Cần một tên ảnh/link được đặt trong dấu nháy.');
  const result=await stopResourceByName(args[0],{sync:async()=>{const info=toolResult(root,'scripts/quan-ly-tai-nguyen-ai.mjs',['sync'],'resource-stop-sync.log');if(!info.synced)throw Error('Chưa đồng bộ.');const snapshot=parse(info.snapshot);loadSync(root,config,snapshot.id);return snapshot;},apply:async plan=>{const path=resolve(folder,'ban-duyet-'+plan.batch.id+'.json');writeFileSync(path,JSON.stringify(plan,null,2)+'\n');return toolResult(root,'scripts/nap-tai-nguyen-ai.mjs',['apply',path,plan.batch.id],'resource-stop-apply.log');}});
  console.log(JSON.stringify(result));return;
 }
 if(action==='sync'){
  if(config.vars?.EXTENSIONS_ENABLED!=='true'||!existsSync(resolve(root,'src/tai-nguyen-dong-bo-da-duyet.mjs')))throw Error('Cần bộ cài có công cụ đồng bộ và trang quản lý đã bật.');
  const session=await makeSyncSession(config);writeFileSync(resolve(folder,'phien-dong-bo.json'),JSON.stringify(session));writeFileSync(resolve(root,'src/tai-nguyen-dong-bo-da-duyet.mjs'),'// Short-lived public key pinned by account-authorized deployment. No private key here.\nexport const resourceSyncRequest='+JSON.stringify(session.spec)+';\n');
  const run=spawnSync(process.execPath,[resolve(root,'node_modules/wrangler/bin/wrangler.js'),'deploy','--name',config.name],{cwd:root,windowsHide:true,encoding:'utf8',timeout:180000});const log=resolve(root,'verification/resource-sync-deploy.log');mkdirSync(dirname(log),{recursive:true});writeFileSync(log,(run.stdout??'')+'\n'+(run.stderr??''));
  let data;for(let i=0;i<3;i++){try{data=await fetchCurrent(session);break;}catch{}}if(!data)throw Error('Chưa đồng bộ được danh mục thật. Không thay đổi mục nào; xem verification/resource-sync-deploy.log.');const path=resolve(folder,'danh-muc-hien-hanh.json');writeFileSync(path,JSON.stringify(data,null,2)+'\n');console.log(JSON.stringify({synced:true,snapshot:path,expires:data.expires,items:data.items.map(x=>({code:x.item.code,title:x.item.title,status:x.item.status,scope:x.item.scope,type:x.item.type}))}));return;
 }
 if(action==='change'){
  const [snapshotFile,operation,selector,patchFile]=args;if(!snapshotFile||!operation||!selector)throw Error('Cần bản đồng bộ, thao tác và đúng tên hoặc mã.');const snapshot=parse(resolve(snapshotFile));loadSync(root,config,snapshot.id);const plan=await prepareResourceChange(snapshot,selector,operation,patchFile?parse(resolve(patchFile)):{});if(plan.unchanged){console.log(JSON.stringify(plan));return;}const out=resolve(folder,'ban-duyet-'+plan.batch.id+'.json');writeFileSync(out,JSON.stringify(plan,null,2)+'\n');console.log(JSON.stringify({draft:out,approval:plan.batch.id,notice:plan.publicSharingNotice,items:plan.batch.items.map(x=>x.item),deployed:false}));return;
 }
 throw Error('Dùng sync, change hoặc stop.');
}
if(process.argv[1]&&resolve(process.argv[1])===fileURLToPath(import.meta.url))main().catch(e=>{console.error(e.message);process.exitCode=1;});
