import { run } from 'node:test';
import { tap } from 'node:test/reporters';
import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
const root = fileURLToPath(new URL('../', import.meta.url));
mkdirSync(resolve(root, 'verification'), { recursive: true });
// Same-process runner: restricted Windows environments may disallow spawning children.
const stream = run({ files: [resolve(root, 'test/nhac-tu-nhien.test.mjs'), resolve(root, 'test/recovery.test.mjs'), resolve(root, 'test/private-access.test.mjs'), resolve(root, 'test/flexible-data.test.mjs'), resolve(root, 'test/summary.test.mjs'), resolve(root, 'test/webhook.test.mjs'), resolve(root, 'test/cloud.test.mjs'), resolve(root, 'test/ai.test.mjs'), resolve(root, 'test/memory.test.mjs'), resolve(root, 'test/knowledge.test.mjs'), resolve(root, 'test/catalog-admin.test.mjs'), resolve(root, 'test/operations.test.mjs'), resolve(root, 'test/retention.test.mjs'), resolve(root, 'test/groups.test.mjs'), resolve(root, 'test/quote-shape.test.mjs'), resolve(root, 'test/images.test.mjs'), resolve(root, 'test/extensions.test.mjs'), resolve(root, 'test/aac-m4a.test.mjs')], isolation: 'none' });
let output = '';
for await (const chunk of stream.compose(tap)) {
  output += chunk;
  process.stdout.write(chunk);
}
mkdirSync(resolve(root, 'verification'), { recursive: true });
writeFileSync(resolve(root, 'verification/test-local.tap'), output);
const count = label => Number(output.match(new RegExp(`^# ${label} (\\d+)$`, 'm'))?.[1] ?? 0);
writeFileSync(resolve(root, 'verification/ket-qua-local.json'), JSON.stringify({
  version: JSON.parse(readFileSync(resolve(root, 'package.json'),'utf8')).version, recordedAt: new Date().toISOString(), node: process.version,
  evidence: 'local-fake-data', realApiCalls: 0, deployed: false,
  tests: count('tests'), passed: count('pass'), failed: count('fail'),
  exitCode: count('tests') > 0 && count('fail') === 0 ? 0 : 1, report: 'verification/test-local.tap'
}, null, 2) + '\n');
process.exitCode = count('tests') > 0 && count('fail') === 0 ? 0 : 1;
