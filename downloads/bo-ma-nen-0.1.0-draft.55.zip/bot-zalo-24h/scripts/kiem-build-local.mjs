import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { resolve } from 'node:path';
import { writeFileSync, mkdirSync } from 'node:fs';
const root = fileURLToPath(new URL('../', import.meta.url));
const localHome = resolve(root, 'verification/wrangler-local-home');
mkdirSync(resolve(localHome, '.wrangler'), { recursive: true });
// Isolate Wrangler from account configuration. No credentials are supplied.
const env = { ...process.env, WRANGLER_SEND_METRICS: 'false',
  USERPROFILE: localHome, HOME: localHome, XDG_CONFIG_HOME: localHome,
  WRANGLER_LOG_PATH: resolve(root, 'verification/wrangler-check.log') };
for (const key of Object.keys(env)) if (/^(CLOUDFLARE_|CF_)/.test(key)) delete env[key];
const result = spawnSync(process.execPath, [resolve(root, 'node_modules/wrangler/bin/wrangler.js'),
  'deploy', '--dry-run', '--outdir', 'verification/worker-dryrun'], { cwd: root, env, encoding: 'utf8' });
const report = { date: '10/10/2026', wrangler: '4.148.0', mode: 'dry-run-no-upload',
  exitCode: result.status ?? 1, deployed: false, errorCode: result.error?.code ?? null };
writeFileSync(resolve(root, 'verification/build-local.json'), JSON.stringify(report, null, 2) + '\n');
process.stdout.write(result.stdout ?? ''); process.stderr.write(result.stderr ?? '');
if (result.error) console.error('Local build could not start:', result.error.code);
process.exitCode = report.exitCode;
