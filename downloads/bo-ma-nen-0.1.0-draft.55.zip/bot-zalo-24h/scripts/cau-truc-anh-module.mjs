import { equalSecret,secretValid } from '../src/webhook.mjs';
import { protocolShape } from './cau-truc-trich-dan-module.mjs';
// Owner-only short-lived metadata probe. Never return URL, text, ID or credentials.
export function imageProtocolShape(body,env,secret,now=Date.now()){
 try{
  const until=Date.parse(env.IMAGE_PROTOCOL_CHECK_UNTIL??'');
  if(!Number.isFinite(until)||until<=now||until-now>600000||env.BOT_ENABLED!=='true'||
   !secretValid(env.WEBHOOK_SECRET)||!equalSecret(secret,env.WEBHOOK_SECRET))return null;
  const admins=JSON.parse(env.CATALOG_ADMIN_IDS_JSON??'[]');
  if(!Array.isArray(admins)||admins.length!==1||typeof admins[0]!=='string'||!admins[0])return null;
  const b=body?.ok===true?body.result:body,m=b?.message;
  if(b?.event_name!=='message.image.received'||m?.chat?.chat_type!=='PRIVATE'||m?.from?.is_bot!==false||m.from.id!==admins[0])return null;
  let hostname=null;
  if(typeof m.photo==='string'&&m.photo.length<=4096){
   const u=new URL(m.photo);
   if(u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&
    /^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/.test(u.hostname)&&
    !/(?:^|\.)(?:local|internal|test)$/.test(u.hostname))hostname=u.hostname;
  }
  const eventShape=protocolShape(b),urlCandidates=[];
  for(const row of eventShape.rows){
   if(row.type!=='string'||!/(?:\.|^)(?:url|photo|image|image_url|imageUrl|photo_url|photoUrl|src|download_url|original_url)$/.test(row.path))continue;
   let value=b;
   for(const key of row.path.split('.').slice(1))value=key==='item'?value?.[0]:value?.[key];
   if(typeof value!=='string'||value.length>4096)continue;
   try{const u=new URL(value);if(u.protocol==='https:'&&!u.username&&!u.password&&!u.port&&/^(?:[a-z0-9](?:[a-z0-9-]*[a-z0-9])?\.)+[a-z]{2,63}$/.test(u.hostname))urlCandidates.push({path:row.path,hostname:u.hostname});}catch{}
  }
  return {privateOwnerImage:true,photoString:typeof m.photo==='string',captionString:typeof m.caption==='string',
   captionNonempty:typeof m.caption==='string'&&Boolean(m.caption.trim()),hostname,
   photoShape:protocolShape({photo:m.photo}),eventShape,urlCandidates};
 }catch{return null;}
}
