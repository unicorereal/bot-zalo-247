// Protocol field labels and types only. No primitive values, dynamic keys or IDs.
import { equalSecret,secretValid } from '../src/webhook.mjs';
import { normalizeEvent } from '../src/chuan-tin.mjs';
import { groupOwner } from '../src/nhom-chat.mjs';
const fields = new Set(['ok','result','event_name','message','from','chat','id','display_name','is_bot','chat_type','text','message_id','date','photo','caption','url','voice_url','sticker',
  'quote','quoted','quoted_message','quotedMessage','quote_message','quoteMessage','reply','reply_to','replyTo','reply_to_message','replyToMessage','reply_message','replyMessage','replied_message','repliedMessage','reference','references','referenced_message','referencedMessage','reference_message','referenceMessage','original_message','originalMessage','original','content','body','data','type','msg','msg_id','msgId','cli_msg_id','cliMsgId','sender','sender_id','senderId','chat_id','chatId','messageId','timestamp','attachments','attachment','mentions','mention','reply_to_message_id','replyToMessageId','quote_id','quoteId','quote_text','quoteText','message_type','messageType','msgType','referenceId','referenceText']);
for(const field of ['image','images','image_url','imageUrl','photo_url','photoUrl','photos','src','download_url','original_url','thumbnail','width','height','size','params'])fields.add(field);
const kinds = new Set(['object','array','string','number','boolean','null']);
export function protocolShape(body) {
  const rows=[];let unknownFields=0,truncated=false;
  function walk(value,path,depth) {
    if(rows.length>=80){truncated=true;return;}
    const type=value===null?'null':Array.isArray(value)?'array':typeof value;
    if(!kinds.has(type))return;
    rows.push({path,type});
    if(depth>=5){if(type==='array'||type==='object')truncated=true;return;}
    if(type==='array'){if(value.length)walk(value[0],path+'.item',depth+1);return;}
    if(type==='object')for(const key of Object.keys(value)) {
      if(!fields.has(key)){unknownFields++;continue;}
      walk(value[key],path+'.'+key,depth+1);
    }
  }
  walk(body,'root',0);
  return {rows,unknownFields:Math.min(unknownFields,1000),truncated};
}
export function safeProtocolShape(source) {
  if(!source||!Array.isArray(source.rows))return null;
  const rows=source.rows.slice(0,80).filter(r=>r&&typeof r.path==='string'&&r.path.split('.').every((p,i)=>i===0?p==='root':p==='item'||fields.has(p))&&r.path.split('.').length<=6&&kinds.has(r.type)).map(r=>({path:r.path,type:r.type}));
  return {rows,unknownFields:Number.isInteger(source.unknownFields)&&source.unknownFields>=0?Math.min(source.unknownFields,1000):0,truncated:source.truncated===true};
}
export function shouldInspect(request,env,body,now,expiresAt) {
  if(now>=expiresAt||request.method!=='POST'||new URL(request.url).pathname!=='/webhook'||env.BOT_ENABLED!=='true'||!secretValid(env.WEBHOOK_SECRET)||!equalSecret(request.headers.get('X-Bot-Api-Secret-Token'),env.WEBHOOK_SECRET))return false;
  const event=normalizeEvent(body,{includeGroups:true}),owner=groupOwner(env);
  return event.kind==='text'&&event.chatType==='GROUP'&&owner!==null&&event.senderId===owner;
}
export function diagnosticEntry(expiresAt) {
  if(!Number.isSafeInteger(expiresAt))throw Error('invalid-expiry');
  return `import worker,{ChatInbox} from '../src/worker-cloud.mjs';
import {equalSecret,secretValid,readLimitedBody} from '../src/webhook.mjs';
import {protocolShape,shouldInspect} from '../scripts/cau-truc-trich-dan-module.mjs';
export {ChatInbox};
export default {async fetch(request,env,ctx){
 if(Date.now()<${expiresAt}&&request.method==='POST'&&new URL(request.url).pathname==='/webhook'&&env.BOT_ENABLED==='true'&&secretValid(env.WEBHOOK_SECRET)&&equalSecret(request.headers.get('X-Bot-Api-Secret-Token'),env.WEBHOOK_SECRET)){
  try{const raw=await readLimitedBody(request.clone(),16384);if(raw!==null){const body=JSON.parse(raw);
   if(shouldInspect(request,env,body,Date.now(),${expiresAt}))console.log('QUOTE_PROTOCOL_SHAPE',JSON.stringify(protocolShape(body)));
  }}catch{}
 }
 return worker.fetch(request,env,ctx);
}};
`;
}
