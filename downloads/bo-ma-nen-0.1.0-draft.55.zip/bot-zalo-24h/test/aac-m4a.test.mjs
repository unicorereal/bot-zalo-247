import test from 'node:test';
import assert from 'node:assert/strict';
import {isAdts,remuxAdts} from '../src/aac-m4a.mjs';
import {audioType,createVoiceReader} from '../src/tep-va-thoai.mjs';
const frame=()=>new Uint8Array([255,241,96,64,1,127,252,1,2,3,4]); // AAC-LC 24k mono,11bytes
test('AAC ADTS is not MP3 and remux retains compressed samples in M4A',()=>{
 const bytes=new Uint8Array([...frame(),...frame()]);assert.equal(isAdts(bytes),true);assert.equal(audioType(bytes).ext,'aac');
 const m4a=remuxAdts(bytes);assert.equal(audioType(m4a).ext,'mp4');
 assert.deepEqual([...m4a.slice(-8)],[1,2,3,4,1,2,3,4]);
 assert.equal(remuxAdts(bytes.slice(0,-1)),null);
 const changed=bytes.slice();changed[13]=100;assert.equal(remuxAdts(changed),null);
 const multiblock=bytes.slice();multiblock[6]=253;assert.equal(remuxAdts(multiblock),null);
 assert.equal(remuxAdts(new Uint8Array([...bytes,0])),null);
});
test('AAC transcription sends one actual M4A file and limits provider errors to categories',async()=>{
 const bytes=new Uint8Array([...frame(),...frame()]);let calls=0;
 const reader=createVoiceReader({apiKey:'fake-key',fetchImpl:async(u,o)=>{calls++;assert.equal(o.body.get('file').name,'speech.m4a');assert.equal(o.body.get('file').type,'audio/mp4');return Response.json({error:{message:'Invalid audio file format private-data'}},{status:400});}});
 const result=await reader({bytes});assert.equal(calls,1);assert.equal(result.category,'audio-format');assert.equal(JSON.stringify(result).includes('private-data'),false);
});
