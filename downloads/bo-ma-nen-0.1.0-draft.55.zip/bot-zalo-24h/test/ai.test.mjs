import test from 'node:test';
import assert from 'node:assert/strict';
import { createLuna, TrialBudget, AI_MODEL, AI_FAILURE } from '../src/ai-luna.mjs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { normalizeEvent } from '../src/chuan-tin.mjs';
import { handleCloud } from '../src/nhan-cloud.mjs';
import { fixture, request, FAKE_SECRET } from './fixtures.mjs';
import { readFileSync } from 'node:fs';
import { readCatalog } from '../src/kho-san-pham.mjs';

class Storage {
  constructor() { this.rows = new Map(); this.tail = Promise.resolve(); }
  async get(k) { return structuredClone(this.rows.get(k)); }
  async put(k,v) {
    if (this.failReady && v.ai?.status === 'ready') throw Error('fake-state-failure');
    if (this.failBudget && k === 'ai-budget') throw Error('fake-budget-failure');
    this.rows.set(k, structuredClone(v));
  }
  async list({prefix}) { return new Map([...this.rows].filter(([k]) => k.startsWith(prefix)).map(([k,v]) => [k,structuredClone(v)])); }
  async setAlarm(v) { this.alarm = v; }
  async transaction(fn) {
    const before = this.tail; let done;
    this.tail = new Promise(r => { done = r; }); await before;
    const backup = structuredClone(this.rows);
    try { return await fn(); } catch(e) { this.rows = backup; throw e; } finally { done(); }
  }
}
const event = (text = 'Câu hỏi giả', chat = 'chat-gia-A', messageId = 'msg-gia-A') => {
  const body = fixture({ chatId: chat, messageId }); body.result.message.text = text;
  return normalizeEvent(body, { includeText: true });
};
const answer = text => Response.json({ status: 'completed', output: [{ type: 'message', role: 'assistant',
  content: [{ type: 'output_text', text }] }] });
test('corrupt Unicode, whitespace and control characters in keys fail before network',async()=>{
  let calls=0;
  for(const key of ['sk-proj-giả','sk-proj-fake\r\n',' sk-fake','sk-fake value']){
    const ai=createLuna({apiKey:key,fetchImpl:async()=>{calls++;throw Error('unexpected-network');}});
    assert.equal(ai.configured,false);assert.equal(ai.configError,'invalid-ai-key-format');
    assert.deepEqual(await ai.generate('2+3'),{status:'failed',reason:'invalid-ai-key-format'});
  }
  assert.equal(calls,0);
});
test('invalid key format gives precise reply without reserve; catalog remains available',async()=>{
  const storage=new Storage();let calls=0,reserves=0,sent;
  const ai=createLuna({apiKey:'sk-proj-lỗi',fetchImpl:async()=>{calls++;}});ai.reserve=async()=>{reserves++;};
  const inbox=new DurableInbox(storage,{aiEnabled:true});await inbox.enqueue(event());
  await inbox.drain({send:async body=>{sent=body.text;return {status:'sent'};}},ai);
  assert.match(sent,/Key OpenAI đang lưu sai định dạng/);assert.equal(calls,0);assert.equal(reserves,0);
  const catalog=readCatalog(readFileSync(new URL('./catalog-gia.json',import.meta.url),'utf8'));
  const catalogInbox=new DurableInbox(new Storage(),{aiEnabled:true,knowledgeEnabled:true,catalog});
  await catalogInbox.enqueue(event('SP-KHO-A giá bao nhiêu và bảo hành bao lâu?'));
  await catalogInbox.drain({send:async body=>{sent=body.text;return {status:'sent'};}},ai);
  assert.match(sent,/345\.000/);assert.equal(calls,0);assert.equal(reserves,0);
});
test('AI rejection diagnostics retain only known status/code/param and scope flag, no key or provider text',async()=>{
  let calls=0,seen;
  const ai=createLuna({apiKey:'fake-private-key',onRejected:value=>seen=value,fetchImpl:async()=>{
    calls++;return Response.json({error:{code:'invalid_api_key',param:'service_tier',message:'fake-private-key Missing scopes: api.responses.write',secret:'fake-private'}},{status:401});
  }});
  assert.deepEqual(await ai.generate('fake'),{status:'failed',reason:'api-rejected'});
  assert.deepEqual(seen,{httpStatus:401,code:'invalid_api_key',param:'service_tier',responsesWriteMissing:true,category:'permission',bodyKind:'json-error'});
  assert.equal(JSON.stringify(seen).includes('fake-private'),false);assert.equal(calls,1);
});
test('unknown or malformed error payload and broken diagnostic sink do not retry or change rejection',async()=>{
  for(const body of ['not-json',JSON.stringify({error:{code:'fake-private',param:'fake-private',message:'fake-private'}})]){
    let seen,calls=0;
    const ai=createLuna({apiKey:'fake',onRejected:value=>{seen=value;throw Error('fake-sink');},fetchImpl:async()=>{calls++;return new Response(body,{status:403});}});
    assert.equal((await ai.generate('fake')).reason,'api-rejected');assert.equal(calls,1);
    assert.deepEqual(seen,{httpStatus:403,code:null,param:null,responsesWriteMissing:false,category:'unknown',bodyKind:body==='not-json'?'text':'json-error'});
  }
});
test('HTTP400 with null code/param is classified from bounded message without exposing it; HTML is distinct',async()=>{
  for(const [body,category,bodyKind] of [[JSON.stringify({error:{code:null,param:null,message:'service_tier default is not allowed for fake-private-project'}}),'service-tier','json-error'],[JSON.stringify({error:{message:'Invalid model for fake-private-project'}}),'model-access','json-error'],['<html>fake-private</html>','unknown','html']]){
    let seen;const ai=createLuna({apiKey:'fake',onRejected:value=>seen=value,fetchImpl:async()=>new Response(body,{status:400})});
    assert.equal((await ai.generate('fake')).reason,'api-rejected');assert.equal(seen.category,category);assert.equal(seen.bodyKind,bodyKind);
    assert.equal(JSON.stringify(seen).includes('fake-private'),false);
  }
});
test('HTTP400 unknown message emits only fixed vocabulary, no arbitrary text, secrets or IDs',async()=>{
  let seen;const ai=createLuna({apiKey:'fake-private-key',onRejected:value=>seen=value,fetchImpl:async()=>Response.json({error:{type:'invalid_request_error',code:null,param:null,message:"Incorrect API key format: sk-proj-fake-private-12345",privateId:'private-id'}},{status:400})});
  assert.equal((await ai.generate('fake')).reason,'api-rejected');
  assert.equal(seen.messagePresent,true);assert.deepEqual(seen.errorWords,['incorrect','api','key','format']);assert.equal(seen.errorType,'invalid_request_error');
  assert.equal(JSON.stringify(seen).includes('fake-private'),false);assert.equal(JSON.stringify(seen).includes('12345'),false);
});
function setup() {
  let clock = 1000;
  const storage = new Storage(), budgetStorage = new Storage(), budget = new TrialBudget(budgetStorage);
  const inbox = new DurableInbox(storage, { aiEnabled: true, now: () => clock });
  let calls = 0;
  const ai = { configured: true, reserve: k => budget.reserve(k), generate: async text => {
    calls++; return { status: 'ready', reply: `Đáp ${text}` };
  }};
  return { storage, budgetStorage, inbox, ai, calls: () => calls, advance: n => { clock += n; } };
}

test('E Luna sends current text only with explicit model, no tools/storage/reasoning', async () => {
  let observed;
  const ai = createLuna({ apiKey: 'key-gia', fetchImpl: async (url, opts) => {
    observed = { url, opts, body: JSON.parse(opts.body) }; return answer('Đáp giả');
  }});
  assert.deepEqual(await ai.generate('2+3?'), { status: 'ready', reply: 'Đáp giả' });
  assert.equal(observed.url, 'https://api.openai.com/v1/responses');
  assert.equal(observed.opts.redirect, 'manual'); assert.equal(observed.body.model, AI_MODEL);
  assert.equal(observed.body.input, '2+3?'); assert.equal(observed.body.store, false);
  assert.deepEqual(observed.body.tools, []); assert.deepEqual(observed.body.reasoning, { effort: 'none' });
  assert.equal(observed.body.max_output_tokens, 512); assert.equal(observed.body.service_tier, 'default');
  assert.equal(JSON.stringify(observed.body).includes('key-gia'), false);
});
test('E missing key, other model, empty/long text never uses transport', async () => {
  let calls = 0; const fetchImpl = async () => { calls++; return answer('fake'); };
  for (const options of [{}, {apiKey:'fake',model:'gpt-6-astra'}]) {
    const ai = createLuna({ ...options, fetchImpl }); assert.equal((await ai.generate('test')).status, 'failed');
  }
  const ai = createLuna({apiKey:'fake',fetchImpl});
  for (const text of ['', 'x'.repeat(1001)]) assert.equal((await ai.generate(text)).reason, 'input-limit');
  assert.equal(calls,0);
});
test('E API rejection/quota/5xx/redirect/invalid JSON are redacted and never retried', async () => {
  for (const status of [401,403,429,500,302,200]) {
    let calls = 0;
    const ai = createLuna({apiKey:'key-private-fake',fetchImpl:async () => {
      calls++; return new Response('private-error-body', {status});
    }});
    const result = await ai.generate('fake-question');
    assert.equal(calls,1); assert.ok(['failed','uncertain'].includes(result.status));
    assert.equal(JSON.stringify(result).includes('private'),false);
  }
});
test('E timeout aborts one request even if transport ignores cancellation', async () => {
  let signal, calls = 0;
  const ai = createLuna({apiKey:'fake',timeoutMs:10,fetchImpl:async (_,options) => {
    calls++; signal = options.signal; return new Promise(() => {});
  }});
  assert.equal((await ai.generate('fake')).reason,'timeout'); assert.equal(signal.aborted,true); assert.equal(calls,1);
});
test('E incomplete/empty/refusal/overlong/oversized AI output does not become an answer', async () => {
  const bodies = [ {status:'incomplete',output:[]}, {status:'completed',output:[]},
    {status:'completed',output:[{type:'message',role:'assistant',content:[{type:'refusal',refusal:'fake'}]}]} ];
  for (const body of bodies) {
    const ai = createLuna({apiKey:'fake',fetchImpl:async () => Response.json(body)});
    assert.notEqual((await ai.generate('fake')).status,'ready');
  }
  for (const size of [1901,70000]) {
    const ai = createLuna({apiKey:'fake',fetchImpl:async () => answer('x'.repeat(size))});
    assert.notEqual((await ai.generate('fake')).status,'ready');
  }
});
test('E shared budget grants exactly three concurrent allocations and survives reopen', async () => {
  const storage = new Storage(), budget = new TrialBudget(storage);
  const results = await Promise.all(Array.from({length:20}, (_,i) => budget.reserve(`chat-gia-${i}`)));
  assert.equal(results.filter(r => r.allowed).length,3);
  assert.equal((await new TrialBudget(storage).reserve('new-fake-chat')).allowed,false);
  assert.equal((await storage.get('ai-budget')).reservedMicroUsd,150000);
});
test('E duplicate reservation, small budget and failed durable writes cannot grant new calls', async () => {
  const storage = new Storage(), budget = new TrialBudget(storage,{maxMicroUsd:50000});
  assert.equal((await budget.reserve('fake-A')).allowed,true);
  assert.equal((await budget.reserve('fake-A')).reason,'already-allocated');
  assert.equal((await budget.reserve('fake-B')).allowed,false);
  assert.throws(() => new TrialBudget(storage,{maxCalls:4}));
  assert.throws(() => new TrialBudget(storage,{maxMicroUsd:1000001}));
  const broken = new Storage(); broken.failBudget = true;
  await assert.rejects(new TrialBudget(broken).reserve('fake-C'));
  assert.equal(broken.rows.size,0);
});
test('E corrupted shared budget fails closed instead of resetting allowance', async () => {
  for (const state of [{keys:[],reservedMicroUsd:-1},{keys:['fake'],reservedMicroUsd:0},
    {keys:['fake','fake'],reservedMicroUsd:100000},{keys:null,reservedMicroUsd:0}]) {
    const storage = new Storage(); await storage.put('ai-budget',state);
    await assert.rejects(new TrialBudget(storage).reserve('new-fake'));
    assert.deepEqual(await storage.get('ai-budget'),state);
  }
});
test('E simultaneous duplicate enqueue/drain generates once and retry reuses answer', async () => {
  const s = setup(); const sent = []; let attempt = 0;
  const sender = {send:async body => { sent.push(body); return {status:++attempt === 1 ? 'rejected':'sent'}; }};
  const queued = await Promise.all(Array.from({length:8},() => s.inbox.enqueue(event())));
  assert.equal(queued.filter(q => q.status === 'queued').length,1);
  await Promise.all([s.inbox.drain(sender,s.ai),s.inbox.drain(sender,s.ai)]);
  s.advance(5000); await new DurableInbox(s.storage,{aiEnabled:true,now:() => 6000}).drain(sender,s.ai);
  assert.equal(s.calls(),1); assert.equal(sent.length,2); assert.deepEqual(sent[0],sent[1]);
});
test('E two chat queues share the three-call cap without mixing input/output', async () => {
  const s = setup(), other = new DurableInbox(new Storage(),{aiEnabled:true,now:() => 1000});
  await s.inbox.enqueue(event('A','chat-gia-A'));
  await other.enqueue(event('B','chat-gia-B'));
  const sent = [], sender = {send:async b => {sent.push(b); return {status:'sent'};}};
  await Promise.all([s.inbox.drain(sender,s.ai),other.drain(sender,s.ai)]);
  assert.equal(s.calls(),2);
  assert.ok(sent.some(b => b.chat_id === 'chat-gia-A' && b.text === 'Đáp A'));
  assert.ok(sent.some(b => b.chat_id === 'chat-gia-B' && b.text === 'Đáp B'));
});
test('E exhausted budget sends clear fallback without more AI; failure retains allocated slot', async () => {
  const s = setup(); s.ai.generate = async () => ({status:'uncertain'});
  const sent = [], sender = {send:async b => {sent.push(b); return {status:'sent'};}};
  for (let i=0;i<4;i++) {await s.inbox.enqueue(event('fake','chat-gia-A',`fake-${i}`)); await s.inbox.drain(sender,s.ai);}
  assert.equal((await s.budgetStorage.get('ai-budget')).keys.length,3);
  assert.ok(sent.every(b => b.text === AI_FAILURE));
});
test('E missing config and invalid input do not allocate paid slots', async () => {
  const s = setup(); s.ai.configured = false;
  await s.inbox.enqueue(event()); await s.inbox.drain({send:async () => ({status:'sent'})},s.ai);
  assert.equal(s.budgetStorage.rows.size,0); assert.equal(s.calls(),0);
  const other = setup(); await other.inbox.enqueue(event('x'.repeat(1001)));
  await other.inbox.drain({send:async () => ({status:'sent'})},other.ai);
  assert.equal(other.budgetStorage.rows.size,0); assert.equal(other.calls(),0);
});
test('E restart after AI answer commit failure cannot regenerate or resend', async () => {
  const s = setup(); s.storage.failReady = true; await s.inbox.enqueue(event());
  await assert.rejects(s.inbox.drain({send:async () => assert.fail('must not send')},s.ai));
  assert.equal(s.calls(),1); s.storage.failReady = false;
  const reopened = new DurableInbox(s.storage,{aiEnabled:true,now:() => 32000});
  await reopened.drain({send:async () => assert.fail('must not send')},s.ai);
  assert.equal(s.calls(),1); assert.equal([...s.storage.rows.values()][0].status,'uncertain');
});
test('E old metadata keeps fixed reply and disabled mode stores no text', async () => {
  const s = setup(); const old = event(); delete old.text;
  await s.inbox.enqueue(old); const messages = [];
  await s.inbox.drain({send:async b => {messages.push(b);return {status:'sent'};}},s.ai);
  assert.equal(s.calls(),0); assert.match(messages[0].text,/Đã nhận tin thử/);
  const storage = new Storage(), disabled = new DurableInbox(storage);
  await disabled.enqueue(event('private-fake-text'));
  assert.equal(JSON.stringify([...storage.rows]).includes('private-fake-text'),false);
});
test('E cloud only includes current text in explicit AI mode and wrong auth cannot route', async () => {
  const routed = [], env = {BOT_ENABLED:'true',AI_ENABLED:'true',WEBHOOK_SECRET:FAKE_SECRET,ZALO_BOT_TOKEN:'fake',
    INBOX:{idFromName:n => n,get:() => ({fetch:async req => {routed.push(await req.json());return Response.json({status:'queued'});}})}};
  await handleCloud(request(),env); assert.equal(typeof routed[0].text,'string');
  await handleCloud(request(fixture(),{secret:'wrong'}),env); assert.equal(routed.length,1);
  env.AI_ENABLED = 'false'; await handleCloud(request(),env); assert.equal('text' in routed[1],false);
});
