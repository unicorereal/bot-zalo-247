import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync, writeFileSync } from 'node:fs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { handleCloud } from '../src/nhan-cloud.mjs';
import { normalizeEvent } from '../src/chuan-tin.mjs';
import { fixture, request, FAKE_SECRET } from './fixtures.mjs';
let networkAttempts = 0;
globalThis.fetch = async () => { networkAttempts++; throw Error('cloud-test-network-forbidden'); };

// Contract simulator, not a Cloudflare runtime. Serialized transactions roll
// back both records and alarm. Optional disk file contains fabricated IDs only.
class FakeStorage {
  constructor(file) {
    this.file = file; this.rows = new Map(); this.alarm = null; this.tail = Promise.resolve();
    if (file) { const data = JSON.parse(readFileSync(file, 'utf8')); this.rows = new Map(data.rows); this.alarm = data.alarm; }
  }
  async get(key) { return structuredClone(this.rows.get(key)); }
  async put(key, value) {
    if (this.failSentWrite && value.status === 'sent') throw Error('fake-write-failed');
    this.rows.set(key, structuredClone(value));
  }
  async list({ prefix }) { return new Map([...this.rows].filter(([k]) => k.startsWith(prefix)).map(([k,v]) => [k, structuredClone(v)])); }
  async setAlarm(value) { if (this.failAlarm) throw Error('fake-alarm-failure'); this.alarm = value; }
  async transaction(fn) {
    const previous = this.tail; let unlock;
    this.tail = new Promise(resolve => { unlock = resolve; });
    await previous;
    const backup = structuredClone([...this.rows]); const alarm = this.alarm;
    try {
      const result = await fn();
      if (this.file) writeFileSync(this.file, JSON.stringify({ rows: [...this.rows], alarm: this.alarm }) + '\n');
      return result;
    } catch (error) { this.rows = new Map(backup); this.alarm = alarm; throw error; }
    finally { unlock(); }
  }
}
const event = options => normalizeEvent(fixture(options));
const setup = (options = {}) => {
  let time = 1000; const storage = new FakeStorage();
  const inbox = new DurableInbox(storage, { now: () => time, ...options });
  return { storage, inbox, advance: value => { time += value; } };
};
const sent = { send: async () => ({ status: 'sent' }) };
test('C concurrent duplicate commits one queued record', async () => {
  const { storage, inbox } = setup();
  const result = await Promise.all(Array.from({ length: 12 }, () => inbox.enqueue(event())));
  assert.equal(result.filter(r => r.status === 'queued').length, 1); assert.equal(storage.rows.size, 1);
});
test('C ACK enqueue does not call sender; stores no text or secret', async () => {
  const { storage, inbox } = setup(); await inbox.enqueue(event());
  assert.equal([...storage.rows.values()][0].status, 'queued');
  assert.ok(!JSON.stringify([...storage.rows]).includes('Xin chào')); assert.ok(storage.alarm > 0);
});
test('C sent remains duplicate after new inbox instance', async () => {
  const { storage, inbox } = setup(); await inbox.enqueue(event()); await inbox.drain(sent);
  assert.equal((await new DurableInbox(storage).enqueue(event())).delivery, 'sent');
});
test('C disk reopen retains fake sent event', async () => {
  const file = new URL(`../verification/state-fake-${Date.now()}.json`, import.meta.url);
  writeFileSync(file, JSON.stringify({ rows: [], alarm: null }));
  const storage = new FakeStorage(file); const inbox = new DurableInbox(storage);
  await inbox.enqueue(event()); await inbox.drain(sent);
  const reopened = new DurableInbox(new FakeStorage(file));
  assert.equal((await reopened.enqueue(event())).delivery, 'sent');
});
test('C alarm failure rolls back enqueue before ACK', async () => {
  const { storage, inbox } = setup(); storage.failAlarm = true;
  await assert.rejects(inbox.enqueue(event())); assert.equal(storage.rows.size, 0);
});
test('C capacity does not evict prior records', async () => {
  const { storage, inbox } = setup({ maxRecords: 1 }); await inbox.enqueue(event());
  assert.equal((await inbox.enqueue(event({ messageId: 'other' }))).status, 'capacity'); assert.equal(storage.rows.size, 1);
});
test('C rejects retry after delay, at most two sends', async () => {
  const { storage, inbox, advance } = setup(); let calls = 0;
  const sender = { send: async () => { calls++; return { status: 'rejected' }; } };
  await inbox.enqueue(event()); await inbox.drain(sender); await inbox.drain(sender); assert.equal(calls, 1);
  advance(5000); await inbox.drain(sender); await inbox.drain(sender);
  assert.equal(calls, 2); assert.equal([...storage.rows.values()][0].status, 'rejected');
});
test('C unknown delivery never retries', async () => {
  const { storage, inbox, advance } = setup(); let calls = 0;
  const sender = { send: async () => { calls++; throw Error('fake-timeout'); } };
  await inbox.enqueue(event()); await inbox.drain(sender); advance(60000); await inbox.drain(sender);
  assert.equal(calls, 1); assert.equal([...storage.rows.values()][0].status, 'uncertain');
});
test('C restart with processing row marks uncertain without sending', async () => {
  const { storage, inbox } = setup(); await inbox.enqueue(event());
  const [key, row] = [...storage.rows][0]; row.status = 'processing'; row.attempts = 1; row.due = 0; await storage.put(key, row);
  await inbox.drain({ send: async () => assert.fail('must not resend') });
  assert.equal((await storage.get(key)).status, 'uncertain');
});
test('C state commit failure after send does not resend on recovery', async () => {
  const { storage, inbox, advance } = setup(); await inbox.enqueue(event()); storage.failSentWrite = true;
  await assert.rejects(inbox.drain(sent));
  assert.equal([...storage.rows.values()][0].status, 'processing');
  storage.failSentWrite = false; advance(30000);
  await inbox.drain({ send: async () => assert.fail('would duplicate') });
  assert.equal([...storage.rows.values()][0].status, 'uncertain');
});
test('C separate queued messages drain without mixing chats', async () => {
  const { inbox } = setup(); const chats = [];
  await inbox.enqueue(event()); await inbox.enqueue(event({ chatId: 'chat-gia-B' }));
  const sender = { send: async body => { chats.push(body.chat_id); return { status: 'sent' }; } };
  await inbox.drain(sender); await inbox.drain(sender);
  assert.deepEqual(chats.sort(), ['chat-gia-A', 'chat-gia-B']);
});
test('C duplicate pending event rearms alarm after pause', async () => {
  const { storage, inbox } = setup(); await inbox.enqueue(event()); storage.alarm = null;
  assert.equal((await inbox.enqueue(event())).status, 'duplicate'); assert.ok(storage.alarm);
});
function environment({ fail = false } = {}) {
  const routed = [];
  return { routed, env: { BOT_ENABLED: 'true', WEBHOOK_SECRET: FAKE_SECRET, ZALO_BOT_TOKEN: 'token-gia',
    INBOX: { idFromName: name => name, get: id => ({ fetch: async req => {
      if (fail) throw Error('fake-storage-failed');
      routed.push({ id, event: await req.json() }); return Response.json({ status: 'queued' });
    } }) } } };
}
test('C cloud validates and routes authenticated event before ACK', async () => {
  const { env, routed } = environment(); const response = await handleCloud(request(), env);
  assert.equal(response.status, 200); assert.equal((await response.json()).status, 'queued'); assert.equal(routed.length, 1);
});

test('D authenticated live flat envelope routes identical chat and dedup key', async () => {
  const { env, routed } = environment(); const wrapped = fixture();
  assert.equal((await handleCloud(request(wrapped.result), env)).status, 200);
  assert.deepEqual(routed[0].event, normalizeEvent(wrapped));
  assert.equal((await handleCloud(request(wrapped.result, { secret: 'wrong' }), env)).status, 403);
  assert.equal(routed.length, 1);
});

test('D flat envelope cannot rescue invalid wrapper or enable groups/bot messages', async () => {
  const { env, routed } = environment(); const flat = fixture().result;
  for (const body of [{ ...flat, ok: false }, { ...flat, result: null },
    { ...flat, message: { ...flat.message, chat: { id: 'fake-chat' } } }]) {
    assert.equal((await handleCloud(request(body), env)).status, 400);
  }
  for (const body of [fixture({ chatType: 'GROUP' }).result, fixture({ isBot: true }).result]) {
    assert.equal((await handleCloud(request(body), env)).status, 200);
  }
  assert.equal(routed.length, 0);
});
test('C wrong secret never touches durable object', async () => {
  const { env, routed } = environment(); assert.equal((await handleCloud(request(fixture(), { secret: 'wrong' }), env)).status, 403);
  assert.equal(routed.length, 0);
});
test('D temporary auth diagnostic contains only booleans, never secret or body', async () => {
  const { env, routed } = environment();
  env.WEBHOOK_AUTH_CHECK_UNTIL = new Date(Date.now() + 60000).toISOString();
  const previous = console.log; const records = [];
  console.log = (...args) => records.push(args);
  try {
    const response = await handleCloud(request({}, { secret: 'wrong-secret-private' }), env);
    assert.equal(response.status, 403); assert.equal(routed.length, 0);
    assert.deepEqual(records, [['WEBHOOK_AUTH_CHECK', JSON.stringify({ headerPresent: true, secretMatches: false, javaClient: false })]]);
    assert.ok(!JSON.stringify(records).includes('wrong-secret-private'));
  } finally { console.log = previous; }
});
test('D expired diagnostic logs nothing and missing secret still fails', async () => {
  const { env } = environment(); env.WEBHOOK_AUTH_CHECK_UNTIL = '2020-01-01T00:00:00Z';
  const previous = console.log; const records = []; console.log = (...args) => records.push(args);
  try {
    const req = request({}); req.headers.delete('X-Bot-Api-Secret-Token');
    assert.equal((await handleCloud(req, env)).status, 403); assert.equal(records.length, 0);
  } finally { console.log = previous; }
});
test('D broken diagnostic logger never disables authentication', async () => {
  const { env } = environment(); env.WEBHOOK_AUTH_CHECK_UNTIL = new Date(Date.now() + 60000).toISOString();
  const previous = console.log; console.log = () => { throw Error('fake-log-failure'); };
  try { assert.equal((await handleCloud(request({}, { secret: 'wrong' }), env)).status, 403); }
  finally { console.log = previous; }
});

test('D schema diagnostic logs booleans only and expires', async () => {
  const { env } = environment();
  const body = fixture(); body.result.message.text = 'private-fake-text';
  const records = [], previous = console.log;
  console.log = (...args) => records.push(args);
  try {
    env.WEBHOOK_AUTH_CHECK_UNTIL = new Date(Date.now() + 60000).toISOString();
    assert.equal((await handleCloud(request(body), env)).status, 200);
    const shape = JSON.parse(records.find(r => r[0] === 'WEBHOOK_SHAPE_CHECK')[1]);
    assert.ok(Object.values(shape).every(v => typeof v === 'boolean'));
    assert.equal(shape.dateValid, true); assert.equal(shape.privateChat, true);
    assert.equal(JSON.stringify(records).includes('private-fake-text'), false);
    records.length = 0; env.WEBHOOK_AUTH_CHECK_UNTIL = '2020-01-01T00:00:00Z';
    await handleCloud(request(body), env); assert.equal(records.length, 0);
  } finally { console.log = previous; }
});
test('C pause blocks new queue writes', async () => {
  const { env, routed } = environment(); env.BOT_ENABLED = 'false';
  assert.equal((await handleCloud(request(), env)).status, 503); assert.equal(routed.length, 0);
});
test('C no success ACK on durable failure', async () => {
  assert.equal((await handleCloud(request(), environment({ fail: true }).env)).status, 503);
});
test('C missing token reported separately from transport failure', async () => {
  const { env } = environment(); delete env.ZALO_BOT_TOKEN;
  assert.equal((await (await handleCloud(request(), env)).json()).error, 'missing-config');
});
test('C group and bot events never route', async () => {
  const { env, routed } = environment();
  for (const body of [fixture({ chatType: 'GROUP' }), fixture({ isBot: true })]) assert.equal((await handleCloud(request(body), env)).status, 200);
  assert.equal(routed.length, 0);
});
test('C deploy configuration preserves SQLite and keeps credentials out of plain variables', () => {
  const config = JSON.parse(readFileSync(new URL('../wrangler.json', import.meta.url), 'utf8'));
  assert.ok(['true','false'].includes(config.vars.BOT_ENABLED));
  for(const key of ['WEBHOOK_SECRET','ZALO_BOT_TOKEN','OPENAI_API_KEY','CATALOG_ADMIN_IDS_JSON'])assert.ok(!Object.hasOwn(config.vars,key),'private variable must use Secret: '+key);
  assert.deepEqual(config.durable_objects.bindings,[{name:'INBOX',class_name:'ChatInbox'}]);
  assert.deepEqual(config.migrations[0].new_sqlite_classes, ['ChatInbox']);
  assert.equal(config.migrations[0].tag,'v1');
});
test('C malformed or oversized request never reaches state', async () => {
  const { env, routed } = environment();
  assert.equal((await handleCloud(request({}, { raw: 'not-json' }), env)).status, 400);
  assert.equal((await handleCloud(request({}, { raw: 'x'.repeat(16385) }), env)).status, 413);
  assert.equal(routed.length, 0);
});
test('C no ambient network attempted throughout local suite', () => assert.equal(networkAttempts, 0));
