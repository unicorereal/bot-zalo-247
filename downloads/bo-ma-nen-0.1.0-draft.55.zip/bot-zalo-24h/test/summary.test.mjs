import test from 'node:test';
import assert from 'node:assert/strict';
import { ChatMemory, createSummarizer, validFacts } from '../src/tom-tat-chat.mjs';
import { relevantHistory, boundedInput } from '../src/bo-nho-chat.mjs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { createLuna } from '../src/ai-luna.mjs';
const DAY=86400000;
class Storage{
 constructor(){this.rows=new Map();this.alarm=null;}
 async get(k){return structuredClone(this.rows.get(k));}async put(k,v){this.rows.set(k,structuredClone(v));}
 async delete(k){this.rows.delete(k);}async list({prefix}){return new Map([...this.rows].filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k,structuredClone(v)]));}
 async transaction(f){return f();}async getAlarm(){return this.alarm;}async setAlarm(v){this.alarm=v;}
}
const row=(i,extra={})=>({chatId:'A',created:DAY+i,text:'Tôi học tiếng Anh '+i,status:'sent',ai:{status:'ready',reply:'Đã nhận.'},...extra});
const actor={chatId:'A'};
const fact=(id,text='Học tiếng Anh để đi du lịch.')=>({topic:'muc-tieu',text,sources:[id]});
const add=async(s,start,n,extra={})=>{for(let i=start;i<start+n;i++)await s.put('tin:'+String(i).padStart(4,'0'),row(i,extra));};
const model=(fn)=>({configured:true,reserve:async()=>({allowed:true}),summarize:fn});

test('memory builds at 20, checks at ten more, unchanged summary retains one current version',async()=>{
 const s=new Storage(),m=new ChatMemory(s,{now:()=>2*DAY});await add(s,1,19);let calls=0;
 const ai=model(async d=>{calls++;return {facts:d.facts.length?d.facts:[fact(d.turns[0].id)]};});
 assert.equal((await m.update(ai)).status,'idle');await add(s,20,1);assert.equal((await m.update(ai)).status,'updated');
 await add(s,21,9);assert.equal((await m.update(ai)).status,'idle');await add(s,30,1);assert.equal((await m.update(ai)).status,'unchanged');
 assert.equal(calls,2);assert.equal((await s.list({prefix:'memory:'})).size,1);
 const state=[...(await s.list({prefix:'memory:'})).values()][0];assert.equal(state.checked,30);assert.equal(state.updated,2*DAY);
});
test('summary survives transcript expiry and restart; other chat and group participant cannot read it',async()=>{
 const s=new Storage(),m=new ChatMemory(s,{now:()=>2*DAY});await add(s,1,20);await m.update(model(async d=>({facts:[fact(d.turns[0].id)]})));
 for(const [k] of await s.list({prefix:'tin:'}))await s.delete(k);
 const restarted=new ChatMemory(s,{now:()=>60*DAY});assert.match(await restarted.read(actor),/du lịch/);assert.equal(await restarted.read({chatId:'B'}),'');
 await add(s,1,20,{chatType:'GROUP',senderId:'one',chatId:'G'});await m.update(model(async d=>({facts:[fact(d.turns[0].id)]})));
 assert.equal(await m.read({chatType:'GROUP',senderId:'two',chatId:'G'}),'');
});
test('expiry flush works with fewer than 20 messages, summary opt-out makes no calls',async()=>{
 const s=new Storage();await add(s,1,2);const m=new ChatMemory(s,{now:()=>31*DAY});let calls=0;
 const ai=model(async d=>{calls++;return {facts:[fact(d.turns[0].id)]};});
 assert.equal((await m.update(ai,{expiringOnly:true})).status,'updated');
 assert.equal((await new ChatMemory(s,{enabled:false}).update(ai)).status,'disabled');assert.equal(calls,1);
});
test('invalid provenance and failed/ambiguous jobs do not replace memory or automatically repeat paid attempts',async()=>{
 assert.equal(validFacts([fact('invented')],[],[{id:'real',text:'x'}]),false);
 const s=new Storage();await add(s,1,20);const m=new ChatMemory(s,{now:()=>2*DAY});let calls=0;
 const ai=model(async()=>{calls++;return {facts:[fact('invented')]};});
 assert.equal((await m.update(ai)).status,'failed');assert.equal((await m.update(ai)).status,'idle');assert.equal(calls,1);assert.equal(await m.read(actor),'');
});
test('a forget operation invalidates an in-flight summary and scrubs raw data without deleting duplicate receipts',async()=>{
 const s=new Storage();await add(s,1,20);const m=new ChatMemory(s,{now:()=>2*DAY});let release;
 const waiting=new Promise(r=>release=r);const work=m.update(model(async d=>{await waiting;return {facts:[fact(d.turns[0].id)]};}));
 while(![...(await s.list({prefix:'memory:'})).values()][0]?.job)await new Promise(r=>setTimeout(r,0));
 assert.match(await m.command({...actor,text:'/xoabonho xac-nhan'}),/Đã xóa/);release();assert.equal((await work).status,'superseded');
 assert.equal(await m.read(actor),'');for(const r of s.rows.values())if(r.chatId==='A')assert.equal(r.text,undefined);
 assert.equal((await s.list({prefix:'tin:'})).size,20);
});
test('forget one topic removes its sources and unclassified text; retains other facts and another chat',async()=>{
 const s=new Storage();await add(s,1,20);
 await s.put('tin:other',row(1,{chatId:'B',text:'Thông tin B'}));
 const m=new ChatMemory(s,{now:()=>2*DAY});await m.update(model(async d=>({facts:[fact(d.turns[0].id),{topic:'lich-hoc',text:'Học thứ Hai.',sources:[d.turns[1].id]}]})));
 await s.put('tin:0030',row(30,{text:'Nội dung chưa phân loại'}));
 assert.match(await m.command({...actor,text:'/quen muc-tieu'}),/Đã quên/);
 const current=await m.read(actor);assert.ok(!current.includes('du lịch'));assert.match(current,/thứ Hai/);assert.equal((await s.get('tin:0030')).text,undefined);
 assert.equal((await s.get('tin:other')).text,'Thông tin B');
});
test('retrieval keeps 12 recent and up to 8 older related turns, with a bounded 20-turn window',()=>{
 const rows=new Map(Array.from({length:40},(_,i)=>['tin:'+i,row(i,{created:i<20?DAY+i:10*DAY+i,text:i<20?'Lịch học tiếng Anh '+i:'Chuyện mới '+i})]));
 const h=relevantHistory(rows,'A',10*DAY+50,'Lịch học tiếng Anh của tôi?');const user=h.filter(x=>x.role==='user');assert.equal(user.length,20);assert.equal(user.filter(x=>x.content.startsWith('Chuyện mới')).length,12);assert.equal(user.filter(x=>x.content.startsWith('Lịch học')).length,8);
 const long=h.map(x=>({...x,content:(x.role==='user'?'x':'y').repeat(x.role==='user'?1000:1900)}));const input=boundedInput('Câu hiện tại',long,'Luật');assert.equal(input.at(-1).content,'Câu hiện tại');assert.ok(new TextEncoder().encode('Luật'+JSON.stringify(input)).length<=24000);
});
test('raw memory deletion command does not pay AI, does not enter history, and has explicit confirmation',async()=>{
 const s=new Storage(),m=new ChatMemory(s,{now:()=>2*DAY});await add(s,1,2);
 assert.match(await m.command({...actor,text:'/xoabonho'}),/xac-nhan/);assert.ok((await s.get('tin:0001')).text);
 const inbox=new DurableInbox(s,{memory:m,aiEnabled:false,now:()=>2*DAY});await inbox.enqueue({key:'forget',chatId:'A',text:'/xoabonho xac-nhan'});let calls=0;
 await inbox.drain({send:async()=>({status:'sent'})},{configured:true,reserve:async()=>{calls++;return {allowed:true};}});assert.equal(calls,0);assert.equal((await s.get('tin:forget')).text,undefined);
});
test('summary transport uses strict JSON, store false, validates failure, and never uses external tools',async()=>{
 let request;const summarize=createSummarizer({apiKey:'fake-key',model:'gpt-6-luna',fetchImpl:async(_,opts)=>{request=JSON.parse(opts.body);return Response.json({status:'completed',output:[{type:'message',role:'assistant',content:[{type:'output_text',text:JSON.stringify({facts:[]})}]}]});}});
 assert.deepEqual(await summarize({facts:[],turns:[]}),{facts:[]});assert.equal(request.store,false);assert.equal(request.text.format.strict,true);assert.deepEqual(request.tools,[]);
});
test('normal AI request includes summary as quoted user data, preserves newest message, and supports more than three turns',async()=>{
 let request;const ai=createLuna({apiKey:'fake-key',fetchImpl:async(_,opts)=>{request=JSON.parse(opts.body);return Response.json({status:'completed',output:[{type:'message',role:'assistant',content:[{type:'output_text',text:'Thứ Hai.'}]}]});}});
 const history=Array.from({length:5},()=>[{role:'user',content:'tin'},{role:'assistant',content:'đáp'}]).flat();
 assert.equal((await ai.generate('Lịch mới thứ Hai.',{history,memorySummary:'Lịch cũ mỗi tối.'})).status,'ready');assert.equal(request.input.length,12);assert.equal(request.input.at(-1).content,'Lịch mới thứ Hai.');assert.ok(!request.instructions.includes('Lịch cũ mỗi tối'));assert.match(request.input[0].content,/Lịch cũ mỗi tối/);
});
