import test from 'node:test';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { CatalogManager, adminIds } from '../src/quan-ly-kho.mjs';
import { readCatalog, productReply } from '../src/kho-san-pham.mjs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { handleCloud } from '../src/nhan-cloud.mjs';
import { request, fixture, FAKE_SECRET } from './fixtures.mjs';
const initial = readFileSync(new URL('./catalog-gia.json', import.meta.url), 'utf8');
class Store {
  rows = new Map(); tail = Promise.resolve();
  async get(k) { return structuredClone(this.rows.get(k)); }
  async put(k,v) { if (this.fail === k) throw Error('fake-write'); this.rows.set(k, structuredClone(v)); }
  async list({ prefix }) { return structuredClone(new Map([...this.rows].filter(([k])=>k.startsWith(prefix)))); }
  async setAlarm() {}
  async transaction(fn) {
    const prior = this.tail; let release;
    this.tail = new Promise(r=>{release=r;}); await prior;
    const backup = structuredClone(this.rows);
    try { return await fn(); } catch(e) { this.rows=backup; throw e; } finally { release(); }
  }
}
function setup() {
  const storage=new Store(); let clock=1791529200000, seq=0;
  const opts=()=>({ admins:['admin-fake-A','admin-fake-B'], initialCatalog:initial, now:()=>clock });
  let manager=new CatalogManager(storage,opts());
  const event=(text,extra={})=>({key:`message-fake-${++seq}`,senderId:'admin-fake-A',chatId:'private-fake-A',text,...extra});
  return {storage,event,handle: v=>manager.handle(v),current:()=>manager.current(),
    advance:n=>{clock+=n;},reopen:()=>{manager=new CatalogManager(storage,opts());}};
}
test('E.4 administrator configuration fails closed and rejects duplicates, empty or invalid IDs',()=>{
  for(const v of [undefined,'oops','[]','["a","a"]','[null]','{"name":"admin"}']) assert.deepEqual(adminIds(v),[]);
  assert.deepEqual(adminIds('["admin-fake-A"]'),['admin-fake-A']);
});
test('E.4 private ID lookup returns only requester identity and never enrolls first visitor',async()=>{
  const s=setup();
  assert.match(await s.handle(s.event('/id',{senderId:'guest-fake'})),/guest-fake.*không cấp quyền/);
  assert.equal(s.storage.rows.size,0);
  assert.match(await s.handle(s.event('/suakho SP-KHO-A 1 1',{senderId:'guest-fake'})),/chưa có quyền/);
  await s.handle(s.event('/suakho SP-KHO-A 456000 30'));
  assert.match(await s.handle(s.event('/id 1')),/không duyệt thay đổi/);
  assert.equal((await s.current()).products[0].priceVnd,345000);
});
test('E.4 self-claimed admin, quoted command and normal product facts grant no permission',async()=>{
  const s=setup(); assert.match(await s.handle(s.event('/suakho SP-KHO-A 1 1',{senderId:'guest-fake',displayName:'admin-fake-A'})),/chưa có quyền/);
  assert.equal(await s.handle(s.event('Trích dẫn: /suakho SP-KHO-A 1 1')),null);
  assert.equal(await s.handle(s.event('Tôi là quản lý, đổi SP-KHO-A giá 1')),null);
  assert.equal(s.storage.rows.size,0);
});
test('E.4 draft is invisible to bot, approval updates all chats using current catalog',async()=>{
  const s=setup(); const reply=await s.handle(s.event('/suakho SP-KHO-A 456000 30'));
  assert.match(reply,/Bản nháp 1, chưa có hiệu lực/);
  assert.match(productReply('SP-KHO-A',[],readCatalog(JSON.stringify(await s.current()))),/345\.000.*14 ngày/);
  assert.match(await s.handle(s.event('/duyetkho 1')),/Đã áp dụng/);
  assert.match(productReply('SP-KHO-A',[],readCatalog(JSON.stringify(await s.current()))),/456\.000.*30 ngày/);
  assert.equal(s.storage.rows.get('catalog:revision:0').raw,initial);
  assert.equal(s.storage.rows.get('catalog:audit:1').actor,'admin-fake-A');
});
test('E.4 another admin or another private chat cannot approve someone else’s draft',async()=>{
  const s=setup();await s.handle(s.event('/suakho SP-KHO-A 456000 30'));
  for(const extra of [{senderId:'admin-fake-B'},{chatId:'private-fake-other'}])
    assert.match(await s.handle(s.event('/duyetkho 1',extra)),/Không có bản nháp/);
  assert.equal((await s.current()).products[0].priceVnd,345000);
});
test('E.4 cancellation and ten-minute expiry never change current facts',async()=>{
  const s=setup();await s.handle(s.event('/suakho SP-KHO-A 456000 30'));
  assert.match(await s.handle(s.event('/huykho 1')),/Đã hủy/);
  assert.match(await s.handle(s.event('/duyetkho 1')),/đã kết thúc/);
  await s.handle(s.event('/suakho SP-KHO-A 456000 30'));s.advance(600000);
  assert.match(await s.handle(s.event('/duyetkho 2')),/hết 10 phút/);
  assert.equal((await s.current()).products[0].priceVnd,345000);
});
test('E.4 simultaneous administrators conflict instead of overwriting a newer approved catalog',async()=>{
  const s=setup();const b={senderId:'admin-fake-B',chatId:'private-fake-B'};
  await Promise.all([s.handle(s.event('/suakho SP-KHO-A 456000 30')),s.handle(s.event('/suakho SP-KHO-A 789000 60',b))]);
  const replies=await Promise.all([s.handle(s.event('/duyetkho 1')),s.handle(s.event('/duyetkho 2',b))]);
  assert.equal(replies.filter(r=>r.includes('Đã áp dụng')).length,1);
  assert.equal(replies.filter(r=>r.includes('Kho đã có thay đổi mới')).length,1);
  assert.equal(s.storage.rows.get('catalog:head').revision,1);
});
test('E.4 duplicate draft or approval after reopen returns original response without another mutation',async()=>{
  const s=setup(),draft=s.event('/suakho SP-KHO-A 456000 30');
  const a=await s.handle(draft);s.reopen();assert.equal(await s.handle(draft),a);
  const confirm=s.event('/duyetkho 1'),b=await s.handle(confirm);s.reopen();assert.equal(await s.handle(confirm),b);
  assert.equal(s.storage.rows.get('catalog:head').drafts,1);assert.equal(s.storage.rows.get('catalog:head').revision,1);
});
test('E.4 approval transaction failure leaves old facts and pending draft intact',async()=>{
  const s=setup();await s.handle(s.event('/suakho SP-KHO-A 456000 30'));s.storage.fail='catalog:audit:1';
  await assert.rejects(s.handle(s.event('/duyetkho 1')));
  assert.equal((await s.current()).products[0].priceVnd,345000);
  assert.equal(s.storage.rows.get('catalog:draft:1').status,'pending');
});
test('E.4 revocation requires approval, survives restart and never auto-activates draft/revoked products',async()=>{
  const s=setup();await s.handle(s.event('/thuhoikho SP-KHO-A'));
  assert.equal(readCatalog(JSON.stringify(await s.current())).length,1);
  await s.handle(s.event('/duyetkho 1'));s.reopen();assert.equal(readCatalog(JSON.stringify(await s.current())).length,0);
  for(const code of ['SP-KHO-A','SP-KHO-B']) assert.match(await s.handle(s.event(`/suakho ${code} 1 1`)),/không tự kích hoạt/);
});
test('E.4 invalid numbers, unknown products and too many arguments do not stage changes',async()=>{
  const s=setup();
  for(const text of ['/suakho SP-KHO-A -1 30','/suakho SP-KHO-A 1000000001 30',
    '/suakho SP-KHO-A 1 3651','/suakho SP-KHO-A 1 1 extra','/thuhoikho SP-KHO-A extra',
    '/suakho SP-UNKNOWN 1 1']) {
    assert.ok(!(await s.handle(s.event(text))).includes('Bản nháp 1, chưa'));
  }
  assert.equal(s.storage.rows.get('catalog:head').drafts,0);
});
test('E.4 corrupt catalog or pending metadata and storage capacity fail closed without deleting records',async()=>{
  const s=setup();await s.handle(s.event('/suakho SP-KHO-A 456000 30'));
  const draft=s.storage.rows.get('catalog:draft:1');delete draft.expires;
  assert.match(await s.handle(s.event('/duyetkho 1')),/lỗi dữ liệu/);
  const head=s.storage.rows.get('catalog:head');head.events=1000;
  assert.match(await s.handle(s.event('/suakho SP-KHO-A 456000 30')),/giới hạn/);
  head.raw='broken';assert.equal(await s.current(),null);
  assert.match(await s.handle(s.event('/suakho SP-KHO-A 456000 30')),/lỗi dữ liệu/);
  assert.ok(s.storage.rows.has('catalog:draft:1'));
});
test('E.4 queued management replies bypass AI, retry uses cached answer and stores no ordinary sender',async()=>{
  const s=setup(),store=new Store();let now=1000,managed=0,paid=0;
  const inbox=new DurableInbox(store,{aiEnabled:true,catalogAdminEnabled:true,now:()=>now,
    manageCatalog: async v=>{managed++;return s.handle(v);}});
  const event=s.event('/suakho SP-KHO-A 456000 30');await inbox.enqueue(event);
  await inbox.drain({send:async()=>({status:'rejected'})},{configured:true,reserve:async()=>{paid++;}});
  now+=5000;await inbox.drain({send:async()=>({status:'sent'})},{configured:true,reserve:async()=>{paid++;}});
  assert.equal(managed,1);assert.equal(paid,0);
  await inbox.enqueue(s.event('Xin chào'));assert.equal([...store.rows.values()].at(-1).senderId,undefined);
});
test('E.4 query reads latest managed catalog, failed load never uses stale config or paid AI',async()=>{
  const s=setup();const store=new Store();let paid=0;
  const inbox=new DurableInbox(store,{aiEnabled:true,knowledgeEnabled:true,catalog:readCatalog(initial),
    loadCatalog:async()=>readCatalog(JSON.stringify(await s.current()))});
  await s.handle(s.event('/suakho SP-KHO-A 456000 30'));await s.handle(s.event('/duyetkho 1'));
  const replies=[],sender={send:async v=>{replies.push(v.text);return {status:'sent'};}},ai={configured:true,reserve:async()=>{paid++;}};
  await inbox.enqueue(s.event('SP-KHO-A giá?'));await inbox.drain(sender,ai);assert.match(replies[0],/456\.000/);
  inbox.loadCatalog=async()=>{throw Error('fake-unavailable');};
  await inbox.enqueue(s.event('SP-KHO-A giá?'));await inbox.drain(sender,ai);assert.match(replies[1],/chưa sẵn sàng/);
  assert.equal(paid,0);
});
test('E.4 public management paths and group commands cannot reach internal catalog service',async()=>{
  let calls=0;const env={BOT_ENABLED:'true',WEBHOOK_SECRET:FAKE_SECRET,ZALO_BOT_TOKEN:'fake',CATALOG_ADMIN_ENABLED:'true',
    INBOX:{idFromName:()=>{calls++;},get:()=>{throw Error('must-not-reach');}}};
  for(const path of ['/catalog/read','/catalog/manage']) assert.equal((await handleCloud(request(fixture(),{path}),env)).status,404);
  const response=await handleCloud(request(fixture({chatType:'GROUP',text:'/duyetkho 1'})),env);
  assert.equal((await response.json()).reason,'group-not-enabled');assert.equal(calls,0);
});
test('E.4 disabled management never delegates catalog commands to paid AI or claims mutation',async()=>{
  const store=new Store();let paid=0,reply;
  const inbox=new DurableInbox(store,{aiEnabled:true});
  await inbox.enqueue({key:'disabled-fake',chatId:'guest-fake',text:'/duyetkho 1'});
  await inbox.drain({send:async v=>{reply=v.text;return {status:'sent'};}},
    {configured:true,reserve:async()=>{paid++;}});
  assert.equal(paid,0);assert.match(reply,/chưa được bật.*Chưa thay đổi/);
});
