import test from 'node:test';
import assert from 'node:assert/strict';
import { PrivateAccess,privateAllowed,privateAccessScript } from '../src/quyen-chat-rieng.mjs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { normalizeEvent } from '../src/chuan-tin.mjs';
import { fixture } from './fixtures.mjs';
import {referenceContext} from '../src/du-lieu-tham-khao.mjs';
import {runInNewContext} from 'node:vm';
class Storage{
 constructor(){this.rows=new Map();this.tail=Promise.resolve();}
 async get(k){return structuredClone(this.rows.get(k));}async put(k,v){this.rows.set(k,structuredClone(v));}
 async delete(k){this.rows.delete(k);}
 async list({prefix}){return new Map([...this.rows].filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k,structuredClone(v)]));}async setAlarm(v){this.alarm=v;}
 async transaction(fn){const before=this.tail;let done;this.tail=new Promise(r=>done=r);await before;try{return await fn();}finally{done();}}
}
const request=(path,body,token)=>new Request('https://internal/private-access/'+path,{method:'POST',headers:token?{Authorization:'Bearer '+token}:{},body:JSON.stringify(body)});
function setup(){const storage=new Storage(),env={PRIVATE_ACCESS_ENABLED:'true',CATALOG_ADMIN_IDS_JSON:'["fake-owner"]'},service=new PrivateAccess(storage,env);env.INBOX={idFromName:v=>v,get:()=>({fetch:r=>service.handle(r)})};return {storage,env,service};}
async function session(service){const reply=await service.command({senderId:'fake-owner',text:'/quyenrieng',accessOrigin:'https://fake.example.com'});return reply.split('#').at(-1);}
test('owner-only short session protects persistent policy, conflicts and expiry; browser never persists token',async()=>{
 const {storage,service,env}=setup();assert.equal(await privateAllowed(env,{senderId:'fake-user'}),true);
 for(const e of [{senderId:'fake-user'},{senderId:'fake-owner',chatType:'GROUP'}])assert.ok(!(await service.command({...e,text:'/quyenrieng',accessOrigin:'https://fake.example.com'})).includes('#'));
 const token=await session(service);assert.equal((await service.handle(request('api',{action:'read'},'0'.repeat(64)))).status,403);
 const save={action:'save',restricted:true,ids:['fake-friend'],revision:0};assert.equal((await service.handle(request('api',save,token))).status,200);assert.equal((await service.handle(request('api',save,token))).status,409);
 assert.equal(await privateAllowed(env,{senderId:'fake-owner'}),true);assert.equal(await privateAllowed(env,{senderId:'fake-friend'}),true);assert.equal(await privateAllowed(env,{senderId:'fake-user'}),false);
 assert.equal(await privateAllowed(env,{senderId:'fake-user',kind:'text',text:'/id'}),true);assert.equal(await privateAllowed(env,{senderId:'fake-user',kind:'image',text:'/id'}),false);assert.equal(await privateAllowed(env,{senderId:'fake-user',chatType:'GROUP'}),true);
 assert.equal((await new PrivateAccess(storage,env).policy()).restricted,true);
 assert.equal((await service.handle(request('api',{action:'save',restricted:false,ids:[],revision:1},token))).status,200);assert.equal(await privateAllowed(env,{senderId:'fake-user'}),true);
 const expire=await storage.get('private-access:session');expire.expires=0;await storage.put('private-access:session',expire);assert.equal((await service.handle(request('api',{action:'read'},token))).status,403);
 const script=privateAccessScript();new Function(script);assert.equal(/localStorage|sessionStorage|document.cookie/.test(script),false);assert.ok(script.includes('history.replaceState'));
});
test('restriction blocks enqueue and queued AI after revoke; corrupt policy fails closed',async()=>{
 const {storage,service,env}=setup();const token=await session(service),chat=new Storage();let aiCalls=0,sends=0;
 const inbox=new DurableInbox(chat,{aiEnabled:true,privateAccessEnabled:true,allowPrivate:e=>privateAllowed(env,e),handlePrivateAccess:e=>service.command(e)});
 const event=normalizeEvent(fixture({senderId:'fake-user'}),{includeText:true});assert.equal((await inbox.enqueue(event)).status,'queued');
 await service.handle(request('api',{action:'save',restricted:true,ids:[],revision:0},token));
 await inbox.drain({send:async()=>{sends++;return {status:'sent'};}},{configured:true,reserve:async()=>({allowed:true}),generate:async()=>{aiCalls++;return {status:'ready',reply:'fake'};}});
 assert.equal(aiCalls,0);assert.equal(sends,0);assert.equal((await inbox.enqueue({...event,key:'fake-next'})).status,'ignored');
 await storage.put('private-access:policy',{restricted:'broken'});await assert.rejects(privateAllowed(env,event));
});
test('SQLite reference import above Secret limit keeps complete source and needs owner review before replacing',async()=>{
 const {storage,service,env}=setup();env.REFERENCE_SQLITE_ENABLED='true';const token=await session(service);
 const data={version:1,sources:[{code:'FAKE-FULL',title:'Hướng dẫn 15 phút',text:'Giới thiệu đầy đủ. '.repeat(360)+' 15 phút: tắt thiết bị, đọc sách, vẽ và lắng nghe không phán xét.',source:'fake',status:'active',audience:'public'},{code:'FAKE-OWNER',title:'Ghi chú riêng',text:'FAKE-PRIVATE-NOT-A-KEY',source:'fake',status:'active',audience:'owner'}]};
 assert.ok(new TextEncoder().encode(JSON.stringify(data)).length>5120);
 const draft=await service.handle(request('api',{action:'source-draft',document:data},token));assert.equal(draft.status,200);const d=await draft.json();
 assert.equal((await service.references.current()).configured,false);
 assert.equal((await service.handle(request('api',{action:'source-apply',id:d.id},'0'.repeat(64)))).status,403);
 assert.equal((await service.handle(request('api',{action:'source-apply',id:d.id},token))).status,200);
 const restored=new PrivateAccess(storage,env),head=await restored.references.current();assert.equal(head.sources[0].text,data.sources[0].text);
 const raw=JSON.stringify({version:1,sources:head.sources});assert.equal(referenceContext(raw,'Ghi chú riêng FAKE-PRIVATE',false).some(x=>x.code==='FAKE-OWNER'),false);assert.equal(referenceContext(raw,'Ghi chú riêng FAKE-PRIVATE',true).some(x=>x.code==='FAKE-OWNER'),true);
 assert.equal((await service.handle(request('api',{action:'source-apply',id:d.id},token))).status,409);
 const bad=await service.handle(request('api',{action:'source-draft',document:{version:1,sources:[{...data.sources[0],text:'X'.repeat(12001)}]}},token));assert.equal(bad.status,409);assert.equal((await service.references.current()).revision,1);
 const next=await (await service.handle(request('api',{action:'source-draft',document:{version:1,sources:[]}},token))).json();
 const newer=await (await service.handle(request('api',{action:'source-draft',document:data},token))).json();assert.equal((await service.handle(request('api',{action:'source-apply',id:next.id},token))).status,409);assert.equal((await service.handle(request('api',{action:'source-apply',id:newer.id},token))).status,200);
 const removed=await (await service.handle(request('api',{action:'source-draft',document:{version:1,sources:[]}},token))).json();await service.handle(request('api',{action:'source-apply',id:removed.id},token));assert.deepEqual((await service.references.current()).sources,[]);
});
test('owner page previews complete JSON and requires checkbox before applying',async()=>{
 const elements=new Map();const node=id=>{if(!elements.has(id))elements.set(id,{disabled:true,textContent:'',value:'',checked:false,files:[],setAttribute(){}});return elements.get(id);};let applied=0;
 const source={code:'FAKE-WEB',title:'Full source',text:'Full paragraph. '.repeat(500)+' END-MUST-KEEP',source:'fake',status:'active',audience:'public'};
 const file=JSON.stringify({version:1,sources:[source]});node('source-file').files=[{size:file.length,text:async()=>file}];
 runInNewContext(privateAccessScript(),{document:{getElementById:node},location:{hash:'#'+'1'.repeat(64),pathname:'/quyen-rieng'},history:{replaceState(){}},fetch:async(_,o)=>{
  const b=JSON.parse(o.body);if(b.action==='read')return {ok:true,json:async()=>({restricted:false,ids:[],referenceEnabled:true})};
  if(b.action==='source-draft')return {ok:true,json:async()=>({id:'fake-draft',sources:b.document.sources})};
  if(b.action==='source-apply'){applied++;return {ok:true,json:async()=>({count:1})};}throw Error('unexpected-action');
 }});
 await new Promise(r=>setImmediate(r));await node('source-preview').onclick();assert.ok(node('source-content').textContent.includes(source.text));assert.equal(node('source-apply').disabled,true);
 await node('source-apply').onclick();assert.equal(applied,0);node('source-confirm').checked=true;node('source-confirm').onchange();assert.equal(node('source-apply').disabled,false);
 await node('source-apply').onclick();assert.equal(applied,1);assert.ok(node('source-status').textContent.includes('Đã lưu 1 mục'));
});
