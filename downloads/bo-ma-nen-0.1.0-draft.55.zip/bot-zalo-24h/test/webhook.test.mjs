import test from 'node:test';
import assert from 'node:assert/strict';
import worker, { createLocalHandler } from '../src/webhook.mjs';
import { MemoryDeliveryStore } from '../src/kho-trang-thai.mjs';
import { createZaloSender, FIXED_REPLY } from '../src/gui-tin.mjs';
import { fixture, request, FAKE_SECRET } from './fixtures.mjs';

// Any accidental ambient network access causes a failing test.
let networkAttempts = 0;
globalThis.fetch = async () => { networkAttempts++; throw new Error('test-network-forbidden'); };

function setup({ store = new MemoryDeliveryStore(), send, ...config } = {}) {
  const calls = [];
  const handler = createLocalHandler({ webhookSecret: FAKE_SECRET, store, sender: {
    async send(body) { calls.push(body); return send ? send(body) : { status: 'sent' }; }
  }, ...config });
  return { handler, store, calls };
}
const invoke = async (handler, body = fixture(), options) => {
  const response = await handler(request(body, options));
  return { code: response.status, body: await response.json() };
};

test('tin chữ PRIVATE trả đúng chat.id, không lấy from.id hoặc chép nội dung khách', async () => {
  const { handler, calls } = setup();
  const result = await invoke(handler);
  assert.equal(result.code, 200);
  assert.equal(result.body.status, 'sent');
  assert.deepEqual(calls, [{ chat_id: 'chat-gia-A', text: FIXED_REPLY }]);
});

test('header sai hoặc thiếu bị chặn trước đọc payload và không gửi', async () => {
  const { handler, calls } = setup();
  for (const secret of [null, 'khong-dung-key-gia', 'x'.repeat(300)]) {
    assert.equal((await invoke(handler, null, { secret, raw: 'khong-json' })).code, 403);
  }
  assert.equal(calls.length, 0);
});

test('thiếu cấu hình báo 503 và không gửi', async () => {
  const { handler, calls } = setup({ webhookSecret: undefined });
  assert.equal((await invoke(handler)).code, 503);
  assert.equal(calls.length, 0);
  assert.equal((await invoke(createLocalHandler({ webhookSecret: FAKE_SECRET }))).code, 503);
});

test('không nhận method/path/content type ngoài hợp đồng', async () => {
  const { handler, calls } = setup();
  assert.equal((await invoke(handler, fixture(), { method: 'GET' })).code, 405);
  assert.equal((await invoke(handler, fixture(), { path: '/sai' })).code, 404);
  assert.equal((await invoke(handler, fixture(), { type: 'text/plain' })).code, 415);
  assert.equal(calls.length, 0);
});

test('JSON hỏng và envelope sai bị từ chối', async () => {
  const { handler, calls } = setup();
  assert.equal((await invoke(handler, null, { raw: '{' })).code, 400);
  for (const body of [null, [], 'abc', { ok: false, result: {} }, { ok: true, result: {} }]) {
    assert.equal((await invoke(handler, body)).code, 400);
  }
  assert.equal(calls.length, 0);
});

test('thiếu hoặc sai trường tin không được phát thành câu trả lời', async () => {
  const { handler, calls } = setup();
  const mutations = [
    m => { m.from = null; }, m => { m.from.is_bot = 'false'; }, m => { delete m.from.is_bot; },
    m => { m.chat.id = ''; }, m => { m.chat.chat_type = 'private'; },
    m => { m.message_id = 7; }, m => { m.date = '1791417600000'; },
    m => { m.text = ''; }, m => { m.text = { url: 'https://example.invalid' }; }
  ];
  for (const mutate of mutations) {
    const body = fixture(); mutate(body.result.message);
    assert.equal((await invoke(handler, body)).code, 400);
  }
  assert.equal(calls.length, 0);
});

test('message dạng String ở bảng tài liệu không được đoán thành object', async () => {
  const { handler, calls } = setup();
  const body = fixture(); body.result.message = JSON.stringify(body.result.message);
  assert.equal((await invoke(handler, body)).code, 400);
  assert.equal(calls.length, 0);
});

test('tin bot và nhóm được bỏ qua', async () => {
  const { handler, calls } = setup();
  assert.equal((await invoke(handler, fixture({ isBot: true }))).body.reason, 'bot-message');
  assert.equal((await invoke(handler, fixture({ chatType: 'GROUP' }))).body.reason, 'group-not-enabled');
  assert.equal(calls.length, 0);
});

test('media và sự kiện chưa hỗ trợ được ACK nhưng không tải/gửi', async () => {
  const { handler, calls } = setup();
  for (const eventName of ['message.image.received', 'message.voice.received',
    'message.sticker.received', 'message.unsupported.received', 'event-tuong-lai']) {
    assert.equal((await invoke(handler, fixture({ eventName }))).body.status, 'ignored');
  }
  assert.equal(calls.length, 0);
});

test('probe rỗng chỉ khi đã xác thực; không tuyên bố verification thật đạt', async () => {
  const { handler, calls } = setup();
  assert.equal((await invoke(handler, {})).body.reason, 'possible-probe');
  assert.equal((await invoke(handler, {}, { secret: null })).code, 403);
  assert.equal(calls.length, 0);
});

test('payload lớn giới hạn theo byte UTF-8, không tin Content-Length', async () => {
  const { handler, calls } = setup({ maxBodyBytes: 32 });
  assert.equal((await invoke(handler, null, { raw: JSON.stringify({ x: 'ắ'.repeat(20) }) })).code, 413);
  assert.equal(calls.length, 0);
});

test('event lặp tuần tự không gửi lại', async () => {
  const { handler, calls } = setup();
  assert.equal((await invoke(handler)).body.status, 'sent');
  const duplicate = await invoke(handler);
  assert.equal(duplicate.body.delivery, 'sent');
  assert.equal(calls.length, 1);
});

test('event lặp đồng thời chỉ một sender chạy trong một store local', async () => {
  let finish;
  const wait = new Promise(resolve => { finish = resolve; });
  const { handler, calls } = setup({ send: async () => { await wait; return { status: 'sent' }; } });
  const first = invoke(handler);
  // Wait until the first claim has reached the sender.
  while (calls.length === 0) await new Promise(resolve => setImmediate(resolve));
  const second = await invoke(handler);
  assert.equal(second.body.delivery, 'processing');
  finish();
  assert.equal((await first).body.status, 'sent');
  assert.equal(calls.length, 1);
});

test('cùng message_id ở hai chat được tách; từ chối dùng sender làm chat', async () => {
  const { handler, calls } = setup();
  await Promise.all([
    invoke(handler, fixture({ chatId: 'chat-gia-A', senderId: 'nguoi-chung' })),
    invoke(handler, fixture({ chatId: 'chat-gia-B', senderId: 'nguoi-chung' }))
  ]);
  assert.deepEqual(calls.map(call => call.chat_id).sort(), ['chat-gia-A', 'chat-gia-B']);
});

test('hai mã tin trong một chat không bị gộp nhầm', async () => {
  const { handler, calls } = setup();
  await invoke(handler, fixture({ messageId: 'gia-1' }));
  await invoke(handler, fixture({ messageId: 'gia-2' }));
  assert.equal(calls.length, 2);
});

test('API từ chối rõ ràng chỉ thử tối đa hai lần qua giao lại', async () => {
  const { handler, calls } = setup({ send: async () => ({ status: 'rejected' }) });
  for (let i = 0; i < 10; i++) await invoke(handler);
  assert.equal(calls.length, 2);
});

test('từ chối rồi gửi thành công cập nhật sent, giao lại không gửi tiếp', async () => {
  let times = 0;
  const { handler, calls } = setup({ send: async () => ({ status: ++times === 1 ? 'rejected' : 'sent' }) });
  assert.equal((await invoke(handler)).body.status, 'rejected');
  assert.equal((await invoke(handler)).body.status, 'sent');
  assert.equal((await invoke(handler)).body.delivery, 'sent');
  assert.equal(calls.length, 2);
});

test('timeout hoặc lỗi chưa rõ không ghi sent và không tự retry', async () => {
  const { handler, calls } = setup({ send: async () => { throw new Error('url-co-key-gia-khong-duoc-lo'); } });
  const result = await invoke(handler);
  assert.equal(result.body.status, 'uncertain');
  assert.ok(!JSON.stringify(result).includes('url-co-key'));
  assert.equal((await invoke(handler)).body.delivery, 'uncertain');
  assert.equal(calls.length, 1);
});

test('store đầy báo 503 thay vì âm thầm bỏ chống trùng', async () => {
  const { handler, calls } = setup({ store: new MemoryDeliveryStore({ maxRecords: 1 }) });
  await invoke(handler);
  assert.equal((await invoke(handler, fixture({ messageId: 'tin-moi' }))).code, 503);
  assert.equal((await invoke(handler)).body.delivery, 'sent');
  assert.equal(calls.length, 1);
});

test('store không truy cập được không gửi', async () => {
  const { handler, calls } = setup({ store: { claim() { throw new Error('gia'); }, finish() {} } });
  assert.equal((await invoke(handler)).code, 503);
  assert.equal(calls.length, 0);
});

test('ghi trạng thái lỗi không báo gửi thành công', async () => {
  const { handler } = setup({ store: { claim() { return { claimed: true, attempts: 1 }; },
    finish() { throw new Error('gia'); } } });
  const result = await invoke(handler);
  assert.equal(result.code, 503);
  assert.equal(result.body.error, 'state-write-failed');
});

test('health không tiết lộ khóa và entrypoint Worker khóa triển khai', async () => {
  const { handler } = setup();
  const health = await invoke(handler, null, { method: 'GET', path: '/health' });
  assert.equal(health.body.productionReady, false);
  assert.ok(!JSON.stringify(health).includes(FAKE_SECRET));
  assert.equal((await worker.fetch()).status, 503);
});

test('sender phải có transport tường minh và input hợp lệ', async () => {
  assert.throws(() => createZaloSender({ fetchImpl: () => {} }), /missing-bot-token/);
  assert.throws(() => createZaloSender({ botToken: 'token-gia' }), /missing-transport/);
  let calls = 0;
  const sender = createZaloSender({ botToken: 'token-gia', fetchImpl: async () => { calls++; } });
  await assert.rejects(sender.send({ chat_id: 'chat-gia', text: 'x'.repeat(2001) }), /invalid-send-input/);
  assert.equal(calls, 0);
});

test('adapter sendMessage tạo POST/JSON và đọc success qua fetch giả', async () => {
  let observed;
  const sender = createZaloSender({ botToken: 'token-gia', fetchImpl: async (url, options) => {
    observed = { url, options };
    return Response.json({ ok: true, result: { message_id: 'dap-gia', date: 1791417600000 } });
  } });
  assert.equal((await sender.send({ chat_id: 'chat-gia', text: FIXED_REPLY })).status, 'sent');
  assert.equal(observed.url, 'https://bot-api.zaloplatforms.com/bottoken-gia/sendMessage');
  assert.equal(observed.options.method, 'POST');
  assert.equal(observed.options.redirect, 'manual');
  assert.deepEqual(JSON.parse(observed.options.body), { chat_id: 'chat-gia', text: FIXED_REPLY });
});

test('adapter phân biệt rejected/5xx/HTTP thất bại/schema lỗi', async () => {
  const examples = [
    [Response.json({ ok: false, error_code: 400 }), 'rejected'],
    [Response.json({ ok: false }, { status: 400 }), 'rejected'],
    [Response.json({ ok: false }, { status: 500 }), 'uncertain'],
    [Response.json({ ok: false }, { status: 302 }), 'uncertain'],
    [Response.json({ ok: true, result: {} }), 'uncertain'],
    [Response.json({ ok: true, result: { message_id: 'gia', date: 1 } }, { status: 403 }), 'uncertain'],
    [new Response('html-khong-json'), 'uncertain']
  ];
  for (const [response, expected] of examples) {
    const sender = createZaloSender({ botToken: 'token-gia', fetchImpl: async () => response });
    assert.equal((await sender.send({ chat_id: 'chat-gia', text: 'Test' })).status, expected);
  }
});

test('adapter timeout được chặn thời gian cả khi transport bỏ qua AbortSignal', async () => {
  const sender = createZaloSender({ botToken: 'token-gia', timeoutMs: 15,
    fetchImpl: async () => new Promise(() => {}) });
  const result = await sender.send({ chat_id: 'chat-gia', text: 'Test' });
  assert.equal(result.status, 'uncertain');
  assert.equal(result.reason, 'timeout');
});

test('adapter không trả exception chứa URL/token giả ra log hoặc kết quả', async () => {
  const sender = createZaloSender({ botToken: 'token-gia', fetchImpl: async () => {
    throw new Error('https://bot-api.zaloplatforms.com/bottoken-gia/sendMessage');
  } });
  const result = await sender.send({ chat_id: 'chat-gia', text: 'Test' });
  assert.deepEqual(result, { status: 'uncertain', reason: 'transport-failed' });
});

test('mất store qua restart minh họa giới hạn local, không cam kết storage bền', async () => {
  const first = setup(); await invoke(first.handler);
  const restarted = setup(); await invoke(restarted.handler);
  assert.equal(first.calls.length + restarted.calls.length, 2);
});

test('toàn bộ suite không thử gọi fetch mạng thật', () => {
  assert.equal(networkAttempts, 0);
});
