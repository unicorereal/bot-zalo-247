import test from 'node:test';
import assert from 'node:assert/strict';
import {protocolShape,safeProtocolShape,diagnosticEntry,shouldInspect} from '../scripts/cau-truc-trich-dan-module.mjs';
import {fixture,request,FAKE_SECRET} from './fixtures.mjs';
test('quote schema never emits values or arbitrary field labels',()=>{
 const body={message:{text:'fake-private',from:{id:'fake-private'},quote:{text:'fake-private',message_id:'fake-private'}},'fake-private':'secret'};
 const result=protocolShape(body);assert.equal(JSON.stringify(result).includes('fake-private'),false);
 assert.ok(result.rows.some(r=>r.path==='root.message.quote.text'&&r.type==='string'));
 assert.equal(result.unknownFields,1);
});
test('quote schema bounded traversal and tail sanitization',()=>{
 const body={message:{quote:{data:{data:{data:{data:{text:'fake-private'}}}}}}};
 assert.equal(protocolShape(body).truncated,true);
 const result=safeProtocolShape({rows:[{path:'root.message.quote.text',type:'string',value:'fake-private'},{path:'root.fake-private',type:'string'}],unknownFields:9999});
 assert.deepEqual(result,{rows:[{path:'root.message.quote.text',type:'string'}],unknownFields:1000,truncated:false});
 assert.equal(JSON.stringify(result).includes('fake-private'),false);
});
test('quote diagnostic entry expires, authenticates and limits to owner group without replacing runtime',()=>{
 const entry=diagnosticEntry(123456);assert.match(entry,/Date.now\(\)<123456/);assert.match(entry,/equalSecret/);
 assert.match(entry,/shouldInspect/);
 assert.match(entry,/return worker.fetch\(request,env,ctx\)/);assert.doesNotMatch(entry,/console.log\([^\n]*raw/);
});
test('quote inspection accepts owner group only; expiration and invalid auth deny without observing guests/private',()=>{
 const env={BOT_ENABLED:'true',WEBHOOK_SECRET:FAKE_SECRET,CATALOG_ADMIN_IDS_JSON:'["owner"]'};
 const body=fixture({chatType:'GROUP',senderId:'owner'}),req=request(body);
 assert.equal(shouldInspect(req,env,body,10,20),true);
 assert.equal(shouldInspect(req,env,body,20,20),false);
 assert.equal(shouldInspect(req,{...env,BOT_ENABLED:'false'},body,10,20),false);
 assert.equal(shouldInspect(request(body,{secret:'wrong'}),env,body,10,20),false);
 assert.equal(shouldInspect(req,env,fixture({chatType:'GROUP',senderId:'guest'}),10,20),false);
 assert.equal(shouldInspect(req,env,fixture({senderId:'owner'}),10,20),false);
 assert.equal(shouldInspect(req,{...env,CATALOG_ADMIN_IDS_JSON:'["owner","other"]'},body,10,20),false);
});
