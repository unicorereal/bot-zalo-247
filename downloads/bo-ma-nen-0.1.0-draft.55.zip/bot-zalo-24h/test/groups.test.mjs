import test from 'node:test';
import assert from 'node:assert/strict';
import { normalizeEvent } from '../src/chuan-tin.mjs';
import { handleCloud } from '../src/nhan-cloud.mjs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { groupAllowed, inboxName, GROUP_ADMIN_REPLY, GroupPermission, isGroupActivation, groupOwner, GROUP_ACTIVATED_REPLY } from '../src/nhom-chat.mjs';
import { fixture, request, FAKE_SECRET } from './fixtures.mjs';
import { CatalogManager } from '../src/quan-ly-kho.mjs';
import { OperatingControl, OperatingBudget } from '../src/van-hanh-ai.mjs';
import {missingQuoteRequest,MISSING_QUOTE_REPLY} from '../src/thieu-trich-dan.mjs';

const env = () => ({ BOT_ENABLED: 'true', WEBHOOK_SECRET: FAKE_SECRET, ZALO_BOT_TOKEN: 'fake-token',
  AI_ENABLED: 'true', GROUP_ENABLED: 'true', GROUP_ALLOWED_IDS_JSON: '["group-A","group-B"]' });
const event = (senderId = 'user-A', messageId = 'message-1', text = 'Tôi mua áo đỏ cỡ M', chatId = 'group-A') =>
  normalizeEvent(fixture({ chatType: 'GROUP', chatId, senderId, messageId, text }), { includeText: true, includeGroups: true });
class Store {
  rows = new Map(); alarm = null;
  async get(k) { return structuredClone(this.rows.get(k)); }
  async put(k,v) { this.rows.set(k, structuredClone(v)); }
  async list({prefix}) { return new Map([...this.rows].filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k,structuredClone(v)])); }
  async setAlarm(t) { this.alarm=t; }
  async transaction(fn) { return fn(); }
}
function setup(options = {}) {
  const store = new Store(), inputs = [], sends = [];
  const inbox = new DurableInbox(store, {now:()=>10000, aiEnabled:true, memoryEnabled:true,
    historyRetrievalEnabled:true, allowGroup:id=>groupAllowed(env(),id), ...options});
  const ai = {configured:true, reserve:async()=>({allowed:true}), generate:async(text,context)=>{
    inputs.push({text,...context});return {status:'ready',reply:'Đáp giả.'};}};
  const sender={send:async body=>{sends.push(body);return {status:'sent'};}};
  return {store,inbox,inputs,sends,ai,sender};
}
test('E10 explicit missing quote and bare demonstrative never substitute recent history, no paid call',async()=>{
 const s=setup();await s.inbox.enqueue(event('user-A','prior','7 cộng 8?'));await s.inbox.drain(s.sender,s.ai);
 s.ai.reserve=async()=>assert.fail('missing quote must not reserve');
 for(const [i,text] of ['Tin được trích dẫn đang nói phép tính nào?','@Bot An 24h đây là phép tính gì','@Bot An 24h đây là món gì'].entries()){
  await s.inbox.enqueue(event('user-A','quote-'+i,text));await s.inbox.drain(s.sender,s.ai);
  assert.equal(s.sends.at(-1).text,MISSING_QUOTE_REPLY);
 }
 assert.equal(s.inputs.length,1);assert.ok([...s.store.rows.values()].slice(1).every(r=>!Object.hasOwn(r,'text')));
 const reopened=new DurableInbox(s.store,{allowGroup:()=>true});
 assert.equal((await reopened.enqueue(event('user-A','quote-0','Tin được trích dẫn đang nói phép tính nào?'))).status,'duplicate');
});
test('E10 supplied original text, ordinary memory and definition questions keep normal path',async()=>{
 const s=setup();const text='Nội dung gốc: 2 cộng 3 bằng 5.\nCâu hỏi: Đây là phép tính gì?';
 for(const value of [text,'Tôi vừa muốn mua áo màu gì?','Trích dẫn là gì?','SP-KHO-A giá bao nhiêu?','2 cộng 3 bằng mấy?'])assert.equal(missingQuoteRequest(value),false);
 await s.inbox.enqueue(event('user-A','copied',text));await s.inbox.drain(s.sender,s.ai);
 assert.equal(s.inputs[0].text,text);assert.equal(s.sends[0].text,'Đáp giả.');
 assert.equal(missingQuoteRequest(null),false);assert.equal(missingQuoteRequest('x'.repeat(1001)),false);
});
test('E10 reference prose cannot bypass group enrollment or group management guards',async()=>{
 const s=setup({catalogAdminEnabled:true,manageCatalog:async()=>assert.fail('group management forbidden')});
 assert.equal((await s.inbox.enqueue(event('user-A','denied','Tin được trích dẫn là gì?','denied'))).status,'ignored');
 await s.inbox.enqueue(event('user-A','command','/suakho Tin được trích dẫn'));await s.inbox.drain(s.sender,s.ai);
 assert.equal(s.sends[0].text,GROUP_ADMIN_REPLY);assert.equal(s.inputs.length,0);
});
test('E9 group requires explicit enabled switch and valid unique owner allowlist', () => {
  assert.equal(groupAllowed(env(),'group-A'),true);
  assert.equal(groupAllowed(env(),'not-chosen'),false);
  for(const raw of ['[]','null','["group-A","group-A"]','["group-A",1]','broken'])
    assert.equal(groupAllowed({...env(),GROUP_ALLOWED_IDS_JSON:raw},'group-A'),false);
  assert.equal(groupAllowed({...env(),GROUP_ENABLED:'false'},'group-A'),false);
  assert.equal(groupAllowed({...env(),GROUP_ALLOWED_IDS_JSON:JSON.stringify(Array(101).fill('group-A'))},'group-A'),false);
});
test('E9 authenticated flat GROUP parses only with explicit opt-in; bot and broken wrapper still ignored/invalid', () => {
  const flat=fixture({chatType:'GROUP'}).result;
  assert.equal(normalizeEvent(flat).reason,'group-not-enabled');
  assert.equal(normalizeEvent(flat,{includeGroups:true}).chatType,'GROUP');
  assert.equal(normalizeEvent({...flat,ok:false},{includeGroups:true}).kind,'invalid');
  assert.equal(normalizeEvent(fixture({chatType:'GROUP',isBot:true}),{includeGroups:true}).reason,'bot-message');
});
test('E9 routing distinguishes PRIVATE and GROUP with identical chat ID; denied group never touches DO', async () => {
  const routes=[], e={...env(),INBOX:{idFromName:x=>x,get:name=>({fetch:async req=>{
    routes.push({name,event:await req.json()});return Response.json({status:'queued'});}})}};
  for(const chatType of ['PRIVATE','GROUP']) assert.equal((await handleCloud(request(fixture({chatType,chatId:'group-A'}).result),e)).status,200);
  assert.deepEqual(routes.map(r=>r.name),['["PRIVATE","group-A"]','["GROUP","group-A"]']);
  assert.equal((await (await handleCloud(request(fixture({chatType:'GROUP',chatId:'not-chosen'})),e)).json()).reason,'group-not-allowed');
  assert.equal((await handleCloud(request(fixture({chatType:'GROUP',chatId:'group-A'}),{secret:'bad'}),e)).status,403);
  assert.equal(routes.length,2);
});
test('E9 group stores actor separately, sends to group, duplicate survives fresh inbox', async () => {
  const s=setup();await s.inbox.enqueue(event());await s.inbox.drain(s.sender,s.ai);
  const record=[...s.store.rows.values()][0];assert.equal(record.senderId,'user-A');assert.equal(record.chatType,'GROUP');
  assert.equal(s.sends[0].chat_id,'group-A');assert.equal(s.inputs.length,1);
  const reopened=new DurableInbox(s.store,{allowGroup:()=>true});
  assert.equal((await reopened.enqueue(event())).status,'duplicate');assert.equal(s.sends.length,1);
});
test('E9 same group different actors never share recent or topic history; own history remains', async () => {
  const s=setup();await s.inbox.enqueue(event());await s.inbox.drain(s.sender,s.ai);
  await s.inbox.enqueue(event('user-B','message-2','Áo tôi màu gì?'));await s.inbox.drain(s.sender,s.ai);
  assert.deepEqual(s.inputs[1].history,[]);
  await s.inbox.enqueue(event('user-A','message-3','Áo tôi màu gì?'));await s.inbox.drain(s.sender,s.ai);
  assert.equal(s.inputs[2].history[0].content,'Tôi mua áo đỏ cỡ M');
  assert.equal(s.inputs[2].history.length,2);
});
test('E9 no implicit cross-group, PRIVATE or legacy-without-actor context', async () => {
  const s=setup();await s.inbox.enqueue(event());await s.inbox.drain(s.sender,s.ai);
  const base=[...s.store.rows.values()][0];
  await s.store.put('tin:private',{...base,chatType:undefined,text:'private-secret'});
  await s.store.put('tin:legacy',{...base,senderId:undefined,text:'unknown-actor-secret'});
  await s.store.put('tin:other-group',{...base,chatId:'group-B',text:'other-group-secret'});
  await s.inbox.enqueue(event('user-A','message-2','Áo tôi màu gì?'));await s.inbox.drain(s.sender,s.ai);
  assert.ok(!JSON.stringify(s.inputs[1]).includes('secret'));
  assert.notEqual(inboxName(event()),inboxName(event('user-A','message-1','same','group-B')));
});
test('E9 group ID/warehouse/control commands never call manager or AI even for admin', async () => {
  const s=setup({catalogAdminEnabled:true,manageCatalog:async()=>assert.fail('group manager forbidden')});
  for(const [i,text] of ['/id','/suakho SP-A 1 2','/duyetkho 1','/huykho 1','/xemkho SP-A','/trangthai','/tatai','/batai'].entries()) {
    await s.inbox.enqueue(event('fake-owner',String(i),text));await s.inbox.drain(s.sender,s.ai);
  }
  assert.equal(s.inputs.length,0);assert.ok(s.sends.every(v=>v.text===GROUP_ADMIN_REPLY));
});
test('E9 group product continuation uses own history and current catalog without AI', async () => {
  const catalog=[{code:'SP-A',name:'Giả A',priceVnd:456000,warrantyDays:30,status:'active',updated:'09/10/2026'}];
  const s=setup({knowledgeEnabled:true,catalog});
  await s.inbox.enqueue(event('user-A','1','SP-A giá bao nhiêu?'));await s.inbox.drain(s.sender,s.ai);
  assert.ok(s.sends[0].text.includes('456.000'));assert.equal(s.inputs.length,0);
  await s.inbox.enqueue(event('user-B','2','bảo hành bao lâu?'));await s.inbox.drain(s.sender,s.ai);
  assert.equal(s.inputs.length,0);assert.ok(s.sends[1].text.includes('mã sản phẩm'));
});
test('E9 removing group before drain blocks queued paid/send work, re-enable never replays', async () => {
  let allowed=true;const s=setup({allowGroup:()=>allowed});
  await s.inbox.enqueue(event());allowed=false;await s.inbox.drain(s.sender,s.ai);
  assert.equal(s.inputs.length,0);assert.equal(s.sends.length,0);
  allowed=true;await s.inbox.drain(s.sender,s.ai);assert.equal(s.sends.length,0);
  assert.equal((await s.inbox.enqueue(event())).delivery,'uncertain');
});
test('E9 queue rejects denied group and missing actor even if directly invoked', async () => {
  const s=setup();assert.equal((await s.inbox.enqueue(event('user-A','1','hello','denied'))).status,'ignored');
  const bad=event();delete bad.senderId;assert.equal((await s.inbox.enqueue(bad)).status,'ignored');
  assert.equal(s.store.rows.size,0);
});
test('E9 management services also deny GROUP bypass before disclosing ID or changing state', async () => {
  const storage=new Store();
  for(const service of [new CatalogManager(storage,{admins:['owner']}),
    new OperatingControl(storage,{admins:['owner'],providerReady:true}),new OperatingBudget(storage,{admins:['owner']})]) {
    assert.equal(await service.handle({chatType:'GROUP',senderId:'owner',chatId:'group-A',text:'/id'}),GROUP_ADMIN_REPLY);
  }
  assert.equal(storage.rows.size,0);
});
const ownerEnv=()=>({...env(),GROUP_ALLOWED_IDS_JSON:'[]',GROUP_ACTIVATION_ENABLED:'true',CATALOG_ADMIN_IDS_JSON:'["owner"]'});
function permissionSetup(environment=ownerEnv()) {
  const s=setup(),permission=new GroupPermission(s.store,environment);
  const options={aiEnabled:true,memoryEnabled:true,allowGroup:id=>permission.allowed(id),
    canActivateGroup:e=>permission.canActivate(e),activateGroup:e=>permission.activate(e)};
  s.inbox=new DurableInbox(s.store,options);return {...s,permission,options};
}
test('E9 activation accepts exact new phrase with mention prefix, not prose or quoted fields', () => {
  for(const text of ['bật nhóm','BẬT NHÓM!','@Bot An 24h bật nhóm'])assert.equal(isGroupActivation(text),true);
  for(const text of ['ai đó nói bật nhóm','không bật nhóm','bật nhóm khác','> bật nhóm'])assert.equal(isGroupActivation(text),false);
  assert.equal(groupOwner(ownerEnv()),'owner');
  assert.equal(groupOwner({...ownerEnv(),CATALOG_ADMIN_IDS_JSON:'["owner","second"]'}),null);
  assert.equal(groupOwner({...ownerEnv(),GROUP_OWNER_ID:'stranger'}),null);
});
test('E9 only authenticated owner can enable inactive group; fake names, quotes and bot do not enroll', async () => {
  const s=permissionSetup();
  const guest=event('guest','guest','@An bật nhóm');guest.displayName='owner';guest.role='owner';
  assert.equal((await s.inbox.enqueue(guest)).status,'ignored');
  const quoted=event('owner','quoted','Xin chào');quoted.quote={text:'bật nhóm'};
  assert.equal((await s.inbox.enqueue(quoted)).status,'ignored');
  assert.equal(await s.permission.allowed('group-A'),false);assert.equal(s.store.rows.size,0);
  assert.equal(normalizeEvent(fixture({chatType:'GROUP',isBot:true,text:'bật nhóm'}),{includeGroups:true}).kind,'ignored');
});
test('E9 owner activation is durable with no AI, duplicate does not reapply, restart retains only chosen group', async () => {
  const s=permissionSetup();const command=event('owner','activate','@Bot An 24h bật nhóm');
  assert.equal((await s.inbox.enqueue(command)).status,'queued');await s.inbox.drain(s.sender,s.ai);
  assert.equal(s.sends[0].text,GROUP_ACTIVATED_REPLY);assert.equal(s.inputs.length,0);
  assert.equal((await s.inbox.enqueue(command)).status,'duplicate');
  const reopened=new DurableInbox(s.store,s.options);
  assert.equal(await s.permission.allowed('group-A'),true);assert.equal(await s.permission.allowed('group-B'),false);
  await reopened.enqueue(event('guest','after','2 cộng 3?'));await reopened.drain(s.sender,s.ai);
  assert.equal(s.inputs.length,1);assert.deepEqual(s.inputs[0].history,[]);
  assert.equal((await reopened.enqueue(event('guest','other','hello','group-B'))).status,'ignored');
});
test('E9 no capacity/failing activation creates permission; global disable and owner change fail closed', async () => {
  const s=permissionSetup();s.inbox.maxRecords=0;
  assert.equal((await s.inbox.enqueue(event('owner','full','bật nhóm'))).status,'capacity');
  assert.equal(await s.permission.allowed('group-A'),false);
  await s.permission.activate(event('owner','ok','bật nhóm'));
  assert.equal(await new GroupPermission(s.store,{...ownerEnv(),GROUP_ENABLED:'false'}).allowed('group-A'),false);
  assert.equal(await new GroupPermission(s.store,{...ownerEnv(),CATALOG_ADMIN_IDS_JSON:'["new-owner"]'}).allowed('group-A'),false);
  assert.equal(await new GroupPermission(s.store,{...ownerEnv(),CATALOG_ADMIN_IDS_JSON:'broken'}).allowed('group-A'),false);
});
test('E9 guest activation in enabled group is denied without AI or changing owner', async () => {
  const s=permissionSetup();await s.permission.activate(event('owner','init','bật nhóm'));
  await s.inbox.enqueue(event('guest','again','bật nhóm'));await s.inbox.drain(s.sender,s.ai);
  assert.equal(s.inputs.length,0);assert.ok(s.sends[0].text.includes('Chỉ người sở hữu'));
  assert.equal((await s.store.get('group:permission')).actor,'owner');
});
test('E9 failed queue/alarm commit rolls back activation permission and confirmation together', async () => {
  const s=permissionSetup();
  s.store.transaction=async fn=>{const before=structuredClone([...s.store.rows]);try{return await fn();}
    catch(e){s.store.rows=new Map(before);throw e;}};
  s.store.setAlarm=async()=>{throw Error('fake-alarm-failure');};
  await assert.rejects(s.inbox.enqueue(event('owner','failed','bật nhóm')));
  assert.equal(s.store.rows.size,0);assert.equal(await s.permission.allowed('group-A'),false);
});
