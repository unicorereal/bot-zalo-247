import test from 'node:test';
import assert from 'node:assert/strict';
import {readCatalog,productReply} from '../src/kho-san-pham.mjs';
import {CatalogManager} from '../src/quan-ly-kho.mjs';
import {readReferences,referenceContext} from '../src/du-lieu-tham-khao.mjs';
import {DurableInbox} from '../src/hang-doi-ben.mjs';
import {handleCloud} from '../src/nhan-cloud.mjs';
import {request,fixture,FAKE_SECRET} from './fixtures.mjs';
const data=()=>({version:2,products:[{code:'SP-A',name:'Áo Linen',fields:[{key:'gia',label:'Giá',value:'250.000 đồng'},{key:'chat-lieu',label:'Chất liệu',value:'Linen'}],status:'active',source:'chu-bot',updated:'14/10/2026'}]});
class Store{rows=new Map();async get(k){return structuredClone(this.rows.get(k));}async put(k,v){this.rows.set(k,structuredClone(v));}async list({prefix}){return new Map([...this.rows].filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k,structuredClone(v)]));}async transaction(f){return f();}async setAlarm(){}}
test('flexible product accepts only supplied facts, name lookup does not require a public code or warranty',()=>{
 const c=readCatalog(JSON.stringify(data()));assert.equal(c.length,1);const reply=productReply('Áo Linen chất liệu gì?',[],c);assert.match(reply,/Linen/);assert.match(reply,/250\.000/);assert.ok(!reply.includes('Bảo hành'));
 assert.match(productReply('SP-NO giá bao nhiêu?',[],c),/chưa có dữ liệu/);
 const course=data();course.products[0].name='Khóa tiếng Anh';course.products[0].fields=[{key:'lich-hoc',label:'Lịch học',value:'Thứ Hai, Tư, Sáu'}];assert.match(productReply('Lịch Khóa tiếng Anh?',[],readCatalog(JSON.stringify(course))),/Thứ Hai/);
  assert.match(productReply('Khóa tiếng Anh học phí bao nhiêu?',[],readCatalog(JSON.stringify(course))),/chưa có thông tin giá/);
});
test('explicit reimport replaces a managed catalog once and preserves later approved edits',async()=>{
 const store=new Store();await store.put('catalog:head',{revision:3,raw:JSON.stringify({version:1,products:[]}),events:0,drafts:0});
 const manager=new CatalogManager(store,{admins:['owner-fake'],initialCatalog:JSON.stringify(data()),initialImport:'import-14-10-2026'});
 assert.equal((await manager.current()).products.length,1);assert.equal((await store.get('catalog:head')).revision,4);
 const event=(text,key)=>({text,key,senderId:'owner-fake',chatId:'A'});
 await manager.handle(event('/suakho SP-A chat-lieu Cotton','import-edit'));await manager.handle(event('/duyetkho 1','import-approve'));
 assert.equal((await manager.current()).products[0].fields[1].value,'Cotton');assert.equal((await store.get('catalog:head')).revision,5);
});
test('flexible schema rejects duplicate fields, invented metadata and corrupt values atomically',()=>{
 for(const mutate of [d=>d.products[0].fields.push(d.products[0].fields[0]),d=>d.products[0].fields[0].key='__proto__',d=>d.products[0].fields[0].value='',d=>d.products[0].role='system']){const d=data();mutate(d);assert.equal(readCatalog(JSON.stringify(d)),null);}
});
test('generic field edit remains owner-only and draft approval changes only the selected field',async()=>{
 const store=new Store(),manager=new CatalogManager(store,{admins:['owner-fake'],initialCatalog:JSON.stringify(data()),now:()=>Date.UTC(2026,9,14)});
 const event=(text,key,who='owner-fake')=>({text,key,senderId:who,chatId:'A'});
 assert.match(await manager.handle(event('/suakho SP-A chat-lieu Cotton','1','guest-fake')),/chưa có quyền/);
 assert.match(await manager.handle(event('/suakho SP-A chat-lieu Cotton','2')),/Bản nháp/);assert.equal((await manager.current()).products[0].fields[1].value,'Linen');
 assert.match(await manager.handle(event('/duyetkho 1','3')),/Đã áp dụng/);assert.equal((await manager.current()).products[0].fields[1].value,'Cotton');assert.equal((await manager.current()).products[0].fields[0].value,'250.000 đồng');
});
test('reference import is bounded, source-attributed, and owner content never enters public/group answers',()=>{
 const source=(code,audience,text)=>({code,title:'Lịch học',text,status:'active',source:'file-chu-cung-cap',audience});
 const raw=JSON.stringify({version:1,sources:[source('PUBLIC','public','Lịch học thứ Hai.'),source('PRIVATE','owner','Lịch học riêng thứ Sáu.')]});
 assert.equal(readReferences(raw).length,2);assert.equal(referenceContext(raw,'Lịch học',false).length,1);assert.equal(referenceContext(raw,'Lịch học',true).length,2);
 assert.equal(readReferences('{bad'),null);assert.equal(readReferences('x'.repeat(24001)),null);assert.throws(()=>referenceContext('{bad','Lịch học'),/invalid/);
 assert.deepEqual(readReferences(undefined),[]);
});
test('self ID works before admin/catalog/AI enrollment, only replies privately and never pays or enrolls',async()=>{
 const store=new Store(),inbox=new DurableInbox(store,{now:()=>10});let paid=0,reply;
 await inbox.enqueue({key:'self-id',chatId:'A',senderId:'actor-fake',text:'/id'});
 await inbox.drain({send:async r=>{reply=r.text;return {status:'sent'};}},{configured:true,reserve:async()=>{paid++;return {allowed:true};}});
 assert.match(reply,/actor-fake.*không cấp quyền/);assert.equal(paid,0);assert.ok(![...store.rows.keys()].some(k=>k.startsWith('catalog:')));
});
test('fixed mode webhook supplies ID text without saving ordinary conversation text',async()=>{
 let event;const env={BOT_ENABLED:'true',WEBHOOK_SECRET:FAKE_SECRET,ZALO_BOT_TOKEN:'fake',INBOX:{idFromName:x=>x,get:()=>({fetch:async req=>{event=await req.json();return Response.json({status:'queued'});}})}};
 assert.equal((await handleCloud(request(fixture({text:'/id'})),env)).status,200);assert.equal(event.text,'/id');
 const store=new Store(),inbox=new DurableInbox(store,{now:()=>10});await inbox.enqueue({key:'ordinary',chatId:'A',text:'Nội dung không lưu'});assert.equal((await store.get('tin:ordinary')).text,undefined);
});
