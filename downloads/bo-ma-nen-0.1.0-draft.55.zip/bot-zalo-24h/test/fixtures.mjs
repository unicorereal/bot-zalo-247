export const FAKE_SECRET = 'gia-lap-webhook-0810';
export function fixture({ chatId = 'chat-gia-A', senderId = 'nguoi-gia-A', messageId = 'tin-gia-001',
  chatType = 'PRIVATE', isBot = false, eventName = 'message.text.received', text = 'Xin chào thử' } = {}) {
  return { ok: true, result: { event_name: eventName, message: {
    from: { id: senderId, display_name: 'Người giả', is_bot: isBot },
    chat: { id: chatId, chat_type: chatType },
    text, message_id: messageId, date: 1791417600000
  } } };
}
export function request(body = fixture(), { secret = FAKE_SECRET, type = 'application/json',
  method = 'POST', path = '/webhook', raw } = {}) {
  const headers = { 'Content-Type': type };
  if (secret !== null) headers['X-Bot-Api-Secret-Token'] = secret;
  return new Request(`http://127.0.0.1${path}`, {
    method, headers, ...(method === 'GET' ? {} : { body: raw ?? JSON.stringify(body) })
  });
}
