import test from 'node:test';
import assert from 'node:assert/strict';
import { OperatingBudget, OperatingControl, monthVN, aiFailureReply } from '../src/van-hanh-ai.mjs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { recentHistory } from '../src/bo-nho-chat.mjs';
import { isCatalogCommand } from '../src/quan-ly-kho.mjs';
class Storage {
  constructor() { this.rows=new Map(); this.tail=Promise.resolve(); }
  async get(k) { return structuredClone(this.rows.get(k)); }
  async put(k,v) { if(this.fail) throw Error('fake-write-failure'); this.rows.set(k,structuredClone(v)); }
  async list({prefix}) { return new Map([...this.rows].filter(([k])=>k.startsWith(prefix))); }
  async setAlarm() {}
  async transaction(fn) {
    const before=this.tail; let done; this.tail=new Promise(r=>done=r); await before;
    const backup=structuredClone(this.rows);
    try { return await fn(); } catch(e) { this.rows=backup; throw e; } finally { done(); }
  }
}
const event=(text,key='cmd-fake',senderId='admin-fake',chatId='chat-fake')=>({text,key,senderId,chatId});
const setup=()=>{const storage=new Storage();let time=Date.parse('2026-10-09T00:00:00Z');
  return {storage, budget:new OperatingBudget(storage,{now:()=>time,admins:['admin-fake']}),setTime:v=>time=Date.parse(v)};};

test('provider private and group switches are independent, persistent and globally controllable',async()=>{
 const storage=new Storage(),make=()=>new OperatingControl(storage,{admins:['admin-fake'],providerReady:true});let op=make();
 assert.match(await op.handle(event('/tatai nhom','group-off')),/trong nhóm/);
 assert.equal((await op.reserve('p1',{chatType:'PRIVATE'})).allowed,true);assert.equal((await op.reserve('g1',{chatType:'GROUP'})).reason,'ai-paused');
 op=make();assert.match(await op.handle(event('/trangthai','state1')),/AI chat riêng: BẬT[\s\S]*AI nhóm: TẮT/);
 await op.handle(event('/batai nhom','group-on'));await op.handle(event('/tatai rieng','private-off'));
 assert.equal((await op.reserve('p2',{chatType:'PRIVATE'})).reason,'ai-paused');assert.equal((await op.reserve('g2',{chatType:'GROUP'})).allowed,true);
 await op.handle(event('/tatai','all-off'));assert.equal((await op.permission('PRIVATE')).allowed,false);assert.equal((await op.permission('GROUP')).allowed,false);
 await op.handle(event('/batai rieng','only-private'));assert.equal((await op.permission('PRIVATE')).allowed,true);assert.equal((await op.permission('GROUP')).allowed,false);
 await op.handle(event('/batai','all-on'));assert.equal((await op.permission('GROUP')).allowed,true);
 assert.equal((await op.permission(null)).reason,'invalid-ai-scope');
});
test('provider scoped controls preserve old pause, authorization, atomicity and command receipts',async()=>{
 const storage=new Storage();await storage.put('operation:control',{paused:true});const op=new OperatingControl(storage,{admins:['admin-fake'],providerReady:true});
 assert.equal((await op.permission('PRIVATE')).allowed,false);assert.equal((await op.permission('GROUP')).allowed,false);
 await op.handle(event('/batai nhom','legacy-one'));assert.equal((await op.permission('PRIVATE')).allowed,false);assert.equal((await op.permission('GROUP')).allowed,true);
 assert.match(await op.handle(event('/batai rieng','guest','guest')),/chưa có quyền/);assert.equal((await op.permission('PRIVATE')).allowed,false);
 assert.match(await op.handle({...event('/batai rieng','group-admin'),chatType:'GROUP'}),/chat riêng/);
 await op.handle(event('/batai','resume'));const old=event('/tatai nhom','old-pause');await op.handle(old);await op.handle(event('/batai nhom','new-resume'));await op.handle(old);assert.equal((await op.permission('GROUP')).allowed,true);
 await Promise.all([op.handle(event('/tatai nhom','parallel-g')),op.handle(event('/tatai rieng','parallel-p'))]);assert.equal((await op.control()).paused,true);
 const before=await op.control();assert.match(await op.handle(event('/batai other','invalid')),/Dùng/);assert.deepEqual(await op.control(),before);
});
test('provider control preserves old allocation and ignores monetary state without deleting it',async()=>{
  const {storage,budget}=setup();await budget.reserve('old-fake');
  const before=await storage.get('operation:month:2026-10');
  const control=new OperatingControl(storage,{providerReady:true,admins:['admin-fake']});
  assert.equal((await control.reserve('old-fake')).reason,'already-allocated');
  for(let i=0;i<501;i++) assert.equal((await control.reserve(`provider-${i}`)).allowed,true);
  assert.deepEqual(await storage.get('operation:month:2026-10'),before);
  assert.doesNotMatch(await control.handle(event('/trangthai')),/0\.300|0\.700|1 USD/);
});
test('provider setup gate cannot be bypassed by resume and never allocates paid calls',async()=>{
  const storage=new Storage(),control=new OperatingControl(storage,{admins:['admin-fake']});
  await control.handle(event('/batai'));
  assert.equal((await control.reserve('setup-fake')).reason,'provider-setup');
  assert.equal((await storage.list({prefix:'operation:allocated:'})).size,0);
  assert.match(aiFailureReply('provider-setup'),/Project và key/);
});
test('provider pause persists across upgrade/reopen; duplicates cannot reapply old pause',async()=>{
  const {storage,budget}=setup();await budget.handle(event('/tatai'));
  const control=new OperatingControl(storage,{admins:['admin-fake'],providerReady:true});
  assert.equal((await control.reserve('paused')).reason,'ai-paused');
  await control.handle(event('/batai','resume-provider'));
  await control.handle(event('/tatai'));
  const results=await Promise.all(Array.from({length:5},()=>control.reserve('same-provider-event')));
  assert.equal(results.filter(r=>r.allowed).length,1);
  assert.equal((await new OperatingControl(storage,{providerReady:true}).reserve('same-provider-event')).reason,'already-allocated');
});
test('provider guest and bad storage fail closed without changing pause or retrying allocation',async()=>{
  const storage=new Storage(),control=new OperatingControl(storage,{admins:['admin-fake'],providerReady:true});
  assert.match(await control.handle(event('/tatai','guest-provider','guest-fake')),/chưa có quyền/);
  storage.fail=true;await assert.rejects(control.reserve('write-provider'));assert.equal(storage.rows.size,0);
  storage.fail=false;await storage.put('operation:control',{paused:'false'});await assert.rejects(control.reserve('corrupt-provider'));
});
test('monthly VN boundary and invalid clocks fail closed',()=>{
  assert.equal(monthVN(Date.parse('2026-10-31T16:59:59Z')),'2026-10');
  assert.equal(monthVN(Date.parse('2026-10-31T17:00:00Z')),'2026-11');
  assert.throws(()=>monthVN(NaN));assert.throws(()=>monthVN(Date.parse('2026-09-01')));
});
test('October includes both legacy trial reserves; concurrent chats cannot overspend',async()=>{
  const {storage,budget}=setup();
  const results=await Promise.all(Array.from({length:351},(_,i)=>budget.reserve(`event-fake-${i}`)));
  assert.equal(results.filter(r=>r.allowed).length,350);
  assert.equal(results.filter(r=>r.reason==='monthly-limit').length,1);
  assert.equal((await storage.get('operation:month:2026-10')).reservedMicroUsd,1000000);
  assert.equal((await new OperatingBudget(storage,{now:()=>Date.parse('2026-10-10')}).reserve('new-fake')).allowed,false);
});
test('month renews without refunding failures or replaying prior-month events',async()=>{
  const {storage,budget,setTime}=setup();await budget.reserve('old-fake');
  setTime('2026-10-31T17:00:00Z');assert.equal((await budget.reserve('old-fake')).reason,'already-allocated');
  assert.equal((await budget.reserve('new-fake')).allowed,true);
  assert.equal((await storage.get('operation:month:2026-11')).reservedMicroUsd,2000);
  assert.equal((await storage.get('operation:month:2026-10')).reservedMicroUsd,302000);
  setTime('2026-10-20');await assert.rejects(budget.reserve('clock-fake'));
});
test('new month allows 500 conservative attempts, not an invoice',async()=>{
  const {budget,setTime}=setup();setTime('2026-11-02');
  for(let i=0;i<500;i++) assert.equal((await budget.reserve(`new-month-fake-${i}`)).allowed,true);
  assert.equal((await budget.reserve('extra-fake')).reason,'monthly-limit');
});
test('pause persists through reopening and month change; resume never resets allowance',async()=>{
  const {storage,budget,setTime}=setup();await budget.reserve('first-fake');
  assert.match(await budget.handle(event('/tatai')),/Đã tắt/);
  assert.equal((await budget.reserve('paused-fake')).reason,'ai-paused');
  const reopened=new OperatingBudget(storage,{now:()=>Date.parse('2026-11-03'),admins:['admin-fake']});
  assert.equal((await reopened.reserve('new-month-fake')).reason,'ai-paused');
  await budget.handle(event('/batai','resume-fake'));
  assert.equal((await storage.get('operation:month:2026-10')).reservedMicroUsd,302000);
  // Duplicate old pause must return its cached reply, not pause after resume.
  await budget.handle(event('/tatai'));assert.equal((await budget.reserve('second-fake')).allowed,true);
});
test('guest, quoted commands and extra args cannot toggle or expose budget',async()=>{
  const {budget,storage}=setup();
  assert.match(await budget.handle(event('/trangthai','guest','guest-fake')),/chưa có quyền/);
  assert.equal(await budget.handle(event('Trích dẫn: /tatai')),null);
  assert.match(await budget.handle(event('/tatai 1')),/không nhận thêm/);
  assert.equal(await storage.get('operation:control'),undefined);
  assert.match(await budget.handle(event('/trangthai')),/0\.300 USD.*0\.700 USD/);
});
test('storage corruption and failed transactions do not allocate or repair by reset',async()=>{
  const {storage,budget}=setup();await storage.put('operation:month:2026-10',{period:'2026-10',calls:0,reservedMicroUsd:0});
  await assert.rejects(budget.reserve('bad-fake'));
  const second=setup();second.storage.fail=true;await assert.rejects(second.budget.reserve('write-fake'));
  assert.equal(second.storage.rows.size,0);
  const third=setup();await third.storage.put('operation:control',{paused:'false'});await assert.rejects(third.budget.reserve('bad-control'));
});
test('commands stay out of AI memory, including /id and operating status',()=>{
  const rows=new Map(['/trangthai','/tatai','/batai','/id'].map((text,i)=>[`tin:fake-${i}`,{text,chatId:'chat-fake',created:100,status:'sent',ai:{status:'ready',reply:'fake-private'}}]));
  assert.deepEqual(recentHistory(rows,'chat-fake',200),[]);
  for(const row of rows.values()) assert.equal(isCatalogCommand(row.text),true);
});
test('queue routes quota and pause into clear cached replies, no AI on denial',async()=>{
  assert.equal(aiFailureReply('ai-paused','fallback','GROUP'),'Em đang tạm ngừng trả lời bằng AI trong nhóm này.');
  assert.equal(aiFailureReply('ai-paused','fallback','PRIVATE'),'Em đang tạm ngừng trả lời bằng AI trong chat riêng.');
  for(const reason of ['monthly-limit','ai-paused']) {
    const storage=new Storage(),inbox=new DurableInbox(storage,{aiEnabled:true});let aiCalls=0,sent;
    await inbox.enqueue(event('Câu hỏi giả','question-fake'));
    await inbox.drain({send:async body=>{sent=body.text;return {status:'sent'};}},{configured:true,reserve:async()=>({allowed:false,reason}),generate:async()=>{aiCalls++;}});
    assert.equal(sent,aiFailureReply(reason,'fallback'));assert.equal(aiCalls,0);
  }
});
