import test from 'node:test';
import assert from 'node:assert/strict';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { OperatingControl } from '../src/van-hanh-ai.mjs';
import { CONTENT_TTL, RECEIPT_TTL, FUTURE_SKEW, MAX_OPERATION_RECEIPTS, eventAgeReason } from '../src/luu-du-lieu.mjs';
import { recentHistory } from '../src/bo-nho-chat.mjs';
import { normalizeEvent } from '../src/chuan-tin.mjs';
import { fixture } from './fixtures.mjs';
class Store {
  constructor(){this.rows=new Map();this.alarm=null;this.tail=Promise.resolve();}
  async get(k){return structuredClone(this.rows.get(k));}
  async put(k,v){this.rows.set(k,structuredClone(v));}
  async delete(k){if(this.failDelete)throw Error('fake-delete-failed');return this.rows.delete(k);}
  async list({prefix}){return new Map([...this.rows].filter(([k])=>k.startsWith(prefix)).map(([k,v])=>[k,structuredClone(v)]));}
  async setAlarm(v){if(this.failAlarm)throw Error('fake-alarm-failed');this.alarm=v;}
  async getAlarm(){return this.alarm;}
  async transaction(fn){const before=this.tail;let done;this.tail=new Promise(r=>{done=r;});await before;const backup=structuredClone(this.rows),alarm=this.alarm;try{return await fn();}catch(e){this.rows=backup;this.alarm=alarm;throw e;}finally{done();}}
}
const START=Date.UTC(2026,9,9,0);
const event=(time=START,key='fake-1')=>({key,chatId:'chat-fake',senderId:'admin-fake',text:'Áo giả màu đỏ cỡ M',eventAt:time});
function setup(options={}){let now=START;const storage=new Store(),inbox=new DurableInbox(storage,{retentionEnabled:true,aiEnabled:true,memoryEnabled:true,now:()=>now,...options});let aiCalls=0,zaloCalls=0;const ai={configured:true,reserve:async()=>({allowed:true}),generate:async()=>{aiCalls++;return {status:'ready',reply:'Áo đỏ cỡ M.'};}},sender={send:async()=>{zaloCalls++;return {status:'sent'};}};return {storage,inbox,ai,sender,time:v=>{now=v;},now:()=>now,calls:()=>({aiCalls,zaloCalls})};}
test('retention is opt-in; default preserves old records and timestamp normalization contract',async()=>{
 const s=setup({retentionEnabled:false});await s.inbox.enqueue(event());await s.inbox.drain(s.sender,s.ai);s.time(START+RECEIPT_TTL+100);await s.inbox.maintain();assert.equal(s.storage.rows.get('tin:fake-1').text,event().text);
 assert.equal(normalizeEvent(fixture()).eventAt,undefined);assert.equal(normalizeEvent(fixture(),{includeTimestamp:true}).eventAt,1791417600000);
});
test('30d storage is separate from 24h AI memory; exact storage boundary retains content then deletes',async()=>{
 const s=setup({catalogAdminEnabled:true});const e={...event(),text:'/id'};await s.inbox.enqueue(e);await s.inbox.drain(s.sender,s.ai);
 s.time(START+86400000+1);await s.inbox.maintain();assert.equal(s.storage.rows.get('tin:fake-1').text,'/id');assert.equal(recentHistory(await s.storage.list({prefix:'tin:'}),'chat-fake',s.now()).length,0);
 s.time(START+CONTENT_TTL);await s.inbox.maintain();assert.equal(s.storage.rows.get('tin:fake-1').text,'/id');assert.equal((await s.inbox.enqueue(e)).status,'duplicate');
 s.time(START+CONTENT_TTL+1);assert.equal((await s.inbox.maintain()).removed,1);assert.equal(s.storage.rows.has('tin:fake-1'),false);assert.equal((await s.inbox.enqueue(e)).reason,'expired-event');assert.deepEqual(s.calls(),{aiCalls:0,zaloCalls:1});
});
test('30d boundary remains dedup; expiration frees capacity and old replay causes zero external calls',async()=>{
 const s=setup({maxRecords:1});await s.inbox.enqueue(event());await s.inbox.drain(s.sender,s.ai);s.time(START+RECEIPT_TTL);await s.inbox.maintain();assert.equal((await s.inbox.enqueue(event())).status,'duplicate');assert.equal((await s.inbox.enqueue(event(s.now(),'fake-2'))).status,'capacity');
 s.time(START+RECEIPT_TTL+1);assert.equal((await s.inbox.maintain()).removed,1);assert.equal((await s.inbox.enqueue(event())).reason,'expired-event');await s.inbox.drain(s.sender,s.ai);assert.deepEqual(s.calls(),{aiCalls:1,zaloCalls:1});assert.equal((await s.inbox.enqueue(event(s.now(),'fake-2'))).status,'queued');
});
test('legacy terminal receipt is retained forever without text and does not consume new window capacity',async()=>{
 const s=setup({maxRecords:1});const legacy={chatId:'chat-fake',senderId:'legacy-actor',status:'sent',created:START-CONTENT_TTL-2,text:'private-fake',ai:{status:'ready',reply:'fake-private'}};
 await s.storage.put('tin:legacy',legacy);await s.inbox.maintain();assert.equal(s.storage.rows.get('tin:legacy').legacy,true);s.time(START+RECEIPT_TTL*2);await s.inbox.maintain();assert.equal(s.storage.rows.has('tin:legacy'),true);assert.equal((await s.inbox.enqueue(event(s.now()))).status,'queued');
});
test('maintenance never scrubs queued or processing; stale queued job becomes uncertain without API or Zalo',async()=>{
 const s=setup();await s.inbox.enqueue(event());await s.storage.put('tin:busy',{...s.storage.rows.get('tin:fake-1'),status:'processing',due:START+RECEIPT_TTL*2});
 s.time(START+RECEIPT_TTL+1);await s.inbox.maintain({sendEnabled:false});assert.equal(s.storage.rows.get('tin:fake-1').text,event().text);assert.equal(s.storage.rows.get('tin:busy').text,event().text);
 await s.inbox.drain(s.sender,s.ai);assert.equal(s.storage.rows.get('tin:fake-1').status,'uncertain');assert.equal(s.storage.rows.get('tin:busy').status,'processing');assert.deepEqual(s.calls(),{aiCalls:0,zaloCalls:0});
});
test('delete/alarm failure rolls back cleanup; no success ACK or paid call on failing maintenance',async()=>{
 const s=setup();await s.inbox.enqueue(event());await s.inbox.drain(s.sender,s.ai);s.time(START+RECEIPT_TTL+1);s.storage.failDelete=true;await assert.rejects(s.inbox.maintain());assert.equal(s.storage.rows.has('tin:fake-1'),true);
 s.storage.failDelete=false;await s.storage.put('tin:new',{status:'sent',created:s.now(),eventAt:s.now(),text:'fake'});s.storage.failAlarm=true;await assert.rejects(s.inbox.maintain());assert.equal(s.storage.rows.has('tin:fake-1'),true);
});
test('bad/future timestamp fails closed; 5min skew is tolerated; corrupt record is never deleted',async()=>{
 assert.equal(eventAgeReason(START+FUTURE_SKEW,START),null);assert.equal(eventAgeReason(START+FUTURE_SKEW+1,START),'future-event');
 const s=setup();for(const at of [undefined,0,'123',START+FUTURE_SKEW+1])assert.equal((await s.inbox.enqueue({...event(),eventAt:at})).status,'ignored');
 await s.storage.put('tin:corrupt',{status:'sent',created:'bad',text:'fake'});await s.inbox.maintain();assert.equal(s.storage.rows.get('tin:corrupt').text,'fake');
});
test('concurrent duplicate and new instance preserve compacted future-skew receipt, memory is isolated by chat',async()=>{
 const s=setup(),e=event(START+FUTURE_SKEW);const result=await Promise.all(Array.from({length:8},()=>s.inbox.enqueue(e)));assert.equal(result.filter(r=>r.status==='queued').length,1);await s.inbox.drain(s.sender,s.ai);
 assert.equal(recentHistory(await s.storage.list({prefix:'tin:'}),'other-chat',s.now()).length,0);s.time(START+CONTENT_TTL+1);await s.inbox.maintain();assert.equal(s.storage.rows.get('tin:fake-1').receipt,true);const reopened=new DurableInbox(s.storage,{retentionEnabled:true,now:s.now});assert.equal((await reopened.enqueue(e)).status,'duplicate');
});
test('global AI receipts expire, old replay denied and historic ledger/pause/catalog stay unchanged',async()=>{
 let now=START;const storage=new Store(),make=()=>new OperatingControl(storage,{providerReady:true,admins:['admin-fake'],retentionEnabled:true,now:()=>now});const op=make();
 await storage.put('operation:allocated:legacy',true);await storage.put('catalog:head',{fake:'preserve'});await storage.put('ai-budget',{fake:'preserve'});
 const result=await Promise.all(Array.from({length:6},()=>op.reserve('fake-1',{eventAt:START})));assert.equal(result.filter(r=>r.allowed).length,1);
 const cmd={...event(),key:'pause-fake',text:'/tatai'};await op.handle(cmd);assert.equal((await op.control()).paused,true);
 now+=RECEIPT_TTL+1;assert.equal((await make().maintain()).removed,2);assert.equal((await make().reserve('fake-1',{eventAt:START})).reason,'expired-event');assert.equal((await make().control()).paused,true);
 assert.equal(await storage.get('operation:allocated:legacy'),true);assert.deepEqual(await storage.get('catalog:head'),{fake:'preserve'});assert.deepEqual(await storage.get('ai-budget'),{fake:'preserve'});
});
test('old pause command cannot reapply after resume even after receipt cleanup',async()=>{
 let now=START;const storage=new Store(),op=new OperatingControl(storage,{admins:['admin-fake'],providerReady:true,retentionEnabled:true,now:()=>now});const pause={...event(),key:'pause',text:'/tatai'},resume={...event(),key:'resume',text:'/batai'};
 await op.handle(pause);await op.handle(resume);now+=RECEIPT_TTL+1;await op.maintain();assert.match(await op.handle(pause),/đã cũ/);assert.equal((await op.control()).paused,false);
});
test('shared receipt capacity refuses AI and admin mutation, then reclaims the expired window',async()=>{
 let now=START;const storage=new Store(),op=new OperatingControl(storage,{admins:['admin-fake'],providerReady:true,retentionEnabled:true,now:()=>now});
 for(let i=0;i<MAX_OPERATION_RECEIPTS;i++)await storage.put(`operation:allocated:fake-${i}`,{retentionVersion:1,at:START,eventAt:START});
 assert.equal((await op.reserve('new-fake',{eventAt:now})).reason,'receipt-capacity');
 assert.match(await op.handle({...event(),key:'pause-full',text:'/tatai'}),/đầy dấu chống trùng/);assert.equal((await op.control()).paused,false);
 now+=RECEIPT_TTL+1;assert.equal((await op.reserve('new-fake',{eventAt:now})).allowed,true);assert.equal((await storage.list({prefix:'operation:allocated:'})).size,1);
});
