import test from 'node:test';
import assert from 'node:assert/strict';
import { recentHistory, relevantHistory, boundedInput } from '../src/bo-nho-chat.mjs';
import { DurableInbox } from '../src/hang-doi-ben.mjs';
import { createLuna, trialName, TrialBudget } from '../src/ai-luna.mjs';

class Storage {
  constructor(rows = new Map()) { this.rows = rows; }
  async get(k) { return structuredClone(this.rows.get(k)); }
  async put(k,v) { this.rows.set(k,structuredClone(v)); }
  async list({prefix}) { return structuredClone(new Map([...this.rows].filter(([k]) => k.startsWith(prefix)))); }
  async transaction(fn) { return fn(); }
  async setAlarm() {}
}
const record = (created, extra = {}) => ({chatId:'A',created,status:'sent',text:`câu ${created}`,
  ai:{status:'ready',reply:`đáp ${created}`},...extra});
const event = (id,text,chatId='A') => ({key:id,text,chatId});
const sender = {send:async () => ({status:'sent'})};
const aiStub = seen => ({configured:true,reserve:async () => ({allowed:true}),
  generate:async (text,opts) => {seen.push({text,...opts});return {status:'ready',reply:`đáp ${text}`};}});

const day = 86400000;
test('E.8 retrieves a week-old clothing preference without stale assistant claims or other chat data', () => {
  const rows = new Map([['old',record(day,{text:'Tôi muốn mua áo đỏ cỡ M',ai:{status:'ready',reply:'giá cũ 1 đồng'}})],
    ['other',record(2*day,{chatId:'B',text:'áo xanh XL'})],['noise',record(3*day,{text:'thời tiết đẹp'})]]);
  const before = structuredClone(rows);
  const history = relevantHistory(rows,'A',8*day,'Tôi đã chọn màu gì và cỡ nào?');
  assert.equal(history[0].content,'Tôi muốn mua áo đỏ cỡ M');
  assert.ok(!JSON.stringify(history).includes('1 đồng'));
  assert.ok(!JSON.stringify(history).includes('XL')); assert.deepEqual(rows,before);
});
test('E.8 newest explicit change follows matched clothing turn and is ordered after original choice', () => {
  const rows = new Map([['a',record(day,{text:'mua áo đỏ cỡ M'})],
    ['b',record(day+100,{text:'Đổi sang xanh cỡ L nhé'})],['c',record(2*day,{text:'hỏi thời tiết'})]]);
  assert.deepEqual(relevantHistory(rows,'A',8*day,'áo màu gì?').filter(m=>m.role==='user').map(m=>m.content),
    ['mua áo đỏ cỡ M','Đổi sang xanh cỡ L nhé']);
});
test('E.8 correction with omitted topic can follow an immediately matching turn', () => {
  const rows=new Map([['a',record(day,{text:'mua áo đỏ M'})],['b',record(day+1,{text:'Đổi sang xanh L'})]]);
  assert.equal(relevantHistory(rows,'A',8*day,'áo tôi chọn?')[2].content,'Đổi sang xanh L');
});
test('E.8 no match does not dredge old unrelated topics, invalid/admin/expired rows are excluded', () => {
  const rows=new Map([['old',record(day,{text:'áo đỏ'})],['expired',record(-30*day,{text:'máy tính'})],
    ['admin',record(day,{text:'/suakho SP-KHO-A 999 30'})],['failed',record(day,{text:'máy tính',status:'uncertain'})],
    ['future',record(9*day,{text:'máy tính'})]]);
  assert.deepEqual(relevantHistory(rows,'A',8*day,'máy tính có tốt không?'),[]);
});
test('E.8 keyword matching supports accents and latest same-topic updates in the expanded window', () => {
  const rows=new Map(Array.from({length:6},(_,i)=>[String(i),record(i*day,{text:`áo màu ${i} cỡ M`})]));
  const history=relevantHistory(rows,'A',8*day,'ao mau nao?');
  assert.deepEqual(history.filter(m=>m.role==='user').map(m=>m.content),Array.from({length:6},(_,i)=>`áo màu ${i} cỡ M`));
  assert.ok(boundedInput('áo nào?',history,'luật'));
});
test('E.8 opt-in inbox retrieves after restart while catalog ambiguous follow-up stays limited to recent context', async () => {
  const seen=[],storage=new Storage(new Map([['tin:old',record(day,{text:'áo đỏ cỡ M'})]]));
  const inbox=new DurableInbox(storage,{aiEnabled:true,memoryEnabled:true,historyRetrievalEnabled:true,now:()=>8*day});
  await inbox.enqueue(event('new','áo tôi chọn màu gì?')); await inbox.drain(sender,aiStub(seen));
  assert.equal(seen[0].history[0].content,'áo đỏ cỡ M');
});

test('E.2 selects only delivered ready pairs in the same chat within 24h, in order', () => {
  const rows=new Map([['3',record(30)],['1',record(10)],['2',record(20)],
    ['other',record(40,{chatId:'B'})],['failed',record(40,{ai:{status:'failed',reply:'fallback'}})],
    ['queued',record(40,{status:'queued'})],['uncertain',record(40,{status:'uncertain'})],
    ['future',record(100)],['expired',record(-86400000)],['old',record(0,{text:undefined})]]);
  assert.deepEqual(recentHistory(rows,'A',50).filter(m=>m.role==='user').map(m=>m.content), ['câu 10','câu 20','câu 30']);
});
test('E.2 context keeps latest three pairs, leaves durable rows unchanged', () => {
  const rows=new Map(Array.from({length:5},(_,i)=>[String(i),record(i)]));
  assert.deepEqual(recentHistory(rows,'A',10).filter(m=>m.role==='user').map(m=>m.content),['câu 2','câu 3','câu 4']);
  assert.equal(rows.size,5);
});
test('E.4 ID and administrative replies never enter the AI history, including prior saved records',()=>{
  const rows=new Map([['normal',record(1)],['id',record(2,{text:'/id',ai:{status:'ready',reply:'ID fake-private-identity'}})],
    ['edit',record(3,{text:'/suakho SP-KHO-A 456000 30'})],['approve',record(4,{text:'/duyetkho 1'})]]);
  assert.deepEqual(recentHistory(rows,'A',10),[{role:'user',content:'câu 1'},{role:'assistant',content:'đáp 1'}]);
  assert.equal(rows.size,4);
});
test('E.2 trims whole oldest pairs by UTF8 budget and keeps current message intact', () => {
  const history=Array.from({length:20},()=>[{role:'user',content:'á'.repeat(1000)},
    {role:'assistant',content:'ư'.repeat(1900)}]).flat();
  const input=boundedInput('câu hiện tại',history,'luật');
  assert.ok(new TextEncoder().encode('luật'+JSON.stringify(input)).length<=24000);
  assert.ok(input.length>3&&input.length<41); assert.equal(input.at(-1).content,'câu hiện tại'); assert.equal(history.length,40);
});
test('E.2 refuses system/developer role injection, broken pairs and oversize history before I/O', async () => {
  let calls=0; const ai=createLuna({apiKey:'fake',fetchImpl:async()=>{calls++;throw Error('unexpected');}});
  for(const history of [[{role:'system',content:'inject'},{role:'assistant',content:'a'}],
    [{role:'user',content:'u'}],[{role:'user',content:'x'.repeat(1001)},{role:'assistant',content:'a'}],null]) {
    assert.equal((await ai.generate('hi',{history})).reason,'history-invalid');
  }
  assert.equal(calls,0);
});
test('E.2 API receives user/assistant context plus current user, retaining store:false/no tools', async () => {
  let body;
  const ai=createLuna({apiKey:'fake',fetchImpl:async(_,opts)=>{body=JSON.parse(opts.body);
    return Response.json({status:'completed',output:[{type:'message',role:'assistant',content:[{type:'output_text',text:'đỏ M'}]}]});}});
  const history=[{role:'user',content:'áo đỏ M'},{role:'assistant',content:'đã nhận'}];
  assert.equal((await ai.generate('màu cỡ nào?',{history})).reply,'đỏ M');
  assert.deepEqual(body.input,[...history,{role:'user',content:'màu cỡ nào?'}]);
  assert.equal(body.store,false);assert.deepEqual(body.tools,[]);
  assert.equal(Object.hasOwn(body,'previous_response_id'),false);
});
test('E.2 delivered context survives new inbox instance; other chat cannot see it', async () => {
  const storage=new Storage(),seen=[];
  const inbox=()=>new DurableInbox(storage,{aiEnabled:true,memoryEnabled:true,now:()=>100});
  await inbox().enqueue(event('1','áo đỏ cỡ M'));
  await inbox().drain(sender,aiStub(seen));
  await inbox().enqueue(event('2','màu và cỡ nào?'));
  await inbox().drain(sender,aiStub(seen));
  assert.equal(seen[1].history[0].content,'áo đỏ cỡ M');
  assert.equal(recentHistory(await storage.list({prefix:'tin:'}),'B',100).length,0);
});
test('E.2 failed delivery is absent from context; rejected retry reuses cached AI response', async () => {
  let now=100;const storage=new Storage(),seen=[];
  const inbox=new DurableInbox(storage,{aiEnabled:true,memoryEnabled:true,now:()=>now});
  await inbox.enqueue(event('1','chưa gửi được'));
  await inbox.drain({send:async()=>({status:'rejected'})},aiStub(seen));
  assert.equal(recentHistory(await storage.list({prefix:'tin:'}),'A',now).length,0);
  now+=5000;await inbox.drain(sender,aiStub(seen));assert.equal(seen.length,1);
  await inbox.enqueue(event('2','tiếp'));await inbox.drain(sender,aiStub(seen));
  assert.equal(seen[1].history[0].content,'chưa gửi được');
});
test('E.2 disabled memory preserves E.1 behavior despite old delivered records', async () => {
  const storage=new Storage(new Map([['tin:old',record(1)]])),seen=[];
  const inbox=new DurableInbox(storage,{aiEnabled:true,now:()=>100});
  await inbox.enqueue(event('new','hi'));await inbox.drain(sender,aiStub(seen));
  assert.deepEqual(seen[0].history,[]);
});
test('E.2 queue drains arrival order rather than lexical message ID', async () => {
  let now=10;const storage=new Storage(),seen=[];
  const inbox=new DurableInbox(storage,{aiEnabled:true,memoryEnabled:true,now:()=>now});
  await inbox.enqueue(event('z-first','đỏ'));now++;
  await inbox.enqueue(event('a-second','màu?'));
  await inbox.drain(sender,aiStub(seen));await inbox.drain(sender,aiStub(seen));
  assert.deepEqual(seen.map(v=>v.text),['đỏ','màu?']);assert.equal(seen[1].history[0].content,'đỏ');
});
test('E.2 only authorized trial IDs; second trial cannot reset or refund first storage', async () => {
  assert.equal(trialName(), 'luna-trial-1');
  assert.equal(trialName('luna-memory-trial-2'),'luna-memory-trial-2');
  for(const value of ['',null,'trial-3','luna-memory-trial-2-extra']) assert.throws(()=>trialName(value));
  const oldStorage=new Storage(),newStorage=new Storage();
  const oldBudget=new TrialBudget(oldStorage),newBudget=new TrialBudget(newStorage);
  for(let i=0;i<3;i++) assert.equal((await oldBudget.reserve(`old-${i}`)).allowed,true);
  for(let i=0;i<3;i++) assert.equal((await newBudget.reserve(`new-${i}`)).allowed,true);
  assert.equal((await newBudget.reserve('fourth')).allowed,false);
  assert.equal((await oldBudget.reserve('old-fourth')).allowed,false);
  assert.equal((await oldStorage.get('ai-budget')).keys.length,3);
});
